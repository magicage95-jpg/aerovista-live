# AEROVISTA LIVE

A real-time 3D Earth: live aircraft, airport boards, satellites and the ISS, weather, imagery and a flat map mode.
React + TypeScript + Vite + React Three Fiber on the front, Node + Express on the back.

> **Honesty rules built into the app**
> - Every panel shows *Source*, *Updated* and a status: `LIVE`, `LAST UPDATED`, `PREDICTED`, `CALCULATED`, `STATIC` or `DEMO DATA`.
> - Satellites are **PREDICTED** (SGP4 from public orbital elements), never labelled live.
> - Demo data only appears when you ask for it (`DEMO_MODE=on`) or for airport schedules when no schedule key exists, and is always labelled.
> - Coverage depends on the data provider.

## What works with zero API keys

| Layer | Provider | Notes |
|---|---|---|
| Aircraft | OpenSky Network, falling back to adsb.lol | Anonymous OpenSky is heavily rate limited, so the server refreshes it slowly and aircraft are dead-reckoned between updates. Add OpenSky credentials for ~90 s refreshes. |
| Satellites / ISS | CelesTrak | Calculated in the browser. |
| Weather, place search | Open-Meteo | Free tier is non-commercial. |
| Imagery | NASA GIBS (proxied + cached) | Blue Marble, Black Marble, daily true colour. |
| Airports | OurAirports | Seed list is used if the download fails. |

Needs a key: **airport arrivals/departures** (`FLIGHT_API_KEY`, AeroDataBox via RapidAPI). Optional: `MAPILLARY_TOKEN` (street-level photos), `WEATHER_API_KEY` (Open-Meteo commercial).

## 1. Install

```bash
npm install
```
Node 20+ is required.

## 2. Environment

```bash
cp .env.example .env
```

## 3. Add API keys (all optional, see table above)

Edit `.env`. Secrets live only on the server. The frontend never receives them.

## 4. Start the backend

```bash
npm run dev:server        # http://localhost:8787
```

## 5. Start the frontend

```bash
npm run dev:client        # http://localhost:5173 (proxies /api to :8787)
# or both together:
npm run dev
```

## 6. Production build

```bash
npm run build             # typechecks client + server, then builds ./dist
npm start                 # Express serves ./dist and /api on $PORT
```

## 7. Deploy: one service (simplest)

Railway or Render, single web service:

- Build command: `npm install && npm run build`
- Start command: `npm start`
- Set the variables from `.env.example` in the dashboard. Leave `VITE_API_BASE` empty.

## 8. Deploy: split frontend and backend

**Backend (Railway/Render):** same as above. Set `CORS_ORIGINS=https://your-frontend.example`.

**Frontend (Vercel/Netlify):**
```bash
VITE_API_BASE=https://your-backend.example npm run build
```
Publish `dist/`. `vercel.json` already rewrites unknown paths to `index.html`.

## 9. CORS

`CORS_ORIGINS` is a comma-separated allow-list. Same-origin requests need no entry. Only `GET` is allowed.

## 10. API limits and caching

- Server cache with in-flight de-duplication and stale-if-error (`server/cache`). A failing provider serves the last good data, flagged `LAST UPDATED`.
- Per-provider throttles, a 60 s cool-down after a failure, and a per-IP limit of `RATE_LIMIT_PER_MIN` (default 240) on `/api`.
- Client cache and request de-duplication (`src/services/apiClient.ts`); polling follows the server's `ttlSec` and pauses in background tabs.
- Overrides: `FLIGHT_CACHE_TTL_SEC`. Do not set it below your provider's limits.

## Architecture

```
src/
  components/{globe,map,ui,panels}  pages/  layouts/
  services/   flightService airportService satelliteService weatherService mapService geocodingService
  runtime/    non-reactive aircraft + satellite state read every frame (no React renders for 10k objects)
  stores/ hooks/ utils/ types/ config/
server/
  routes/ services/ middleware/ cache/ utils/ data/
```

Swap a provider by implementing `FlightProvider` (`server/services/flights/types.ts`) or editing `src/config/mapProviders.ts`.

### Performance
Aircraft render as one `InstancedMesh` (single draw call); satellites, airports and borders are single buffers. Picking is screen-space (no raycasting over thousands of instances). Airports cluster on the 2D map. `three`, `r3f` and `maplibre` are split into separate chunks and the globe/map are lazy loaded.

### Accessibility
Keyboard: arrow keys rotate, `+`/`-` zoom, `/` focuses search. Visible focus, ARIA roles on search, tabs and dialogs, `prefers-reduced-motion` plus a manual setting.

## Known limitations

- Anonymous OpenSky is slow by design; use credentials or accept regional adsb.lol fallback.
- Airport "weather" is gridded model output, not METAR.
- Flight route/type data from adsb.lol is community-sourced and may be missing.
- 3D buildings need a vector-tile provider; the raster basemaps here do not claim them.
- Street-level imagery depends on Mapillary coverage and a token.
- Free tile services (OSM, Esri, CARTO, OpenTopoMap) have usage policies. Replace them in `mapProviders.ts` before heavy production traffic.
- Review each provider's current terms before commercial use.
