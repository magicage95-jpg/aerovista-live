import { ArrowLeft } from 'lucide-react';
import { useAppStore } from '../stores/useAppStore';
import { useDataStore } from '../stores/useDataStore';
import { PROVIDERS_FOR_ABOUT, BASEMAPS } from '../config/mapProviders';

const KINDS = [
  ['LIVE DATA', 'Reported by a provider and refreshed on their schedule. Positions between updates are estimated.'],
  ['CALCULATED DATA', 'Derived here from other data, such as distance remaining or aircraft near an airport.'],
  ['PREDICTED DATA', 'Modelled forward in time, such as satellite positions from orbital elements.'],
  ['STATIC DATA', 'Reference data that changes rarely, such as airport directories and basemaps.'],
];

export default function AboutPage() {
  const setPage = useAppStore((s) => s.setPage);
  const server = useDataStore((s) => s.server);
  return (
    <div className="about">
      <a className="back" href="#/" onClick={() => setPage('explorer')}><ArrowLeft size={16} aria-hidden /> Back to Earth</a>
      <h1>About AEROVISTA LIVE</h1>
      <p className="lede">A 3D Earth for following aircraft, satellites and airports. Every panel names its source and says whether its data is live, calculated, predicted or static.</p>

      <h2>How to read the labels</h2>
      <dl className="kinds">{KINDS.map(([k, v]) => <div key={k}><dt>{k}</dt><dd>{v}</dd></div>)}</dl>
      <p>Coverage depends on the data provider. Aircraft that no receiver hears do not appear, and satellite positions are predictions, not telemetry. Demo mode, when active, is always labelled DEMO DATA.</p>

      <h2>Data sources</h2>
      <div className="table-wrap"><table className="board">
        <thead><tr><th>Provider</th><th>Used for</th><th>Type</th><th>Terms and notes</th></tr></thead>
        <tbody>{PROVIDERS_FOR_ABOUT.map((p) => (
          <tr key={p.name}><td><a href={p.url} target="_blank" rel="noreferrer">{p.name}</a></td><td>{p.use}</td><td className="mono">{p.kind}</td><td>{p.note}</td></tr>
        ))}</tbody>
      </table></div>

      <h2>Map attribution</h2>
      <ul>{Object.values(BASEMAPS).map((b) => <li key={b.id}>{b.label}: {b.attribution} (<a href={b.terms} target="_blank" rel="noreferrer">terms</a>)</li>)}</ul>

      {server && (
        <>
          <h2>This deployment</h2>
          <ul>{Object.entries(server.layers).map(([k, v]) => <li key={k}><b>{k}</b>: {v.provider} · {v.configured ? 'configured' : 'not configured'}{v.note ? ` · ${v.note}` : ''}</li>)}</ul>
        </>
      )}
      <p className="note">Provider terms change. Review each provider’s current terms before commercial use; several free tiers are limited to non-commercial use.</p>
    </div>
  );
}
