import AppShell from '../layouts/AppShell';
export default function ExplorerPage() { return <AppShell />; }
