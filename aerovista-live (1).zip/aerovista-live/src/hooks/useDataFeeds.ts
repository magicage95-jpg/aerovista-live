import { useCallback, useEffect, useRef } from 'react';
import { airportService } from '../services/airportService';
import { flightService } from '../services/flightService';
import { satelliteService } from '../services/satelliteService';
import { apiGet, ApiError } from '../services/apiClient';
import { useAppStore } from '../stores/useAppStore';
import { useDataStore } from '../stores/useDataStore';
import { AC, setAircraft, pushTrail } from '../runtime/aircraft';
import { setSatellites } from '../runtime/satellites';
import type { ServerStatus } from '../types';

const errMsg = (e: unknown) => (e instanceof ApiError ? e.message : 'Live data temporarily unavailable');

/** Loads every data layer independently so one failing provider never takes down the others. */
export function useDataFeeds() {
  const refreshNonce = useAppStore((s) => s.refreshNonce);
  const refreshMode = useAppStore((s) => s.settings.refresh);
  const set = useDataStore((s) => s.set);
  const timer = useRef<number | undefined>(undefined);

  const loadFlights = useCallback(async () => {
    const st = useDataStore.getState().flights;
    set('flights', { status: st.data.length ? st.status : 'loading' });
    try {
      const { data, meta } = await flightService.getLive(useAppStore.getState().userLocation ?? undefined);
      setAircraft(data);
      const sel = useAppStore.getState().selection;
      if (sel?.type === 'flight') {
        const a = data.find((x) => x.id === sel.id);
        if (a) pushTrail(a.id, a.lat, a.lon, a.altM ?? 0, a.positionAt);
      }
      set('flights', { data, meta, status: 'ok', error: undefined, updatedAt: Date.now() });
    } catch (e) {
      set('flights', { status: 'error', error: errMsg(e) });
    }
  }, [set]);

  const loadStatic = useCallback(async () => {
    apiGet<ServerStatus>('/api/status').then((s) => useDataStore.getState().setServer(s)).catch(() => undefined);
    set('airports', { status: 'loading' });
    airportService.markers().then(({ data, meta }) => set('airports', { data, meta, status: 'ok', updatedAt: Date.now() }))
      .catch((e) => set('airports', { status: 'error', error: errMsg(e) }));
    set('satellites', { status: 'loading' });
    satelliteService.list().then(({ data, meta }) => { setSatellites(data); set('satellites', { data, meta, status: 'ok', updatedAt: Date.now() }); })
      .catch((e) => set('satellites', { status: 'error', error: errMsg(e) }));
  }, [set]);

  useEffect(() => { void loadStatic(); void loadFlights(); }, [loadStatic, loadFlights, refreshNonce]);

  // Poll at the server's cache cadence (never faster than the provider allows).
  useEffect(() => {
    window.clearTimeout(timer.current);
    if (refreshMode === 'manual') return;
    const tick = () => {
      const ttl = useDataStore.getState().flights.meta?.ttlSec ?? 60;
      timer.current = window.setTimeout(async () => { if (!document.hidden) await loadFlights(); tick(); }, Math.max(15, ttl) * 1000);
    };
    tick();
    return () => window.clearTimeout(timer.current);
  }, [refreshMode, loadFlights]);

  useEffect(() => {
    const on = () => useDataStore.getState().setOnline(navigator.onLine);
    window.addEventListener('online', on); window.addEventListener('offline', on);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', on); };
  }, []);

  useEffect(() => { useDataStore.getState().setTracks(AC.list.length); }, []);
  return { reloadFlights: loadFlights, reloadAll: () => { void loadStatic(); void loadFlights(); } };
}
