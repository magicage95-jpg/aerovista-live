import { useCallback, useState } from 'react';
import { useAppStore } from '../stores/useAppStore';

/** Only asks for permission when the user presses "Locate me". Denial is a normal, non-fatal outcome. */
export function useGeolocation() {
  const [state, setState] = useState<'idle' | 'asking' | 'denied' | 'unavailable'>('idle');
  const setUserLocation = useAppStore((s) => s.setUserLocation);
  const flyTo = useAppStore((s) => s.flyTo);
  const locate = useCallback(() => {
    if (!('geolocation' in navigator)) { setState('unavailable'); return; }
    setState('asking');
    navigator.geolocation.getCurrentPosition(
      (p) => { setUserLocation({ lat: p.coords.latitude, lon: p.coords.longitude }); setState('idle'); flyTo(p.coords.latitude, p.coords.longitude, 1.5); },
      (e) => setState(e.code === e.PERMISSION_DENIED ? 'denied' : 'unavailable'),
      { enableHighAccuracy: false, timeout: 10_000, maximumAge: 300_000 },
    );
  }, [setUserLocation, flyTo]);
  return { state, locate };
}
