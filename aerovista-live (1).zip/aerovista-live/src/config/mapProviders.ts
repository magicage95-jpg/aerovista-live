export type BasemapId = 'standard' | 'satellite' | 'terrain' | 'dark';

export interface RasterBasemap {
  id: BasemapId;
  label: string;
  tiles: string[];
  tileSize: number;
  maxzoom: number;
  attribution: string;
  terms: string;
}

// Every basemap here is a documented, public tile service that requires attribution.
// Check each provider's usage policy before production traffic and swap URLs here if needed.
export const BASEMAPS: Record<BasemapId, RasterBasemap> = {
  standard: {
    id: 'standard', label: 'Standard', maxzoom: 19, tileSize: 256,
    tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
    attribution: '© OpenStreetMap contributors',
    terms: 'https://operations.osmfoundation.org/policies/tiles/',
  },
  satellite: {
    id: 'satellite', label: 'Satellite', maxzoom: 19, tileSize: 256,
    tiles: ['https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'],
    attribution: 'Tiles © Esri — Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community',
    terms: 'https://www.esri.com/en-us/legal/terms/full-master-agreement',
  },
  terrain: {
    id: 'terrain', label: 'Terrain', maxzoom: 17, tileSize: 256,
    tiles: ['https://a.tile.opentopomap.org/{z}/{x}/{y}.png', 'https://b.tile.opentopomap.org/{z}/{x}/{y}.png', 'https://c.tile.opentopomap.org/{z}/{x}/{y}.png'],
    attribution: '© OpenStreetMap contributors, SRTM | Style © OpenTopoMap (CC-BY-SA)',
    terms: 'https://opentopomap.org/about',
  },
  dark: {
    id: 'dark', label: 'Dark', maxzoom: 20, tileSize: 256,
    tiles: ['https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', 'https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png', 'https://c.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png'],
    attribution: '© OpenStreetMap contributors © CARTO',
    terms: 'https://carto.com/basemaps/',
  },
};

export const PROVIDERS_FOR_ABOUT = [
  { name: 'OpenSky Network', use: 'Global aircraft states', kind: 'LIVE', url: 'https://opensky-network.org', note: 'Research/non-commercial terms apply. Credentials raise limits.' },
  { name: 'adsb.lol', use: 'Regional aircraft fallback, registrations, community routes', kind: 'LIVE', url: 'https://adsb.lol', note: 'Open community data (ODbL).' },
  { name: 'AeroDataBox (RapidAPI)', use: 'Airport arrivals and departures', kind: 'LIVE', url: 'https://aerodatabox.com', note: 'Requires your own key. Plan limits apply.' },
  { name: 'CelesTrak', use: 'Satellite orbital elements', kind: 'PREDICTED', url: 'https://celestrak.org', note: 'Positions calculated with SGP4 in your browser.' },
  { name: 'Open-Meteo', use: 'Weather and place search', kind: 'LIVE', url: 'https://open-meteo.com', note: 'Free for non-commercial use (CC BY 4.0). Commercial use needs a key.' },
  { name: 'NASA GIBS', use: 'Blue Marble, Black Marble and daily true-colour imagery', kind: 'STATIC', url: 'https://earthdata.nasa.gov/gibs', note: 'Daily imagery is the previous day’s mosaic and has swath gaps.' },
  { name: 'OurAirports', use: 'Airport directory', kind: 'STATIC', url: 'https://ourairports.com', note: 'Public domain.' },
  { name: 'OpenStreetMap / Overpass', use: 'Standard map, nearby places', kind: 'STATIC', url: 'https://www.openstreetmap.org/copyright', note: '© OpenStreetMap contributors (ODbL).' },
  { name: 'Esri World Imagery', use: 'Satellite basemap (2D)', kind: 'STATIC', url: 'https://www.esri.com', note: 'Attribution required. Check Esri terms for your use.' },
  { name: 'OpenTopoMap', use: 'Terrain basemap (2D)', kind: 'STATIC', url: 'https://opentopomap.org', note: 'CC-BY-SA.' },
  { name: 'CARTO', use: 'Dark basemap (2D)', kind: 'STATIC', url: 'https://carto.com/basemaps', note: 'Attribution required.' },
  { name: 'RainViewer', use: 'Weather radar overlay (2D)', kind: 'LIVE', url: 'https://www.rainviewer.com', note: 'Attribution required. Check current terms.' },
  { name: 'Mapillary', use: 'Street-level imagery (optional)', kind: 'STATIC', url: 'https://www.mapillary.com', note: 'CC BY-SA. Coverage is not global.' },
  { name: 'Natural Earth (world-atlas)', use: 'Country boundaries', kind: 'STATIC', url: 'https://www.naturalearthdata.com', note: 'Public domain.' },
] as const;
