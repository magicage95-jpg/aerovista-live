// STATIC reference markers (largest metropolitan hubs). Not live data.
export const CITIES: { name: string; lat: number; lon: number }[] = [
  { name: 'New York', lat: 40.71, lon: -74.01 }, { name: 'Los Angeles', lat: 34.05, lon: -118.24 }, { name: 'Mexico City', lat: 19.43, lon: -99.13 },
  { name: 'São Paulo', lat: -23.55, lon: -46.63 }, { name: 'Buenos Aires', lat: -34.6, lon: -58.38 }, { name: 'Bogotá', lat: 4.71, lon: -74.07 },
  { name: 'London', lat: 51.51, lon: -0.13 }, { name: 'Paris', lat: 48.86, lon: 2.35 }, { name: 'Madrid', lat: 40.42, lon: -3.7 },
  { name: 'Berlin', lat: 52.52, lon: 13.4 }, { name: 'Istanbul', lat: 41.01, lon: 28.98 }, { name: 'Moscow', lat: 55.76, lon: 37.62 },
  { name: 'Cairo', lat: 30.04, lon: 31.24 }, { name: 'Lagos', lat: 6.52, lon: 3.38 }, { name: 'Nairobi', lat: -1.29, lon: 36.82 },
  { name: 'Johannesburg', lat: -26.2, lon: 28.05 }, { name: 'Dubai', lat: 25.2, lon: 55.27 }, { name: 'Mumbai', lat: 19.08, lon: 72.88 },
  { name: 'Delhi', lat: 28.61, lon: 77.21 }, { name: 'Bangkok', lat: 13.76, lon: 100.5 }, { name: 'Singapore', lat: 1.35, lon: 103.82 },
  { name: 'Jakarta', lat: -6.21, lon: 106.85 }, { name: 'Hong Kong', lat: 22.32, lon: 114.17 }, { name: 'Shanghai', lat: 31.23, lon: 121.47 },
  { name: 'Beijing', lat: 39.9, lon: 116.41 }, { name: 'Seoul', lat: 37.57, lon: 126.98 }, { name: 'Tokyo', lat: 35.68, lon: 139.69 },
  { name: 'Sydney', lat: -33.87, lon: 151.21 }, { name: 'Auckland', lat: -36.85, lon: 174.76 }, { name: 'Toronto', lat: 43.65, lon: -79.38 },
];
