const base = (import.meta.env.VITE_API_BASE as string | undefined) ?? '';
/** Empty string means same origin (the Express server serves the built app, or Vite proxies /api in dev). */
export const API_BASE = base.replace(/\/$/, '');
