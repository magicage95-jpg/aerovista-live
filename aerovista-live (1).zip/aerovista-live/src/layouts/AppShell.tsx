import { lazy, Suspense, useEffect } from 'react';
import { useAppStore } from '../stores/useAppStore';
import { useIsMobile } from '../hooks/useMediaQuery';
import { nudge, zoomBy } from '../runtime/camera';
import TopBar from '../components/ui/TopBar';
import LayerRail from '../components/ui/LayerRail';
import MapControls from '../components/ui/MapControls';
import Hud from '../components/ui/Hud';
import StatsBar from '../components/ui/StatsBar';
import SettingsModal from '../components/ui/SettingsModal';
import BootSequence from '../components/ui/BootSequence';
import BottomSheet from '../components/ui/BottomSheet';
import RightContent from '../components/ui/RightContent';
import Banners from '../components/ui/Banners';
import { Skeleton } from '../components/ui/States';

const Globe = lazy(() => import('../components/globe/Globe'));
const FlatMap = lazy(() => import('../components/map/FlatMap'));

export default function AppShell() {
  const map = useAppStore((s) => s.settings.map);
  const selection = useAppStore((s) => s.selection);
  const mobile = useIsMobile();

  useEffect(() => { document.title = selection ? 'AEROVISTA LIVE · tracking' : 'AEROVISTA LIVE'; }, [selection]);

  const onKey = (e: React.KeyboardEvent) => {
    if (map !== '3d') return;
    const k = e.key;
    if (k === 'ArrowLeft') nudge(0, -8); else if (k === 'ArrowRight') nudge(0, 8);
    else if (k === 'ArrowUp') nudge(6, 0); else if (k === 'ArrowDown') nudge(-6, 0);
    else if (k === '+' || k === '=') zoomBy(0.8); else if (k === '-') zoomBy(1.25);
    else return;
    e.preventDefault();
  };

  return (
    <div className="app">
      <Banners />
      <TopBar />
      <main className="stage" tabIndex={0} onKeyDown={onKey} aria-label={map === '3d' ? '3D Earth. Use arrow keys to rotate, plus and minus to zoom.' : '2D map'}>
        <Suspense fallback={<div className="stage-loading"><Skeleton lines={3} /></div>}>
          {map === '3d' ? <Globe /> : <FlatMap />}
        </Suspense>
        <div className="vignette" aria-hidden />
        <div className="scanlines" aria-hidden />
      </main>
      <LayerRail />
      <MapControls />
      <Hud />
      <StatsBar />
      {mobile ? <BottomSheet><RightContent /></BottomSheet> : <aside className="right glass" aria-label="Selected object"><RightContent /></aside>}
      <SettingsModal />
      <BootSequence />
      <div className="sr-only" aria-live="polite">{selection ? `Selected ${selection.type}` : 'Nothing selected'}</div>
    </div>
  );
}
