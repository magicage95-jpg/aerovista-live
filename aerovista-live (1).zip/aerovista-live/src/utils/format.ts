export type SpeedUnit = 'kmh' | 'kt';
export type AltUnit = 'ft' | 'm';
export type TimeMode = 'local' | 'utc';

const dash = '—';
export const fmtAlt = (m: number | null | undefined, u: AltUnit) =>
  m == null ? dash : u === 'ft' ? `${Math.round(m * 3.28084).toLocaleString()} ft` : `${Math.round(m).toLocaleString()} m`;
export const fmtSpeed = (ms: number | null | undefined, u: SpeedUnit) =>
  ms == null ? dash : u === 'kt' ? `${Math.round(ms * 1.943844)} kt` : `${Math.round(ms * 3.6)} km/h`;
export const fmtVs = (ms: number | null | undefined, u: AltUnit) =>
  ms == null ? dash : u === 'ft' ? `${Math.round(ms * 196.85).toLocaleString()} ft/min` : `${ms.toFixed(1)} m/s`;
export const fmtHeading = (h: number | null | undefined) => (h == null ? dash : `${Math.round(h)}°`);
export const fmtKm = (m: number) => `${Math.round(m / 1000).toLocaleString()} km`;
export const fmtCoord = (lat: number, lon: number) =>
  `${Math.abs(lat).toFixed(3)}°${lat >= 0 ? 'N' : 'S'}  ${Math.abs(lon).toFixed(3)}°${lon >= 0 ? 'E' : 'W'}`;

const pad = (n: number) => String(n).padStart(2, '0');
export function fmtClock(ts: number | string | Date, mode: TimeMode, withSeconds = true) {
  const d = new Date(ts);
  if (isNaN(d.getTime())) return dash;
  const h = mode === 'utc' ? d.getUTCHours() : d.getHours();
  const m = mode === 'utc' ? d.getUTCMinutes() : d.getMinutes();
  const s = mode === 'utc' ? d.getUTCSeconds() : d.getSeconds();
  return `${pad(h)}:${pad(m)}${withSeconds ? ':' + pad(s) : ''}${mode === 'utc' ? ' UTC' : ''}`;
}
export function fmtDuration(sec: number) {
  if (!isFinite(sec) || sec < 0) return dash;
  const h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
  return h > 0 ? `${h} h ${m} min` : `${m} min`;
}
export function fmtAgo(tsMs: number, nowMs = Date.now()) {
  const s = Math.max(0, Math.round((nowMs - tsMs) / 1000));
  if (s < 5) return 'just now';
  if (s < 90) return `${s}s ago`;
  if (s < 5400) return `${Math.round(s / 60)} min ago`;
  return `${Math.round(s / 3600)} h ago`;
}
export const compassPoint = (d: number) =>
  ['N', 'NNE', 'NE', 'ENE', 'E', 'ESE', 'SE', 'SSE', 'S', 'SSW', 'SW', 'WSW', 'W', 'WNW', 'NW', 'NNW'][Math.round(d / 22.5) % 16];
