export const EARTH_R_M = 6371008.8;
export const rad = (d: number) => (d * Math.PI) / 180;
export const deg = (r: number) => (r * 180) / Math.PI;
export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const wrapLon = (l: number) => ((((l + 180) % 360) + 360) % 360) - 180;

export function haversineM(lat1: number, lon1: number, lat2: number, lon2: number) {
  const p1 = rad(lat1), p2 = rad(lat2);
  const dp = p2 - p1, dl = rad(lon2 - lon1);
  const a = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 2 * EARTH_R_M * Math.asin(Math.min(1, Math.sqrt(a)));
}

export function bearingDeg(lat1: number, lon1: number, lat2: number, lon2: number) {
  const p1 = rad(lat1), p2 = rad(lat2), dl = rad(lon2 - lon1);
  const y = Math.sin(dl) * Math.cos(p2);
  const x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
  return (deg(Math.atan2(y, x)) + 360) % 360;
}

export function destination(lat: number, lon: number, brgDeg: number, distM: number) {
  const d = distM / EARTH_R_M, b = rad(brgDeg), p1 = rad(lat), l1 = rad(lon);
  const p2 = Math.asin(Math.sin(p1) * Math.cos(d) + Math.cos(p1) * Math.sin(d) * Math.cos(b));
  const l2 = l1 + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(p1), Math.cos(d) - Math.sin(p1) * Math.sin(p2));
  return { lat: deg(p2), lon: wrapLon(deg(l2)) };
}

/** Point at fraction f (0..1) along the great circle between two points. */
export function intermediate(lat1: number, lon1: number, lat2: number, lon2: number, f: number) {
  const p1 = rad(lat1), l1 = rad(lon1), p2 = rad(lat2), l2 = rad(lon2);
  const d = haversineM(lat1, lon1, lat2, lon2) / EARTH_R_M;
  if (d < 1e-9) return { lat: lat1, lon: lon1 };
  const a = Math.sin((1 - f) * d) / Math.sin(d), b = Math.sin(f * d) / Math.sin(d);
  const x = a * Math.cos(p1) * Math.cos(l1) + b * Math.cos(p2) * Math.cos(l2);
  const y = a * Math.cos(p1) * Math.sin(l1) + b * Math.cos(p2) * Math.sin(l2);
  const z = a * Math.sin(p1) + b * Math.sin(p2);
  return { lat: deg(Math.atan2(z, Math.hypot(x, y))), lon: deg(Math.atan2(y, x)) };
}

/**
 * Scene coordinates. The globe is fixed in an Earth-centred frame, matching three.js SphereGeometry UVs
 * for an equirectangular texture: lon 0 -> +X, lon 90E -> -Z, north -> +Y.
 */
export function latLonToXYZ(lat: number, lon: number, r = 1): [number, number, number] {
  const p = rad(lat), l = rad(lon), c = Math.cos(p);
  return [r * c * Math.cos(l), r * Math.sin(p), -r * c * Math.sin(l)];
}
export function xyzToLatLon(x: number, y: number, z: number) {
  const r = Math.hypot(x, y, z) || 1;
  return { lat: deg(Math.asin(clamp(y / r, -1, 1))), lon: deg(Math.atan2(-z, x)) };
}
