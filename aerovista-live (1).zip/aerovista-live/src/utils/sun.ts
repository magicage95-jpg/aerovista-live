import { rad, deg, wrapLon } from './geo';

const jd = (d: Date) => d.getTime() / 86400000 + 2440587.5;

/** Sub-solar point (low-precision Astronomical Almanac algorithm, ~0.01 degree). */
export function sunSubpoint(date: Date) {
  const n = jd(date) - 2451545.0;
  const L = (280.46 + 0.9856474 * n) % 360;
  const g = rad((357.528 + 0.9856003 * n) % 360);
  const lam = rad(L + 1.915 * Math.sin(g) + 0.02 * Math.sin(2 * g));
  const eps = rad(23.439 - 0.0000004 * n);
  const ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam));
  const dec = Math.asin(Math.sin(eps) * Math.sin(lam));
  const gmst = (((18.697374558 + 24.06570982441908 * n) % 24) + 24) % 24; // hours
  const lon = wrapLon(deg(ra) - gmst * 15);
  return { lat: deg(dec), lon };
}

/** Sun elevation in degrees for an observer on the ground. */
export function sunElevationDeg(date: Date, lat: number, lon: number) {
  const s = sunSubpoint(date);
  const p = rad(lat), d = rad(s.lat), h = rad(lon - s.lon);
  return deg(Math.asin(Math.sin(p) * Math.sin(d) + Math.cos(p) * Math.cos(d) * Math.cos(h)));
}

/** Unit vector toward the sun in Earth-fixed (ECEF) axes: x->lon0, y->lon90E, z->north. */
export function sunEcef(date: Date): [number, number, number] {
  const s = sunSubpoint(date);
  const p = rad(s.lat), l = rad(s.lon);
  return [Math.cos(p) * Math.cos(l), Math.cos(p) * Math.sin(l), Math.sin(p)];
}
