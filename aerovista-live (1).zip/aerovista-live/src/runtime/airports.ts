import type { AirportBrief } from '../types';
import { latLonToXYZ } from '../utils/geo';

export const AP = { list: [] as AirportBrief[], xyz: new Float32Array(0) };
export function setAirportsXYZ(list: AirportBrief[]) {
  AP.list = list;
  AP.xyz = new Float32Array(list.length * 3);
  list.forEach((a, i) => { const [x, y, z] = latLonToXYZ(a.lat, a.lon, 1.003); AP.xyz.set([x, y, z], i * 3); });
}
