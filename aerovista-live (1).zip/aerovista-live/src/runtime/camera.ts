/** Imperative camera commands issued by UI buttons / keyboard and consumed each frame. */
export const camCmd = { dLat: 0, dLon: 0, zoom: 1, reset: false };
export const DEFAULT_VIEW = { lat: 22, lon: 12, distance: 3.3 };

/** The 2D map registers itself here so the same buttons work in both modes. */
export const flat: { map: { zoomTo(z: number): void; getZoom(): number; flyTo(o: object): void } | null } = { map: null };

/** Live camera readouts for the HUD (written by CameraRig / FlatMap, polled by the UI). */
export const hud = { lat: DEFAULT_VIEW.lat, lon: DEFAULT_VIEW.lon, altKm: (DEFAULT_VIEW.distance - 1) * 6371, kmPerPx: 0, mode: '3d' as '3d' | '2d', zoom: 2, handoff: false };
export const globeFlags = { ready: false };

export const nudge = (dLat: number, dLon: number) => { camCmd.dLat += dLat; camCmd.dLon += dLon; };
export const zoomBy = (f: number) => {
  if (flat.map) flat.map.zoomTo(flat.map.getZoom() + Math.log2(1 / f));
  else camCmd.zoom *= f;
};
export const resetView = () => {
  if (flat.map) flat.map.flyTo({ center: [DEFAULT_VIEW.lon, DEFAULT_VIEW.lat], zoom: 2, duration: 800 });
  else camCmd.reset = true;
};
/** Map camera distance (globe units from centre) to a web-map zoom level. */
export const distanceToZoom = (d: number) => Math.max(2, Math.min(16, 11 - Math.log2(Math.max(5, (d - 1) * 6371) / 50)));
/** Inverse of distanceToZoom: used when switching from the 2D map back to the globe. */
export const zoomToDistance = (z: number) => Math.min(DEFAULT_VIEW.distance, Math.max(1.06, 1 + (50 * Math.pow(2, 11 - z)) / 6371));
