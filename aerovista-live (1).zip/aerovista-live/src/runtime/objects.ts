import { aircraftLatLon } from './aircraft';
import { SATS, llaAt, EARTH_RADIUS_KM } from './satellites';
import { useDataStore } from '../stores/useDataStore';
import type { Selection } from '../stores/useAppStore';

export interface ObjPos { lat: number; lon: number; radius: number }

/** Current scene position for any selection (used by camera follow, markers and panels). */
export function positionOf(sel: Selection, now = new Date()): ObjPos | null {
  if (!sel) return null;
  switch (sel.type) {
    case 'flight': {
      const p = aircraftLatLon(sel.id, now.getTime() / 1000);
      return p ? { ...p, radius: 1.004 } : null;
    }
    case 'satellite': {
      const rec = SATS.byId.get(sel.id);
      const s = rec && llaAt(rec, now);
      return s ? { lat: s.lat, lon: s.lon, radius: 1 + s.altKm / EARTH_RADIUS_KM } : null;
    }
    case 'airport': {
      const a = useDataStore.getState().airports.data.find((x) => x.icao === sel.icao);
      return a ? { lat: a.lat, lon: a.lon, radius: 1.002 } : null;
    }
    case 'location': return { lat: sel.lat, lon: sel.lon, radius: 1.002 };
  }
}
