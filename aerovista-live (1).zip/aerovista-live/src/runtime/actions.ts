import { useAppStore, type Selection } from '../stores/useAppStore';
import { useDataStore } from '../stores/useDataStore';
import { positionOf } from './objects';

const DIST = { flight: 1.7, satellite: 2.2, airport: 1.12, location: 1.08 } as const;

/** Select an object and fly the camera to it. */
export function selectAndFly(sel: Exclude<Selection, null>, at?: { lat: number; lon: number }) {
  const st = useAppStore.getState();
  st.select(sel);
  const p = at ?? positionOf(sel);
  if (p) {
    const radius = 'radius' in p ? (p as { radius: number }).radius : 1;
    st.flyTo(p.lat, p.lon, DIST[sel.type] + (sel.type === 'satellite' ? Math.max(0, radius - 1) : 0));
  }
}

export function selectAirport(icao: string) {
  const a = useDataStore.getState().airports.data.find((x) => x.icao === icao);
  selectAndFly({ type: 'airport', icao }, a ? { lat: a.lat, lon: a.lon } : undefined);
}

/** Globe -> city -> map: zoom the globe in, then hand over to the satellite map and keep descending. */
export function exploreLocation(lat: number, lon: number) {
  const st = useAppStore.getState();
  const reduced = st.settings.motion === 'reduced';
  st.flyTo(lat, lon, 1.06);
  window.setTimeout(() => {
    const s = useAppStore.getState();
    s.setBasemap('satellite');
    s.setSettings({ map: '2d' });
    window.setTimeout(() => useAppStore.getState().flyTo(lat, lon, 1.001), 150);
  }, reduced ? 0 : 1300);
}
