import type { Aircraft, AircraftCategory } from '../types';
import { destination, wrapLon } from '../utils/geo';

export const CATEGORY_COLORS: Record<AircraftCategory, string> = {
  airliner: '#ffc15e', cargo: '#ff8f66', helicopter: '#8fe388', general: '#c3b5ff', military: '#ff6b6b', unknown: '#a9b6cf',
};
const MAX_EXTRAPOLATE_S = 900;
const M_PER_DEG = 111_195;

/**
 * Shared, non-reactive aircraft state. Render loops read this directly each frame,
 * so 10k aircraft never touch React state or the DOM.
 */
export const AC = {
  list: [] as Aircraft[],
  index: new Map<string, number>(),
  lat: new Float64Array(0), lon: new Float64Array(0),
  offLat: new Float32Array(0), offLon: new Float32Array(0),
  version: 0,
};

function extrap(a: Aircraft, nowS: number): { lat: number; lon: number } {
  if (a.onGround || a.speedMs == null || a.headingDeg == null) return { lat: a.lat, lon: a.lon };
  const dt = Math.min(Math.max(nowS - a.positionAt, 0), MAX_EXTRAPOLATE_S);
  if (dt < 0.5 || a.speedMs < 5) return { lat: a.lat, lon: a.lon };
  const h = (a.headingDeg * Math.PI) / 180, d = a.speedMs * dt;
  const lat = a.lat + (d * Math.cos(h)) / M_PER_DEG;
  const lon = a.lon + (d * Math.sin(h)) / (M_PER_DEG * Math.max(0.05, Math.cos((a.lat * Math.PI) / 180)));
  return { lat: Math.max(-89.9, Math.min(89.9, lat)), lon: wrapLon(lon) };
}

/** Rendered position of aircraft i (extrapolated + blending offset). */
export function renderPos(i: number, nowS: number, out: { lat: number; lon: number }) {
  const e = extrap(AC.list[i], nowS);
  out.lat = e.lat + AC.offLat[i];
  out.lon = e.lon + AC.offLon[i];
}

/** Replace the aircraft list; positions blend smoothly from where aircraft are currently drawn. */
export function setAircraft(list: Aircraft[]) {
  const nowS = Date.now() / 1000;
  const prev = { list: AC.list, index: AC.index };
  const n = list.length;
  const offLat = new Float32Array(n), offLon = new Float32Array(n);
  const index = new Map<string, number>();
  const tmp = { lat: 0, lon: 0 };
  for (let i = 0; i < n; i++) {
    const a = list[i];
    index.set(a.id, i);
    const j = prev.index.get(a.id);
    if (j !== undefined) {
      renderPos(j, nowS, tmp);
      const ne = extrap(a, nowS);
      const dLat = tmp.lat - ne.lat;
      let dLon = tmp.lon - ne.lon;
      if (dLon > 180) dLon -= 360; else if (dLon < -180) dLon += 360;
      if (Math.abs(dLat) < 1.5 && Math.abs(dLon) < 1.5) { offLat[i] = dLat; offLon[i] = dLon; }
    }
  }
  AC.list = list; AC.index = index; AC.offLat = offLat; AC.offLon = offLon;
  AC.lat = new Float64Array(n); AC.lon = new Float64Array(n);
  AC.version++;
}

/** Exponentially decay blend offsets (call once per frame). */
export function decayOffsets(dtSec: number) {
  const k = Math.exp(-dtSec / 1.4);
  const a = AC.offLat, b = AC.offLon;
  for (let i = 0; i < a.length; i++) { a[i] *= k; b[i] *= k; }
}

export function aircraftLatLon(id: string, nowS = Date.now() / 1000) {
  const i = AC.index.get(id);
  if (i === undefined) return null;
  const o = { lat: 0, lon: 0 };
  renderPos(i, nowS, o);
  return o;
}

export function projectAhead(a: Aircraft, seconds: number) {
  if (a.speedMs == null || a.headingDeg == null) return { lat: a.lat, lon: a.lon };
  return destination(a.lat, a.lon, a.headingDeg, a.speedMs * seconds);
}

/** Position history for selected / tracked aircraft. */
export const TRAILS = new Map<string, { lat: number; lon: number; alt: number; t: number }[]>();
export function pushTrail(id: string, lat: number, lon: number, alt: number, t: number) {
  let tr = TRAILS.get(id);
  if (!tr) { tr = []; TRAILS.set(id, tr); }
  const last = tr[tr.length - 1];
  if (last && Math.abs(last.lat - lat) < 1e-4 && Math.abs(last.lon - lon) < 1e-4) return;
  tr.push({ lat, lon, alt, t });
  if (tr.length > 400) tr.shift();
}
