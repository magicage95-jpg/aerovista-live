import * as sat from 'satellite.js';
import type { SatCategory, SatTle } from '../types';
import { deg, rad } from '../utils/geo';
import { sunEcef, sunElevationDeg } from '../utils/sun';

export interface SatRec { noradId: number; name: string; category: SatCategory; satrec: any }
export const SATS = {
  all: [] as SatRec[],
  byId: new Map<number, SatRec>(),
  visible: [] as SatRec[],
  pos: new Float32Array(0), // lat, lon, altKm triples for visible satellites
  version: 0,
};
export const ISS_ID = 25544;
export const EARTH_RADIUS_KM = 6371;

export function setSatellites(tles: SatTle[]) {
  const all: SatRec[] = [];
  for (const t of tles) {
    try {
      const satrec = sat.twoline2satrec(t.line1, t.line2);
      if (satrec && !satrec.error) all.push({ noradId: t.noradId, name: t.name, category: t.category, satrec });
    } catch { /* skip malformed element sets */ }
  }
  SATS.all = all;
  SATS.byId = new Map(all.map((s) => [s.noradId, s]));
  setSatFilter('all');
}

export function setSatFilter(cat: 'all' | SatCategory) {
  SATS.visible = cat === 'all' ? SATS.all : SATS.all.filter((s) => s.category === cat);
  SATS.pos = new Float32Array(SATS.visible.length * 3);
  SATS.version++;
}

export interface Lla { lat: number; lon: number; altKm: number }
export function llaAt(rec: SatRec, date: Date): Lla | null {
  const pv = sat.propagate(rec.satrec, date);
  if (!pv || !pv.position || typeof pv.position === 'boolean') return null;
  const gd = sat.eciToGeodetic(pv.position, sat.gstime(date));
  const lat = deg(gd.latitude), lon = deg(gd.longitude);
  if (!isFinite(lat) || !isFinite(lon)) return null;
  return { lat, lon, altKm: gd.height };
}

export function updatePositions(date: Date) {
  const v = SATS.visible, p = SATS.pos;
  for (let i = 0; i < v.length; i++) {
    const s = llaAt(v[i], date);
    if (s) { p[i * 3] = s.lat; p[i * 3 + 1] = s.lon; p[i * 3 + 2] = s.altKm; } else { p[i * 3 + 2] = -1; }
  }
}

export interface SatState extends Lla { velKms: number; sunlit: boolean }
export function stateAt(rec: SatRec, date: Date): SatState | null {
  const pv = sat.propagate(rec.satrec, date);
  if (!pv || !pv.position || typeof pv.position === 'boolean') return null;
  const gmst = sat.gstime(date);
  const gd = sat.eciToGeodetic(pv.position, gmst);
  const ecf = sat.eciToEcf(pv.position, gmst);
  const v = pv.velocity as { x: number; y: number; z: number };
  return {
    lat: deg(gd.latitude), lon: deg(gd.longitude), altKm: gd.height,
    velKms: v ? Math.hypot(v.x, v.y, v.z) : NaN,
    sunlit: isSunlit([ecf.x, ecf.y, ecf.z], date),
  };
}

/** Cylindrical Earth-shadow test in Earth-fixed axes. */
function isSunlit(p: [number, number, number], date: Date) {
  const s = sunEcef(date);
  const d = p[0] * s[0] + p[1] * s[1] + p[2] * s[2];
  if (d > 0) return true;
  const perp = Math.hypot(p[0] - d * s[0], p[1] - d * s[1], p[2] - d * s[2]);
  return perp > 6371;
}

export function groundTrack(rec: SatRec, from: Date, minutes: number, steps: number): Lla[] {
  const out: Lla[] = [];
  for (let i = 0; i <= steps; i++) {
    const s = llaAt(rec, new Date(from.getTime() + (i / steps) * minutes * 60_000));
    if (s) out.push(s);
  }
  return out;
}

export interface OrbitInfo { periodMin: number; inclinationDeg: number; apogeeKm: number; perigeeKm: number; epoch: Date; ageDays: number }
export function orbitInfo(rec: SatRec): OrbitInfo {
  const n = rec.satrec.no / 60; // rad/s
  const a = Math.cbrt(398600.4418 / (n * n)); // km
  const e = rec.satrec.ecco;
  const epoch = new Date((rec.satrec.jdsatepoch - 2440587.5) * 86400000);
  return {
    periodMin: (2 * Math.PI) / rec.satrec.no, inclinationDeg: deg(rec.satrec.inclo),
    apogeeKm: a * (1 + e) - 6378.137, perigeeKm: a * (1 - e) - 6378.137,
    epoch, ageDays: (Date.now() - epoch.getTime()) / 86400000,
  };
}

export interface Pass { start: number; end: number; peak: number; maxElDeg: number; visible: boolean }
/** First pass above 10 degrees in the next `hours`. "Visible" = sunlit satellite while the observer's sun is below -6 degrees. */
export function nextPass(rec: SatRec, lat: number, lon: number, from = new Date(), hours = 36): Pass | null {
  const obs = { latitude: rad(lat), longitude: rad(lon), height: 0 };
  const step = 30_000, t0 = from.getTime(), t1 = t0 + hours * 3600_000;
  let inPass = false, start = 0, maxEl = -90, peak = 0;
  for (let t = t0; t <= t1; t += step) {
    const d = new Date(t);
    const pv = sat.propagate(rec.satrec, d);
    if (!pv || !pv.position || typeof pv.position === 'boolean') continue;
    const ecf = sat.eciToEcf(pv.position, sat.gstime(d));
    const el = deg(sat.ecfToLookAngles(obs, ecf).elevation);
    if (el > 0) {
      if (!inPass) { inPass = true; start = t; maxEl = el; peak = t; }
      else if (el > maxEl) { maxEl = el; peak = t; }
    } else if (inPass) {
      if (maxEl >= 10) return finish(rec, lat, lon, start, t, peak, maxEl);
      inPass = false;
    }
  }
  return inPass && maxEl >= 10 ? finish(rec, lat, lon, start, t1, peak, maxEl) : null;
}
function finish(rec: SatRec, lat: number, lon: number, start: number, end: number, peak: number, maxElDeg: number): Pass {
  const d = new Date(peak);
  const st = stateAt(rec, d);
  return { start, end, peak, maxElDeg, visible: Boolean(st?.sunlit) && sunElevationDeg(d, lat, lon) < -6 };
}
