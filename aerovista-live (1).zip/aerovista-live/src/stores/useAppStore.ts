import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { SatCategory } from '../types';
import type { BasemapId } from '../config/mapProviders';
import type { AltUnit, SpeedUnit, TimeMode } from '../utils/format';

export type Mode = 'live' | 'flights' | 'airports' | 'satellites' | 'earth' | 'weather' | 'map';
export type Page = 'explorer' | 'about';
export type Selection =
  | { type: 'flight'; id: string }
  | { type: 'satellite'; id: number }
  | { type: 'airport'; icao: string }
  | { type: 'location'; lat: number; lon: number; name?: string }
  | null;

export interface Layers { aircraft: boolean; satellites: boolean; airports: boolean; weather: boolean; borders: boolean; cities: boolean; trails: boolean; orbits: boolean }
export interface Settings {
  speedUnit: SpeedUnit; altUnit: AltUnit; time: TimeMode; map: '3d' | '2d';
  motion: 'full' | 'reduced'; theme: 'dark' | 'light'; refresh: 'auto' | 'manual';
}
export interface FlyRequest { lat: number; lon: number; distance: number; nonce: number }
export type SatFilter = 'all' | SatCategory;

const base: Layers = { aircraft: true, satellites: false, airports: true, weather: false, borders: true, cities: false, trails: true, orbits: true };
export const MODE_PRESETS: Record<Mode, Partial<Layers>> = {
  live: { aircraft: true, satellites: true, airports: true, weather: false, cities: false },
  flights: { aircraft: true, satellites: false, airports: false, weather: false, cities: false },
  airports: { aircraft: true, satellites: false, airports: true, weather: false, cities: false },
  satellites: { aircraft: false, satellites: true, airports: false, weather: false, cities: false },
  earth: { aircraft: false, satellites: false, airports: false, weather: false, cities: true },
  weather: { aircraft: false, satellites: false, airports: true, weather: true, cities: true },
  map: { aircraft: true, satellites: false, airports: true, weather: false, cities: false },
};

const prefersReduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

interface AppState {
  page: Page; mode: Mode; layers: Layers; basemap: BasemapId; settings: Settings;
  selection: Selection; follow: boolean; fly: FlyRequest | null;
  satFilter: SatFilter; userLocation: { lat: number; lon: number } | null; sheet: 'peek' | 'half' | 'full' | 'closed';
  refreshNonce: number;
  setPage(p: Page): void; setMode(m: Mode): void; toggleLayer(k: keyof Layers): void; setBasemap(b: BasemapId): void;
  setSettings(p: Partial<Settings>): void; select(s: Selection): void; setFollow(f: boolean): void;
  flyTo(lat: number, lon: number, distance?: number): void; setSatFilter(f: SatFilter): void;
  setUserLocation(l: { lat: number; lon: number } | null): void; setSheet(s: AppState['sheet']): void; refreshNow(): void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      page: 'explorer', mode: 'live', layers: { ...base, ...MODE_PRESETS.live }, basemap: 'dark',
      settings: { speedUnit: 'kmh', altUnit: 'ft', time: 'utc', map: '3d', motion: prefersReduced ? 'reduced' : 'full', theme: 'dark', refresh: 'auto' },
      selection: null, follow: false, fly: null, satFilter: 'all', userLocation: null, sheet: 'peek', refreshNonce: 0,
      setPage: (page) => set({ page }),
      setMode: (mode) => set((s) => ({
        mode, layers: { ...s.layers, ...MODE_PRESETS[mode] },
        settings: { ...s.settings, map: mode === 'map' ? '2d' : s.mode === 'map' ? '3d' : s.settings.map },
        selection: null, follow: false, sheet: 'peek',
      })),
      toggleLayer: (k) => set((s) => ({ layers: { ...s.layers, [k]: !s.layers[k] } })),
      setBasemap: (basemap) => set({ basemap }),
      setSettings: (p) => set((s) => ({ settings: { ...s.settings, ...p } })),
      select: (selection) => set({ selection, follow: false, sheet: selection ? 'half' : 'peek' }),
      setFollow: (follow) => set({ follow }),
      flyTo: (lat, lon, distance = 1.6) => set({ fly: { lat, lon, distance, nonce: (get().fly?.nonce ?? 0) + 1 } }),
      setSatFilter: (satFilter) => set({ satFilter }),
      setUserLocation: (userLocation) => set({ userLocation }),
      setSheet: (sheet) => set({ sheet }),
      refreshNow: () => set((s) => ({ refreshNonce: s.refreshNonce + 1 })),
    }),
    {
      name: 'aerovista-settings-v1',
      partialize: (s) => ({ settings: s.settings, basemap: s.basemap }),
    },
  ),
);

export const isReducedMotion = () => useAppStore.getState().settings.motion === 'reduced';
