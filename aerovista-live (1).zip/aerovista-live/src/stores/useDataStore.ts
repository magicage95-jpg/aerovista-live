import { create } from 'zustand';
import type { Aircraft, AirportBrief, SatTle, ServerStatus, SourceMeta } from '../types';

export type Status = 'idle' | 'loading' | 'ok' | 'error';
export interface Slice<T> { data: T; meta?: SourceMeta; status: Status; error?: string; updatedAt?: number }

interface DataState {
  flights: Slice<Aircraft[]>;
  satellites: Slice<SatTle[]>;
  airports: Slice<AirportBrief[]>;
  server: ServerStatus | null;
  online: boolean;
  tracks: number;
  set<K extends 'flights' | 'satellites' | 'airports'>(key: K, patch: Partial<DataState[K]>): void;
  setServer(s: ServerStatus | null): void;
  setOnline(o: boolean): void;
  setTracks(n: number): void;
}

const empty = <T,>(data: T): Slice<T> => ({ data, status: 'idle' });

export const useDataStore = create<DataState>((set) => ({
  flights: empty<Aircraft[]>([]),
  satellites: empty<SatTle[]>([]),
  airports: empty<AirportBrief[]>([]),
  server: null, online: true, tracks: 0,
  set: (key, patch) => set((s) => ({ [key]: { ...s[key], ...patch } }) as Partial<DataState>),
  setServer: (server) => set({ server }),
  setOnline: (online) => set({ online }),
  setTracks: (tracks) => set({ tracks }),
}));
