import { create } from 'zustand';
import type { FlightDetail } from '../types';

/** Enrichment for the currently selected flight (shared by the panel and the 3D route arc). */
export const useSelectionStore = create<{ flightDetail: FlightDetail | null; setFlightDetail(d: FlightDetail | null): void }>((set) => ({
  flightDetail: null,
  setFlightDetail: (flightDetail) => set({ flightDetail }),
}));
