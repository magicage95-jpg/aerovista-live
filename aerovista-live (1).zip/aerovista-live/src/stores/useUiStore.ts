import { create } from 'zustand';
export const useUiStore = create<{
  booted: boolean; globeReady: boolean; settingsOpen: boolean; layersOpen: boolean; searchOpen: boolean;
  set(p: Partial<{ booted: boolean; globeReady: boolean; settingsOpen: boolean; layersOpen: boolean; searchOpen: boolean }>): void;
}>((set) => ({ booted: false, globeReady: false, settingsOpen: false, layersOpen: false, searchOpen: false, set: (p) => set(p) }));
