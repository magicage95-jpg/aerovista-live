import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { useAppStore, type Settings } from '../../stores/useAppStore';
import { useUiStore } from '../../stores/useUiStore';

function Seg<K extends keyof Settings>({ label, k, opts }: { label: string; k: K; opts: [Settings[K], string][] }) {
  const { settings, setSettings } = useAppStore();
  return (
    <div className="field" role="radiogroup" aria-label={label}>
      <span className="field-label">{label}</span>
      <div className="seg">
        {opts.map(([v, l]) => (
          <button key={String(v)} role="radio" aria-checked={settings[k] === v} className={settings[k] === v ? 'on' : ''} onClick={() => setSettings({ [k]: v } as Partial<Settings>)}>{l}</button>
        ))}
      </div>
    </div>
  );
}

export default function SettingsModal() {
  const open = useUiStore((s) => s.settingsOpen);
  const setUi = useUiStore((s) => s.set);
  const refreshNow = useAppStore((s) => s.refreshNow);
  const refresh = useAppStore((s) => s.settings.refresh);
  const closeRef = useRef<HTMLButtonElement>(null);
  const prev = useRef<Element | null>(null);

  useEffect(() => {
    if (!open) return;
    prev.current = document.activeElement;
    closeRef.current?.focus();
    const key = (e: KeyboardEvent) => { if (e.key === 'Escape') setUi({ settingsOpen: false }); };
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('keydown', key); (prev.current as HTMLElement | null)?.focus?.(); };
  }, [open, setUi]);

  if (!open) return null;
  return (
    <div className="scrim" onClick={() => setUi({ settingsOpen: false })}>
      <div className="modal glass" role="dialog" aria-modal="true" aria-labelledby="settings-title" onClick={(e) => e.stopPropagation()}>
        <header className="panel-head"><h2 id="settings-title">Settings</h2><button ref={closeRef} className="icon-btn" onClick={() => setUi({ settingsOpen: false })} aria-label="Close settings"><X size={18} /></button></header>
        <Seg label="Speed" k="speedUnit" opts={[['kmh', 'km/h'], ['kt', 'knots']]} />
        <Seg label="Altitude" k="altUnit" opts={[['ft', 'feet'], ['m', 'meters']]} />
        <Seg label="Time" k="time" opts={[['local', 'Local'], ['utc', 'UTC']]} />
        <Seg label="Map" k="map" opts={[['3d', '3D globe'], ['2d', '2D map']]} />
        <Seg label="Animation" k="motion" opts={[['full', 'Full'], ['reduced', 'Reduced']]} />
        <Seg label="Theme" k="theme" opts={[['dark', 'Dark'], ['light', 'Light']]} />
        <Seg label="Data refresh" k="refresh" opts={[['auto', 'Automatic'], ['manual', 'Manual']]} />
        {refresh === 'manual' && <button className="btn wide" onClick={refreshNow}>Refresh data now</button>}
        <p className="note">Reduced animation is applied automatically when your system asks for it.</p>
      </div>
    </div>
  );
}
