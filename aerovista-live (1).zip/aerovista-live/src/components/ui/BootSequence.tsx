import { useEffect, useState } from 'react';
import { useDataStore, type Status } from '../../stores/useDataStore';
import { useUiStore } from '../../stores/useUiStore';

const MIN_MS = 1100, MAX_MS = 4500;
type St = 'wait' | 'active' | 'done' | 'fail';

/** Reflects real loading progress. Dismisses as soon as the essentials settle (never longer than a few seconds). */
export default function BootSequence() {
  const { flights, satellites, server } = useDataStore();
  const globeReady = useUiStore((s) => s.globeReady);
  const booted = useUiStore((s) => s.booted);
  const setUi = useUiStore((s) => s.set);
  const [t0] = useState(() => performance.now());
  const [tick, setTick] = useState(0);
  useEffect(() => { const i = setInterval(() => setTick((x) => x + 1), 150); return () => clearInterval(i); }, []);

  const of = (s: Status): St => (s === 'ok' ? 'done' : s === 'error' ? 'fail' : s === 'loading' ? 'active' : 'wait');
  const steps: [string, St][] = [
    ['INITIALIZING EARTH SYSTEM', 'done'],
    ['CONNECTING TO LIVE DATA', server ? 'done' : flights.status === 'error' ? 'fail' : 'active'],
    ['LOADING AIRCRAFT', of(flights.status)],
    ['LOADING SATELLITES', of(satellites.status)],
    ['INITIALIZING 3D GLOBE', globeReady ? 'done' : 'active'],
  ];
  const settled = flights.status !== 'idle' && flights.status !== 'loading' && globeReady;
  const elapsed = performance.now() - t0;
  const finish = !booted && ((settled && elapsed > MIN_MS) || elapsed > MAX_MS);
  const [leaving, setLeaving] = useState(false);
  useEffect(() => {
    if (!finish || leaving) return;
    setLeaving(true);
    const t = setTimeout(() => setUi({ booted: true }), 480);
    return () => clearTimeout(t);
  }, [finish, leaving, setUi, tick]);

  if (booted) return null;
  return (
    <div className={`boot ${leaving ? 'leave' : ''}`} role="status" aria-label="Loading AEROVISTA LIVE">
      <div className="boot-inner">
        <div className="boot-mark" aria-hidden />
        <h1>AEROVISTA</h1>
        <ul>
          {steps.map(([label, st]) => (
            <li key={label} className={st}><i aria-hidden />{label}{st === 'fail' ? ' · unavailable' : ''}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
