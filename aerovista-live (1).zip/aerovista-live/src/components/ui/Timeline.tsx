export interface TimelineItem { time: string; label: string; note?: string; state?: 'done' | 'now' | 'future' }
export default function Timeline({ items }: { items: TimelineItem[] }) {
  if (!items.length) return null;
  return (
    <ol className="timeline" aria-label="Flight timeline">
      {items.map((it, i) => (
        <li key={i} className={it.state ?? 'done'}>
          <time className="mono">{it.time}</time>
          <div><strong>{it.label}</strong>{it.note && <span>{it.note}</span>}</div>
        </li>
      ))}
    </ol>
  );
}
