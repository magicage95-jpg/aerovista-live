import { useClock } from '../../hooks/useClock';
import { hud, resetView } from '../../runtime/camera';
import { fmtCoord } from '../../utils/format';
import { useAppStore } from '../../stores/useAppStore';

const nice = (km: number) => { const p = Math.pow(10, Math.floor(Math.log10(km))), m = km / p; return (m >= 5 ? 5 : m >= 2 ? 2 : 1) * p; };

/** Compass, centre coordinates, altitude and scale bar. */
export default function Hud() {
  useClock(250);
  const settings = useAppStore((s) => s.settings);
  const kmPerPx = hud.kmPerPx || 1;
  const km = nice(kmPerPx * 90), w = km / kmPerPx;
  const alt = hud.mode === '3d' ? (settings.altUnit === 'ft' ? `${Math.round(hud.altKm * 3280.84).toLocaleString()} ft` : `${Math.round(hud.altKm).toLocaleString()} km`) : null;
  return (
    <div className="hud" aria-hidden>
      <button className="compass" tabIndex={-1} onClick={resetView} title="Reset view (north up)">
        <svg viewBox="0 0 40 40" width="38" height="38"><circle cx="20" cy="20" r="18" fill="none" stroke="currentColor" strokeOpacity=".35" /><path d="M20 5l4 15h-8z" fill="#ff7a59" /><path d="M20 35l-4-15h8z" fill="currentColor" fillOpacity=".5" /><text x="20" y="4.5" textAnchor="middle" fontSize="6" fill="currentColor">N</text></svg>
      </button>
      <div className="readout mono">
        <span>{fmtCoord(hud.lat, hud.lon)}</span>
        {alt && <span>ALT {alt}</span>}
        <span className="scale"><i style={{ width: Math.max(24, Math.min(160, w)) }} />{km >= 1 ? `${km.toLocaleString()} km` : `${Math.round(km * 1000)} m`}</span>
      </div>
    </div>
  );
}
