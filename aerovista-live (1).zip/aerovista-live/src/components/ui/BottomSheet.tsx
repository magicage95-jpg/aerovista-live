import { useRef, type ReactNode } from 'react';
import { useAppStore } from '../../stores/useAppStore';

const ORDER = ['peek', 'half', 'full'] as const;

/** Mobile details panel: tap or swipe the handle to peek / half / full. */
export default function BottomSheet({ children }: { children: ReactNode }) {
  const sheet = useAppStore((s) => s.sheet);
  const setSheet = useAppStore((s) => s.setSheet);
  const y0 = useRef<number | null>(null);
  const idx = Math.max(0, ORDER.indexOf(sheet === 'closed' ? 'peek' : sheet));

  const move = (d: number) => setSheet(ORDER[Math.min(2, Math.max(0, idx + d))]);
  return (
    <div className={`sheet glass ${ORDER[idx]}`} role="region" aria-label="Details">
      <button
        className="grab" aria-label={`Details panel, ${ORDER[idx]}. Activate to resize`}
        onPointerDown={(e) => { y0.current = e.clientY; (e.target as Element).setPointerCapture(e.pointerId); }}
        onPointerUp={(e) => {
          const dy = y0.current == null ? 0 : e.clientY - y0.current;
          y0.current = null;
          if (dy < -28) move(1); else if (dy > 28) move(-1); else setSheet(ORDER[(idx + 1) % 3]);
        }}
        onKeyDown={(e) => { if (e.key === 'ArrowUp') move(1); if (e.key === 'ArrowDown') move(-1); }}
      ><i aria-hidden /></button>
      <div className="sheet-body">{children}</div>
    </div>
  );
}
