import { X } from 'lucide-react';
import type { ReactNode } from 'react';

export default function Panel({ title, subtitle, onClose, children, accent }: { title: ReactNode; subtitle?: ReactNode; onClose?: () => void; children: ReactNode; accent?: 'air' | 'sat' | 'ap' | 'loc' }) {
  return (
    <section className={`panel-body ${accent ?? ''}`} aria-label={typeof title === 'string' ? title : 'Details'}>
      <header className="panel-head">
        <div>
          <h2>{title}</h2>
          {subtitle && <p className="sub">{subtitle}</p>}
        </div>
        {onClose && <button className="icon-btn" onClick={onClose} aria-label="Close details"><X size={18} /></button>}
      </header>
      {children}
    </section>
  );
}

export const Row = ({ k, v, mono = true }: { k: string; v: ReactNode; mono?: boolean }) => (
  <div className="kv"><dt>{k}</dt><dd className={mono ? 'mono' : ''}>{v ?? '—'}</dd></div>
);
