import { useAppStore } from '../../stores/useAppStore';
import FlightPanel from '../panels/FlightPanel';
import SatellitePanel from '../panels/SatellitePanel';
import AirportPanel from '../panels/AirportPanel';
import LocationPanel from '../panels/LocationPanel';
import ModePanel from '../panels/ModePanel';

export default function RightContent() {
  const sel = useAppStore((s) => s.selection);
  const mode = useAppStore((s) => s.mode);
  if (!sel) return <ModePanel mode={mode} />;
  switch (sel.type) {
    case 'flight': return <FlightPanel key={sel.id} id={sel.id} />;
    case 'satellite': return <SatellitePanel key={sel.id} id={sel.id} />;
    case 'airport': return <AirportPanel key={sel.icao} icao={sel.icao} />;
    case 'location': return <LocationPanel key={`${sel.lat.toFixed(3)}${sel.lon.toFixed(3)}`} lat={sel.lat} lon={sel.lon} name={sel.name} />;
  }
}
