import { LocateFixed, Minus, Plus, RotateCcw } from 'lucide-react';
import { useAppStore } from '../../stores/useAppStore';
import { resetView, zoomBy } from '../../runtime/camera';
import { useGeolocation } from '../../hooks/useGeolocation';

export default function MapControls() {
  const { settings, setSettings, userLocation } = useAppStore();
  const { state, locate } = useGeolocation();
  return (
    <div className="mapctl" role="group" aria-label="Map controls">
      <button className="ctl glass" onClick={() => zoomBy(0.7)} aria-label="Zoom in"><Plus size={18} /></button>
      <button className="ctl glass" onClick={() => zoomBy(1.4)} aria-label="Zoom out"><Minus size={18} /></button>
      <button className="ctl glass" onClick={resetView} aria-label="Reset globe"><RotateCcw size={16} /></button>
      <button className="ctl glass txt" onClick={() => setSettings({ map: settings.map === '3d' ? '2d' : '3d' })} aria-label={`Switch to ${settings.map === '3d' ? '2D' : '3D'} view`}>
        {settings.map === '3d' ? '2D' : '3D'}
      </button>
      <button className={`ctl glass ${userLocation ? 'on' : ''}`} onClick={locate} aria-label="Show my location" title={state === 'denied' ? 'Location permission denied' : 'Show my location'}>
        <LocateFixed size={17} />
      </button>
      {state === 'denied' && <span className="sr-only" role="status">Location permission denied</span>}
    </div>
  );
}
