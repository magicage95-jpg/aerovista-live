import { RefreshCw } from 'lucide-react';
import { useDataStore } from '../../stores/useDataStore';
import { useAppStore } from '../../stores/useAppStore';

/** Trust banners: demo data is always loud; a failed layer says so and offers a retry. */
export default function Banners() {
  const { flights, server, online } = useDataStore();
  const refreshNow = useAppStore((s) => s.refreshNow);
  const demo = server?.demo || flights.meta?.demo;
  const failed = flights.status === 'error';
  return (
    <div className="banners">
      {demo && <div className="banner demo" role="status"><b>DEMO DATA</b> Simulated aircraft and sample schedules. Nothing here is real traffic.</div>}
      {!online && <div className="banner warn" role="alert">You are offline. Showing the last data received.</div>}
      {failed && (
        <div className="banner warn" role="alert">
          Live data temporarily unavailable for aircraft{flights.data.length ? ' (showing last known positions)' : ''}.
          <button className="btn small" onClick={refreshNow}><RefreshCw size={12} aria-hidden /> Retry</button>
        </div>
      )}
      {flights.meta?.stale && !failed && <div className="banner info" role="status">Provider is rate limiting or slow. Showing the last update.</div>}
    </div>
  );
}
