import { useDataStore, type Status } from '../../stores/useDataStore';

const cls = (s: Status) => (s === 'ok' ? 'ok' : s === 'error' ? 'bad' : 'wait');
export default function ApiStatus() {
  const { flights, satellites, airports, online } = useDataStore();
  const rows: [string, Status][] = [['Flights', flights.status], ['Satellites', satellites.status], ['Airports', airports.status]];
  return (
    <div className="apistat" role="status" aria-label={`Connection ${online ? 'online' : 'offline'}. ${rows.map(([n, s]) => `${n} ${s}`).join(', ')}`}>
      <span className={`dot ${online ? 'ok' : 'bad'}`} aria-hidden />
      <span className="apistat-label">{online ? 'CONNECTED' : 'OFFLINE'}</span>
      <span className="apistat-dots" aria-hidden>
        {rows.map(([n, s]) => <i key={n} className={`dot ${cls(s)}`} title={`${n}: ${s}`} />)}
      </span>
    </div>
  );
}
