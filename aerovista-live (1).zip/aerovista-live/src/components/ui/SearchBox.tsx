import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { Loader2, Search } from 'lucide-react';
import { geocodingService } from '../../services/geocodingService';
import { selectAndFly } from '../../runtime/actions';
import { useAppStore } from '../../stores/useAppStore';
import { useDebounced } from '../../hooks/useDebounced';
import type { Envelope, SearchResults } from '../../types';

interface Item { key: string; label: string; sub?: string; run: () => void }
interface Group { title: string; items: Item[] }

function ensureLayer(k: 'aircraft' | 'satellites' | 'airports') {
  const s = useAppStore.getState();
  if (!s.layers[k]) s.toggleLayer(k);
}

export default function SearchBox() {
  const [q, setQ] = useState('');
  const dq = useDebounced(q, 280);
  const [res, setRes] = useState<Envelope<SearchResults> | null>(null);
  const [state, setState] = useState<'idle' | 'loading' | 'error'>('idle');
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const id = useId();
  const input = useRef<HTMLInputElement>(null);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = dq.trim();
    if (t.length < 2) { setRes(null); setState('idle'); return; }
    const ctl = new AbortController();
    setState('loading');
    geocodingService.search(t, ctl.signal).then((r) => { setRes(r); setState('idle'); setActive(0); }).catch((e) => { if ((e as Error).name !== 'AbortError') setState('error'); });
    return () => ctl.abort();
  }, [dq]);

  useEffect(() => {
    const key = (e: KeyboardEvent) => { if (e.key === '/' && document.activeElement?.tagName !== 'INPUT') { e.preventDefault(); input.current?.focus(); } };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, []);

  const groups: Group[] = useMemo(() => {
    if (!res) return [];
    const d = res.data, out: Group[] = [];
    const done = () => { setOpen(false); setQ(''); input.current?.blur(); };
    if (d.flights.length) out.push({ title: 'FLIGHTS', items: d.flights.map((f) => ({ key: `f${f.id}`, label: f.callsign ?? f.id.toUpperCase(), sub: [f.flightNumber, f.airline].filter(Boolean).join(' · '), run: () => { ensureLayer('aircraft'); selectAndFly({ type: 'flight', id: f.id }, { lat: f.lat, lon: f.lon }); done(); } })) });
    if (d.airports.length) out.push({ title: 'AIRPORTS', items: d.airports.map((a) => ({ key: `a${a.icao}`, label: `${a.name}`, sub: `${a.iata ?? '—'} · ${a.icao} · ${a.city ?? ''} ${a.country}`, run: () => { ensureLayer('airports'); selectAndFly({ type: 'airport', icao: a.icao }, { lat: a.lat, lon: a.lon }); done(); } })) });
    if (d.aircraft.length) out.push({ title: 'AIRCRAFT', items: d.aircraft.map((a) => ({ key: `r${a.id}`, label: a.registration ?? a.id, sub: [a.type, a.callsign].filter(Boolean).join(' · '), run: () => { ensureLayer('aircraft'); selectAndFly({ type: 'flight', id: a.id }, { lat: a.lat, lon: a.lon }); done(); } })) });
    if (d.satellites.length) out.push({ title: 'SATELLITES', items: d.satellites.map((s) => ({ key: `s${s.noradId}`, label: s.name, sub: `NORAD ${s.noradId} · ${s.category.replace('-', ' ')}`, run: () => { ensureLayer('satellites'); selectAndFly({ type: 'satellite', id: s.noradId }); done(); } })) });
    if (d.cities.length) out.push({ title: 'CITIES', items: d.cities.map((c, i) => ({ key: `c${i}${c.lat}`, label: c.name, sub: [c.admin, c.country].filter(Boolean).join(', '), run: () => { selectAndFly({ type: 'location', lat: c.lat, lon: c.lon, name: c.name }, c); done(); } })) });
    if (d.locations.length) out.push({ title: 'LOCATIONS', items: d.locations.map((c, i) => ({ key: `l${i}${c.lat}`, label: c.name, sub: [c.admin, c.country].filter(Boolean).join(', '), run: () => { selectAndFly({ type: 'location', lat: c.lat, lon: c.lon, name: c.name }, c); done(); } })) });
    return out;
  }, [res]);
  const flat = groups.flatMap((g) => g.items);

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive((a) => Math.min(flat.length - 1, a + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(0, a - 1)); }
    else if (e.key === 'Enter' && flat[active]) { e.preventDefault(); flat[active].run(); }
    else if (e.key === 'Escape') { setOpen(false); input.current?.blur(); }
  };

  const showList = open && q.trim().length >= 2;
  return (
    <div className="search" ref={box} onBlur={(e) => { if (!box.current?.contains(e.relatedTarget as Node)) setOpen(false); }}>
      <Search size={16} aria-hidden className="search-ico" />
      <input
        ref={input} value={q} onChange={(e) => { setQ(e.target.value); setOpen(true); }} onFocus={() => setOpen(true)} onKeyDown={onKey}
        placeholder="Search flight, airport, aircraft, satellite or city..." aria-label="Search flights, airports, aircraft, satellites or cities"
        role="combobox" aria-expanded={showList} aria-controls={`${id}-list`} aria-autocomplete="list" aria-activedescendant={flat[active] ? `${id}-${flat[active].key}` : undefined}
        autoComplete="off" spellCheck={false} maxLength={60}
      />
      {state === 'loading' && <Loader2 size={15} className="spin search-state" aria-label="Searching" />}
      {showList && (
        <div className="results glass" id={`${id}-list`} role="listbox" aria-label="Search results">
          {state === 'error' && <div className="state error">Search is temporarily unavailable.</div>}
          {state !== 'error' && res && flat.length === 0 && state !== 'loading' && <div className="state empty">No matches for “{q.trim()}”.</div>}
          {groups.map((g) => (
            <div key={g.title} role="group" aria-label={g.title}>
              <div className="group-title">{g.title}</div>
              {g.items.map((it) => (
                <div key={it.key} id={`${id}-${it.key}`} role="option" aria-selected={flat[active]?.key === it.key} className={`opt ${flat[active]?.key === it.key ? 'on' : ''}`}
                  onMouseDown={(e) => e.preventDefault()} onClick={it.run} onMouseEnter={() => setActive(flat.findIndex((x) => x.key === it.key))}>
                  <b>{it.label}</b>{it.sub && <small>{it.sub}</small>}
                </div>
              ))}
            </div>
          ))}
          {res?.meta.note && flat.length > 0 && <div className="note pad">{res.meta.note}</div>}
        </div>
      )}
    </div>
  );
}
