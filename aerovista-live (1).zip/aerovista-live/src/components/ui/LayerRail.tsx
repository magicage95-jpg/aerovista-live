import { Cloud, Layers, MapPin, Orbit, Plane, Satellite, Route, Globe, Building2, X } from 'lucide-react';
import { useAppStore, type Layers as LayerKeys } from '../../stores/useAppStore';
import { useUiStore } from '../../stores/useUiStore';
import { BASEMAPS, type BasemapId } from '../../config/mapProviders';
import { useIsMobile } from '../../hooks/useMediaQuery';

export default function LayerRail() {
  const { layers, toggleLayer, settings, basemap, setBasemap } = useAppStore();
  const open = useUiStore((s) => s.layersOpen);
  const setUi = useUiStore((s) => s.set);
  const mobile = useIsMobile();
  const flat = settings.map === '2d';
  const items: [keyof LayerKeys, string, React.ReactNode][] = [
    ['aircraft', 'Aircraft', <Plane size={16} key="a" />],
    ['satellites', 'Satellites', <Satellite size={16} key="s" />],
    ['airports', 'Airports', <MapPin size={16} key="p" />],
    ['weather', flat ? 'Weather radar' : 'Daily clouds', <Cloud size={16} key="w" />],
    ['borders', 'Borders', <Globe size={16} key="b" />],
    ['cities', 'Cities', <Building2 size={16} key="c" />],
    ['trails', 'Trails and routes', <Route size={16} key="t" />],
    ['orbits', 'Orbit paths', <Orbit size={16} key="o" />],
  ];
  const visible = items.filter(([k]) => !(flat && (k === 'borders' || k === 'trails' || k === 'orbits' || k === 'cities')));
  if (mobile && !open) {
    return <button className="fab layers-fab glass" onClick={() => setUi({ layersOpen: true })} aria-label="Open layers"><Layers size={18} /></button>;
  }
  return (
    <aside className="rail glass" aria-label="Layers">
      <div className="rail-head"><Layers size={15} aria-hidden /> <span>Layers</span>{mobile && <button className="icon-btn" aria-label="Close layers" onClick={() => setUi({ layersOpen: false })}><X size={16} /></button>}</div>
      <ul>
        {visible.map(([k, label, icon]) => (
          <li key={k}>
            <button className={`toggle ${layers[k] ? 'on' : ''}`} role="switch" aria-checked={layers[k]} onClick={() => toggleLayer(k)}>
              {icon}<span>{label}</span><i aria-hidden />
            </button>
          </li>
        ))}
      </ul>
      {flat && (
        <>
          <div className="rail-head sub"><span>Map style</span></div>
          <div className="chips col" role="radiogroup" aria-label="Basemap">
            {(Object.keys(BASEMAPS) as BasemapId[]).map((k) => (
              <button key={k} role="radio" aria-checked={basemap === k} className={`chip ${basemap === k ? 'on' : ''}`} onClick={() => setBasemap(k)}>{BASEMAPS[k].label}</button>
            ))}
          </div>
        </>
      )}
    </aside>
  );
}
