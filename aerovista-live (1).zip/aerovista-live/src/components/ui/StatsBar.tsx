import { useDataStore } from '../../stores/useDataStore';
import { useAppStore } from '../../stores/useAppStore';
import { SATS } from '../../runtime/satellites';
import { fmtClock } from '../../utils/format';

export default function StatsBar() {
  const { flights, satellites, server } = useDataStore();
  const tm = useAppStore((s) => s.settings.time);
  const n = flights.data.length;
  const fetched = flights.meta?.fetchedAt;
  const active = fetched ? flights.data.filter((a) => fetched / 1000 - a.lastContact < 60).length : 0;
  const fmt = (v: number | undefined | null) => (v == null ? '—' : v.toLocaleString());
  return (
    <footer className="stats glass" aria-label="Live statistics">
      <Stat label="Live aircraft" value={flights.status === 'error' && !n ? '—' : fmt(n)} hint={flights.meta?.demo ? 'DEMO' : undefined} />
      <Stat label="Airports" value={fmt(server?.airportsCount)} />
      <Stat label="Satellites" value={satellites.status === 'ok' ? fmt(SATS.all.length) : '—'} hint="predicted" />
      <Stat label="Active tracks" value={fetched ? fmt(active) : '—'} hint="reporting < 60 s" />
      <Stat label="Data updated" value={fetched ? fmtClock(fetched, tm) : '—'} mono />
      <p className="stats-note">Coverage depends on data provider.</p>
    </footer>
  );
}
const Stat = ({ label, value, hint, mono }: { label: string; value: string; hint?: string; mono?: boolean }) => (
  <div className="stat"><span className="stat-label">{label}</span><b className={`stat-val ${mono ? 'mono' : ''}`}>{value}</b>{hint && <small>{hint}</small>}</div>
);
