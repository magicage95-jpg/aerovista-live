import { RefreshCw } from 'lucide-react';

export function ErrorState({ message = 'Live data temporarily unavailable', onRetry }: { message?: string; onRetry?: () => void }) {
  return (
    <div className="state error" role="alert">
      <p>{message}</p>
      {onRetry && <button className="btn" onClick={onRetry}><RefreshCw size={14} aria-hidden /> Retry</button>}
    </div>
  );
}
export const Skeleton = ({ lines = 4 }: { lines?: number }) => (
  <div className="skeleton" aria-busy="true" aria-label="Loading">
    {Array.from({ length: lines }, (_, i) => <i key={i} style={{ width: `${92 - ((i * 17) % 40)}%` }} />)}
  </div>
);
export const Empty = ({ children }: { children: React.ReactNode }) => <div className="state empty">{children}</div>;
