import { useClock } from '../../hooks/useClock';
import { useAppStore } from '../../stores/useAppStore';
import { fmtClock } from '../../utils/format';
import type { SourceMeta } from '../../types';

export function dataState(meta: SourceMeta | undefined, now: number) {
  if (!meta) return { label: 'NO DATA', cls: 'off' };
  if (meta.demo) return { label: 'DEMO DATA', cls: 'demo' };
  if (meta.kind === 'PREDICTED') return { label: 'PREDICTED', cls: 'pred' };
  if (meta.kind === 'STATIC') return { label: 'STATIC DATA', cls: 'static' };
  if (meta.kind === 'CALCULATED') return { label: 'CALCULATED', cls: 'calc' };
  const old = meta.ttlSec ? now - meta.fetchedAt > meta.ttlSec * 3000 : false;
  return meta.stale || old ? { label: 'LAST UPDATED', cls: 'stale' } : { label: 'LIVE', cls: 'live' };
}

/** Provider, update time and status. Shown on every data panel. */
export default function SourceBadge({ meta, compact }: { meta?: SourceMeta; compact?: boolean }) {
  const now = useClock(5000);
  const tm = useAppStore((s) => s.settings.time);
  const st = dataState(meta, now);
  return (
    <div className={`source ${st.cls}`} role="status">
      <span className="source-state"><i aria-hidden />{st.label}</span>
      <span className="source-line">Source: {meta?.source ?? '—'}</span>
      {meta && <span className="source-line">Updated: {fmtClock(meta.fetchedAt, tm)}</span>}
      {!compact && meta?.coverage && <span className="source-note">Coverage depends on data provider. {meta.coverage}</span>}
      {!compact && meta?.note && <span className="source-note">{meta.note}</span>}
    </div>
  );
}
