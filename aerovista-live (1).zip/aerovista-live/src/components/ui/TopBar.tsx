import { Settings } from 'lucide-react';
import { useAppStore, type Mode } from '../../stores/useAppStore';
import { useUiStore } from '../../stores/useUiStore';
import { useClock } from '../../hooks/useClock';
import { fmtClock } from '../../utils/format';
import SearchBox from './SearchBox';
import ApiStatus from './ApiStatus';

const NAV: { id: Mode | 'about'; label: string }[] = [
  { id: 'live', label: 'LIVE' }, { id: 'flights', label: 'FLIGHTS' }, { id: 'airports', label: 'AIRPORTS' }, { id: 'satellites', label: 'SATELLITES' },
  { id: 'earth', label: 'EARTH' }, { id: 'weather', label: 'WEATHER' }, { id: 'map', label: 'MAP' }, { id: 'about', label: 'ABOUT' },
];

export default function TopBar() {
  const { mode, page, setMode, setPage } = useAppStore();
  const setUi = useUiStore((s) => s.set);
  const now = useClock(1000);
  return (
    <header className="topbar glass">
      <a className="brand" href="#/" onClick={() => setPage('explorer')} aria-label="AEROVISTA LIVE home">
        <svg viewBox="0 0 32 32" width="26" height="26" aria-hidden><circle cx="16" cy="16" r="13" fill="none" stroke="#7cc4ff" strokeWidth="1.6" /><ellipse cx="16" cy="16" rx="13" ry="5" fill="none" stroke="#7cc4ff" strokeOpacity=".5" strokeWidth="1" transform="rotate(-24 16 16)" /><circle cx="26" cy="9.5" r="2.2" fill="#ffc15e" /></svg>
        <span className="brand-name">AEROVISTA</span>
        <span className="live-badge"><i aria-hidden />LIVE</span>
      </a>
      <nav className="nav" aria-label="Main">
        {NAV.map((n) => {
          const on = n.id === 'about' ? page === 'about' : page === 'explorer' && mode === n.id;
          return (
            <button key={n.id} className={on ? 'on' : ''} aria-current={on ? 'page' : undefined}
              onClick={() => { if (n.id === 'about') { setPage('about'); window.location.hash = '#/about'; } else { setPage('explorer'); window.location.hash = '#/'; setMode(n.id); } }}>
              {n.label}
            </button>
          );
        })}
      </nav>
      <SearchBox />
      <div className="top-right">
        <time className="clock mono" dateTime={new Date(now).toISOString()} aria-label="UTC time">{fmtClock(now, 'utc')}</time>
        <ApiStatus />
        <button className="icon-btn" aria-label="Open settings" onClick={() => setUi({ settingsOpen: true })}><Settings size={18} /></button>
      </div>
    </header>
  );
}
