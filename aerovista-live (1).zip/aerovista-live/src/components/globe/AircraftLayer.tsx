import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { AC, CATEGORY_COLORS, decayOffsets, renderPos } from '../../runtime/aircraft';
import { planeGeometry } from '../../utils/three';
import { clamp } from '../../utils/geo';

const CAP = 20000;
const D2R = Math.PI / 180;
const tmp = { lat: 0, lon: 0 };
const colorTmp = new THREE.Color();

/** All aircraft in ONE draw call. Matrices are written straight into the instance buffer every frame. */
export default function AircraftLayer() {
  const ref = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => planeGeometry(), []);
  const colorVersion = useRef(-1);

  useFrame((state, dt) => {
    const mesh = ref.current;
    if (!mesh) return;
    if (!useAppStore.getState().layers.aircraft) { mesh.count = 0; return; }
    decayOffsets(Math.min(dt, 0.25));
    const n = Math.min(AC.list.length, CAP);
    mesh.count = n;
    if (n === 0) return;

    if (colorVersion.current !== AC.version) {
      for (let i = 0; i < n; i++) mesh.setColorAt(i, colorTmp.set(CATEGORY_COLORS[AC.list[i].category]));
      if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      colorVersion.current = AC.version;
    }

    const nowS = Date.now() / 1000;
    const s = clamp(0.0052 * state.camera.position.length(), 0.0075, 0.03);
    const arr = mesh.instanceMatrix.array as Float32Array;
    for (let i = 0; i < n; i++) {
      renderPos(i, nowS, tmp);
      const a = AC.list[i];
      const phi = tmp.lat * D2R, lam = tmp.lon * D2R;
      const sp = Math.sin(phi), cp = Math.cos(phi), sl = Math.sin(lam), cl = Math.cos(lam);
      const nx = cp * cl, ny = sp, nz = -cp * sl; // up
      const h = (a.headingDeg ?? 0) * D2R, ch = Math.cos(h), sh = Math.sin(h);
      // forward = cos(h)*north + sin(h)*east
      const fx = ch * (-sp * cl) + sh * -sl, fy = ch * cp, fz = ch * (sp * sl) + sh * -cl;
      // right = forward x up
      const rx = fy * nz - fz * ny, ry = fz * nx - fx * nz, rz = fx * ny - fy * nx;
      const r = 1.004 + (Math.min(a.altM ?? 0, 13000) / 6371000) * 4;
      const o = i * 16;
      arr[o] = rx * s; arr[o + 1] = ry * s; arr[o + 2] = rz * s; arr[o + 3] = 0;
      arr[o + 4] = nx * s; arr[o + 5] = ny * s; arr[o + 6] = nz * s; arr[o + 7] = 0;
      arr[o + 8] = -fx * s; arr[o + 9] = -fy * s; arr[o + 10] = -fz * s; arr[o + 11] = 0;
      arr[o + 12] = nx * r; arr[o + 13] = ny * r; arr[o + 14] = nz * r; arr[o + 15] = 1;
    }
    mesh.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={ref} args={[geometry, undefined, CAP]} frustumCulled={false} renderOrder={5} name="aircraft">
      <meshBasicMaterial side={THREE.DoubleSide} toneMapped={false} transparent opacity={0.96} />
    </instancedMesh>
  );
}
