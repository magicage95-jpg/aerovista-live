import * as THREE from 'three';

const vert = `varying vec3 vN; void main(){ vN = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`;
const frag = `varying vec3 vN; void main(){ float i = pow(clamp(0.72 - dot(vN, vec3(0.0,0.0,1.0)), 0.0, 1.0), 2.4); gl_FragColor = vec4(0.28, 0.55, 1.0, 1.0) * i * 1.25; }`;

export default function Atmosphere() {
  return (
    <mesh scale={1.07} renderOrder={-1}>
      <sphereGeometry args={[1, 96, 64]} />
      <shaderMaterial vertexShader={vert} fragmentShader={frag} side={THREE.BackSide} transparent blending={THREE.AdditiveBlending} depthWrite={false} />
    </mesh>
  );
}
