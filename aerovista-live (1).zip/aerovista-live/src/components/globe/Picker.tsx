import { useEffect } from 'react';
import { useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { AC, renderPos } from '../../runtime/aircraft';
import { AP } from '../../runtime/airports';
import { SATS } from '../../runtime/satellites';
import { selectAirport, selectAndFly } from '../../runtime/actions';
import { SAT_XYZ } from './SatelliteLayer';
import { latLonToXYZ, xyzToLatLon } from '../../utils/geo';

type Hit = { score: number; run: () => void };

/** Screen-space picking: nearest object within a finger-friendly radius. No raycasting over 10k instances. */
export default function Picker() {
  const { camera, gl } = useThree();

  useEffect(() => {
    const el = gl.domElement;
    const v = new THREE.Vector3();
    let down: { x: number; y: number; t: number } | null = null;

    const onDown = (e: PointerEvent) => { down = { x: e.clientX, y: e.clientY, t: performance.now() }; };
    const onUp = (e: PointerEvent) => {
      if (!down) return;
      const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y), held = performance.now() - down.t;
      down = null;
      if (moved > 6 || held > 600) return;
      pick(e);
    };

    function pick(e: PointerEvent) {
      const rect = el.getBoundingClientRect();
      const px = e.clientX - rect.left, py = e.clientY - rect.top;
      const R = e.pointerType === 'touch' ? 24 : 14;
      const cam = camera.position;
      const st = useAppStore.getState();
      let best: Hit | null = null;
      const consider = (x: number, y: number, z: number, bias: number, run: () => void) => {
        v.set(x, y, z);
        if (v.dot(cam) < 1.0) return; // far side of the globe
        v.project(camera);
        if (v.z > 1) return;
        const d = Math.hypot((v.x * 0.5 + 0.5) * rect.width - px, (-v.y * 0.5 + 0.5) * rect.height - py);
        if (d > R) return;
        const score = d * bias;
        if (!best || score < best.score) best = { score, run };
      };

      if (st.layers.aircraft) {
        const o = { lat: 0, lon: 0 }, now = Date.now() / 1000;
        for (let i = 0; i < AC.list.length; i++) {
          renderPos(i, now, o);
          const [x, y, z] = latLonToXYZ(o.lat, o.lon, 1.004);
          const id = AC.list[i].id;
          consider(x, y, z, 1, () => selectAndFly({ type: 'flight', id }));
        }
      }
      if (st.layers.satellites) {
        for (let i = 0; i < SAT_XYZ.count; i++) {
          const rec = SATS.visible[i];
          if (!rec) continue;
          consider(SAT_XYZ.arr[i * 3], SAT_XYZ.arr[i * 3 + 1], SAT_XYZ.arr[i * 3 + 2], 0.9, () => selectAndFly({ type: 'satellite', id: rec.noradId }));
        }
      }
      if (st.layers.airports) {
        for (let i = 0; i < AP.list.length; i++) {
          const icao = AP.list[i].icao;
          consider(AP.xyz[i * 3], AP.xyz[i * 3 + 1], AP.xyz[i * 3 + 2], 1.15, () => selectAirport(icao));
        }
      }
      const winner = best as Hit | null;
      if (winner) { winner.run(); return; }

      // Empty space: pick a point on the surface in Earth/Weather mode, otherwise clear the selection.
      const ndc = new THREE.Vector2((px / rect.width) * 2 - 1, -(py / rect.height) * 2 + 1);
      const ray = new THREE.Raycaster();
      ray.setFromCamera(ndc, camera);
      const o = ray.ray.origin, d = ray.ray.direction;
      const b = o.dot(d), c = o.dot(o) - 1, disc = b * b - c;
      if (disc >= 0 && (st.mode === 'earth' || st.mode === 'weather')) {
        const t = -b - Math.sqrt(disc);
        const p = o.clone().addScaledVector(d, t);
        const ll = xyzToLatLon(p.x, p.y, p.z);
        selectAndFly({ type: 'location', lat: ll.lat, lon: ll.lon }, ll);
      } else if (st.selection) st.select(null);
    }

    el.addEventListener('pointerdown', onDown);
    el.addEventListener('pointerup', onUp);
    return () => { el.removeEventListener('pointerdown', onDown); el.removeEventListener('pointerup', onUp); };
  }, [camera, gl]);

  return null;
}
