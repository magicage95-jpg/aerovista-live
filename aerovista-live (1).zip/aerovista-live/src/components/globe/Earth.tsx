import { useEffect, useMemo, useState } from 'react';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { mapService } from '../../services/mapService';
import { latLonToXYZ } from '../../utils/geo';
import { sunSubpoint } from '../../utils/sun';

const vert = /* glsl */ `
varying vec2 vUv; varying vec3 vNW; varying vec3 vNV;
void main(){
  vUv = uv;
  vNW = normalize(mat3(modelMatrix) * normal);
  vNV = normalize(normalMatrix * normal);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;
const frag = /* glsl */ `
uniform sampler2D uDay; uniform sampler2D uNight; uniform vec3 uSun; uniform float uGrid;
varying vec2 vUv; varying vec3 vNW; varying vec3 vNV;
void main(){
  float d = dot(normalize(vNW), normalize(uSun));
  float t = smoothstep(-0.10, 0.20, d);
  vec3 day = texture2D(uDay, vUv).rgb;
  vec3 night = texture2D(uNight, vUv).rgb;
  vec3 dayLit = day * (0.92 + 0.12 * d);
  vec3 nightCol = night * 1.5 + day * 0.035;
  vec3 col = mix(nightCol, dayLit, t);
  float tw = smoothstep(-0.02, 0.12, d) * (1.0 - smoothstep(0.12, 0.34, d));
  col += vec3(0.95, 0.38, 0.12) * tw * 0.05;
  vec2 gv = vUv * vec2(24.0, 12.0);
  vec2 gl = abs(fract(gv - 0.5) - 0.5) / fwidth(gv);
  float line = 1.0 - min(min(gl.x, gl.y), 1.0);
  col += vec3(0.25, 0.5, 0.9) * line * 0.07 * uGrid;
  float fres = pow(1.0 - max(dot(normalize(vNV), vec3(0.0, 0.0, 1.0)), 0.0), 3.0);
  col += vec3(0.20, 0.45, 1.0) * fres * 0.35 * (0.35 + 0.65 * t);
  gl_FragColor = vec4(col, 1.0);
  #include <colorspace_fragment>
}`;

function solid(r: number, g: number, b: number) {
  const t = new THREE.DataTexture(new Uint8Array([r, g, b, 255]), 1, 1);
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}

function useRemoteTexture(url: string | null, fallback: THREE.Texture) {
  const [tex, setTex] = useState<THREE.Texture>(fallback);
  useEffect(() => {
    if (!url) { setTex(fallback); return; }
    let dead = false;
    const loader = new THREE.TextureLoader();
    loader.setCrossOrigin('anonymous');
    loader.load(url, (t) => {
      if (dead) { t.dispose(); return; }
      t.colorSpace = THREE.SRGBColorSpace;
      t.anisotropy = 8;
      setTex(t);
    }, undefined, () => { /* keep the procedural fallback: the globe still works without imagery */ });
    return () => { dead = true; };
  }, [url, fallback]);
  return tex;
}

export default function Earth() {
  const weather = useAppStore((s) => s.layers.weather);
  const dayFallback = useMemo(() => solid(9, 20, 38), []);
  const nightFallback = useMemo(() => solid(0, 0, 0), []);
  const day = useRemoteTexture(mapService.imageryUrl(weather ? 'daily' : 'bluemarble'), dayFallback);
  const night = useRemoteTexture(mapService.imageryUrl('night'), nightFallback);

  const uniforms = useMemo(() => ({
    uDay: { value: dayFallback }, uNight: { value: nightFallback },
    uSun: { value: new THREE.Vector3(1, 0, 0) }, uGrid: { value: 1 },
  }), [dayFallback, nightFallback]);

  useEffect(() => { uniforms.uDay.value = day; }, [day, uniforms]);
  useEffect(() => { uniforms.uNight.value = night; }, [night, uniforms]);
  useEffect(() => {
    const update = () => { const s = sunSubpoint(new Date()); uniforms.uSun.value.set(...latLonToXYZ(s.lat, s.lon, 1)); };
    update();
    const id = setInterval(update, 30_000);
    return () => clearInterval(id);
  }, [uniforms]);

  return (
    <mesh name="earth">
      <sphereGeometry args={[1, 128, 96]} />
      <shaderMaterial vertexShader={vert} fragmentShader={frag} uniforms={uniforms} />
    </mesh>
  );
}
