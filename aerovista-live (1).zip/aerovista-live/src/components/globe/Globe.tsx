import { useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import Earth from './Earth';
import Atmosphere from './Atmosphere';
import Stars from './Stars';
import Borders from './Borders';
import AircraftLayer from './AircraftLayer';
import SatelliteLayer from './SatelliteLayer';
import AirportLayer from './AirportLayer';
import Overlays from './Overlays';
import CameraRig from './CameraRig';
import Picker from './Picker';
import { useUiStore } from '../../stores/useUiStore';
import { globeFlags } from '../../runtime/camera';

export default function Globe() {
  const setUi = useUiStore((s) => s.set);
  useEffect(() => () => { globeFlags.ready = false; setUi({ globeReady: false }); }, [setUi]);
  return (
    <Canvas
      dpr={[1, 2]}
      camera={{ fov: 40, near: 0.01, far: 300, position: [0, 0, 3.3] }}
      gl={{ antialias: true, powerPreference: 'high-performance', alpha: false }}
      onCreated={({ gl }) => {
        gl.setClearColor('#02040a');
        gl.domElement.addEventListener('webglcontextlost', (e) => e.preventDefault());
        globeFlags.ready = true;
        setUi({ globeReady: true });
      }}
      aria-label="Interactive 3D globe"
    >
      <Stars />
      <Earth />
      <Atmosphere />
      <Borders />
      <AirportLayer />
      <AircraftLayer />
      <SatelliteLayer />
      <Overlays />
      <CameraRig />
      <Picker />
    </Canvas>
  );
}
