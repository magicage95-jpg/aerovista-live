import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { EARTH_RADIUS_KM, ISS_ID, SATS, llaAt, setSatFilter, updatePositions } from '../../runtime/satellites';
import { latLonToXYZ } from '../../utils/geo';
import { circleTexture, ringTexture } from '../../utils/three';
import type { SatCategory } from '../../types';

export const SAT_COLORS: Record<SatCategory, string> = {
  communication: '#6fd6ff', 'earth-observation': '#7ff0a8', weather: '#ffe27a', navigation: '#c9a6ff',
  science: '#ff9ac8', 'space-station': '#ffffff', other: '#9fb2d0',
};
const CAP = 4000;
/** Compact scene-space positions of the currently visible satellites (read by the picker). */
export const SAT_XYZ = { arr: new Float32Array(CAP * 3), count: 0 };

export default function SatelliteLayer() {
  const filter = useAppStore((s) => s.satFilter);
  const loadedAt = useDataStore((s) => s.satellites.updatedAt);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(CAP * 3), 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(CAP * 3), 3));
    return g;
  }, []);
  const map = useMemo(() => circleTexture(64, 0.5), []);
  const last = useRef(0);
  const ver = useRef(-1);
  const issRef = useRef<THREE.Sprite>(null);
  const ringMap = useMemo(() => ringTexture(), []);

  useEffect(() => { setSatFilter(filter); }, [filter, loadedAt]);

  useFrame((state) => {
    const on = useAppStore.getState().layers.satellites;
    geo.setDrawRange(0, on ? SATS.visible.length : 0);
    if (issRef.current) issRef.current.visible = on;
    if (!on) return;
    const now = Date.now();
    if (now - last.current < 1000 && ver.current === SATS.version) return;
    last.current = now; ver.current = SATS.version;
    const date = new Date(now);
    updatePositions(date);
    const pos = geo.getAttribute('position') as THREE.BufferAttribute;
    const col = geo.getAttribute('color') as THREE.BufferAttribute;
    const c = new THREE.Color();
    const n = Math.min(SATS.visible.length, CAP);
    for (let i = 0; i < n; i++) {
      const lat = SATS.pos[i * 3], lon = SATS.pos[i * 3 + 1], alt = SATS.pos[i * 3 + 2];
      if (alt < 0) { pos.setXYZ(i, 0, 0, 0); continue; }
      const [x, y, z] = latLonToXYZ(lat, lon, 1 + alt / EARTH_RADIUS_KM);
      pos.setXYZ(i, x, y, z);
      SAT_XYZ.arr[i * 3] = x; SAT_XYZ.arr[i * 3 + 1] = y; SAT_XYZ.arr[i * 3 + 2] = z;
      c.set(SAT_COLORS[SATS.visible[i].category]);
      col.setXYZ(i, c.r, c.g, c.b);
    }
    SAT_XYZ.count = n;
    pos.needsUpdate = true; col.needsUpdate = true;
    geo.setDrawRange(0, n);
    geo.computeBoundingSphere();

    const iss = SATS.byId.get(ISS_ID);
    const s = iss && llaAt(iss, date);
    if (s && issRef.current) {
      issRef.current.position.set(...latLonToXYZ(s.lat, s.lon, 1 + s.altKm / EARTH_RADIUS_KM));
    }
  });

  useFrame((state) => {
    const sp = issRef.current;
    if (!sp) return;
    const reduced = useAppStore.getState().settings.motion === 'reduced';
    const pulse = reduced ? 1 : 1 + 0.18 * Math.sin(state.clock.elapsedTime * 2.4);
    const d = state.camera.position.length();
    const k = Math.min(0.2, Math.max(0.045, d * 0.03)) * pulse;
    sp.scale.set(k, k, 1);
  });

  return (
    <>
      <points geometry={geo} frustumCulled={false} renderOrder={6} name="satellites">
        <pointsMaterial size={5} sizeAttenuation={false} vertexColors map={map} transparent alphaTest={0.05} depthWrite={false} />
      </points>
      <sprite ref={issRef} renderOrder={9} name="iss">
        <spriteMaterial map={ringMap} color="#ffffff" transparent depthTest={false} blending={THREE.AdditiveBlending} />
      </sprite>
    </>
  );
}
