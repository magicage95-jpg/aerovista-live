import { useEffect, useMemo } from 'react';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { AP, setAirportsXYZ } from '../../runtime/airports';
import { CITIES } from '../../config/cities';
import { circleTexture } from '../../utils/three';
import { latLonToXYZ } from '../../utils/geo';

export default function AirportLayer() {
  const on = useAppStore((s) => s.layers.airports);
  const cities = useAppStore((s) => s.layers.cities);
  const list = useDataStore((s) => s.airports.data);
  const map = useMemo(() => circleTexture(32, 0.45), []);

  const geo = useMemo(() => {
    setAirportsXYZ(list);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(AP.xyz, 3));
    const col = new Float32Array(list.length * 3);
    list.forEach((a, i) => (a.kind === 'large' ? new THREE.Color('#e9f2ff') : new THREE.Color('#6f88ad')).toArray(col, i * 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  }, [list]);
  useEffect(() => () => geo.dispose(), [geo]);

  const cityGeo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(CITIES.flatMap((c) => latLonToXYZ(c.lat, c.lon, 1.002)), 3));
    return g;
  }, []);

  return (
    <>
      {on && list.length > 0 && (
        <points geometry={geo} frustumCulled={false} renderOrder={4} name="airports">
          <pointsMaterial size={3.2} sizeAttenuation={false} vertexColors map={map} transparent alphaTest={0.05} depthWrite={false} />
        </points>
      )}
      {cities && (
        <points geometry={cityGeo} frustumCulled={false} renderOrder={4} name="cities">
          <pointsMaterial size={6} sizeAttenuation={false} color="#ffd9a0" map={map} transparent alphaTest={0.05} depthWrite={false} />
        </points>
      )}
    </>
  );
}
