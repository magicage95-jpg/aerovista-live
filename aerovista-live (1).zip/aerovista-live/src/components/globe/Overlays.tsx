import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { useSelectionStore } from '../../stores/useSelectionStore';
import { AC, TRAILS, pushTrail, renderPos } from '../../runtime/aircraft';
import { positionOf } from '../../runtime/objects';
import { EARTH_RADIUS_KM, SATS, groundTrack, orbitInfo } from '../../runtime/satellites';
import { intermediate, latLonToXYZ, haversineM, EARTH_R_M } from '../../utils/geo';
import { ringTexture, circleTexture } from '../../utils/three';

const TRAIL_MAX = 420;

/** Selection reticle + selected-aircraft trail + route arc + satellite path + user marker. */
export default function Overlays() {
  return (<><SelectionMarker /><AircraftTrail /><RouteArc /><OrbitPath /><UserMarker /></>);
}

function SelectionMarker() {
  const ref = useRef<THREE.Sprite>(null);
  const tex = useMemo(() => ringTexture(), []);
  useFrame((state) => {
    const sp = ref.current;
    if (!sp) return;
    const st = useAppStore.getState();
    const p = positionOf(st.selection);
    sp.visible = Boolean(p) && st.selection?.type !== 'location' ? true : Boolean(p);
    if (!p) return;
    sp.position.set(...latLonToXYZ(p.lat, p.lon, p.radius));
    const reduced = st.settings.motion === 'reduced';
    const pulse = reduced ? 1 : 1 + 0.12 * Math.sin(state.clock.elapsedTime * 3);
    const k = Math.min(0.24, Math.max(0.03, state.camera.position.length() * 0.026)) * pulse;
    sp.scale.set(k, k, 1);
  });
  return <sprite ref={ref} renderOrder={10} visible={false}><spriteMaterial map={tex} color="#7cc4ff" transparent depthTest={false} /></sprite>;
}

function AircraftTrail() {
  const lineRef = useRef<THREE.Line>(null);
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(TRAIL_MAX * 3), 3).setUsage(THREE.DynamicDrawUsage));
    g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(TRAIL_MAX * 3), 3));
    return g;
  }, []);
  const last = useRef(0);
  const tmp = useMemo(() => ({ lat: 0, lon: 0 }), []);

  useFrame(() => {
    const st = useAppStore.getState();
    const line = lineRef.current;
    if (!line) return;
    const sel = st.selection;
    if (!st.layers.trails || sel?.type !== 'flight') { line.visible = false; return; }
    const i = AC.index.get(sel.id);
    if (i === undefined) { line.visible = false; return; }
    const now = Date.now();
    renderPos(i, now / 1000, tmp);
    if (now - last.current > 2000) {
      last.current = now;
      pushTrail(sel.id, tmp.lat, tmp.lon, AC.list[i].altM ?? 0, now / 1000);
    }
    const tr = TRAILS.get(sel.id) ?? [];
    const n = Math.min(tr.length, TRAIL_MAX - 1);
    const start = tr.length - n;
    const pos = geo.getAttribute('position') as THREE.BufferAttribute;
    const col = geo.getAttribute('color') as THREE.BufferAttribute;
    for (let k = 0; k < n; k++) {
      const p = tr[start + k];
      const [x, y, z] = latLonToXYZ(p.lat, p.lon, 1.004);
      pos.setXYZ(k, x, y, z);
      const f = (k + 1) / (n + 1);
      col.setXYZ(k, 1.0 * f, 0.76 * f, 0.36 * f);
    }
    const [x, y, z] = latLonToXYZ(tmp.lat, tmp.lon, 1.004);
    pos.setXYZ(n, x, y, z); col.setXYZ(n, 1, 0.85, 0.5);
    pos.needsUpdate = true; col.needsUpdate = true;
    geo.setDrawRange(0, n + 1);
    line.visible = n >= 1;
  });
  return (
    <line ref={lineRef as never} geometry={geo} frustumCulled={false} renderOrder={7}>
      <lineBasicMaterial vertexColors transparent blending={THREE.AdditiveBlending} depthWrite={false} />
    </line>
  );
}

/** Great-circle arc origin -> destination for the selected flight (only when a route is known). */
function RouteArc() {
  const detail = useSelectionStore((s) => s.flightDetail);
  const sel = useAppStore((s) => s.selection);
  const ref = useRef<THREE.Line>(null);
  const geo = useMemo(() => {
    const o = detail?.origin as { lat?: number; lon?: number } | null | undefined;
    const d = detail?.destination as { lat?: number; lon?: number } | null | undefined;
    if (sel?.type !== 'flight' || detail?.id !== sel.id || o?.lat == null || o.lon == null || d?.lat == null || d.lon == null) return null;
    const pts: number[] = [];
    const dist = haversineM(o.lat, o.lon, d.lat, d.lon) / EARTH_R_M;
    for (let i = 0; i <= 96; i++) {
      const f = i / 96, p = intermediate(o.lat, o.lon, d.lat, d.lon, f);
      pts.push(...latLonToXYZ(p.lat, p.lon, 1.004 + Math.sin(Math.PI * f) * 0.06 * Math.min(1, dist)));
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    return g;
  }, [detail, sel]);
  useEffect(() => { if (geo && ref.current) ref.current.computeLineDistances(); }, [geo]);
  useFrame((_, dt) => {
    const m = ref.current?.material as THREE.LineDashedMaterial | undefined;
    if (m && useAppStore.getState().settings.motion !== 'reduced') (m as unknown as { dashOffset: number }).dashOffset -= dt * 0.04;
  });
  if (!geo) return null;
  return (
    <line ref={ref as never} geometry={geo} renderOrder={6}>
      <lineDashedMaterial color="#7cc4ff" dashSize={0.02} gapSize={0.016} transparent opacity={0.75} depthWrite={false} />
    </line>
  );
}

/** Predicted path of the selected satellite over the next orbit, relative to the rotating Earth. */
function OrbitPath() {
  const sel = useAppStore((s) => s.selection);
  const on = useAppStore((s) => s.layers.orbits);
  const geo = useMemo(() => {
    if (sel?.type !== 'satellite') return null;
    const rec = SATS.byId.get(sel.id);
    if (!rec) return null;
    const minutes = Math.min(orbitInfo(rec).periodMin, 1440);
    const pts = groundTrack(rec, new Date(), minutes, 200);
    if (pts.length < 2) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pts.flatMap((p) => latLonToXYZ(p.lat, p.lon, 1 + p.altKm / EARTH_RADIUS_KM)), 3));
    return g;
  }, [sel]);
  if (!on || !geo) return null;
  return <line geometry={geo} frustumCulled={false} renderOrder={6}><lineBasicMaterial color="#62e0d0" transparent opacity={0.8} blending={THREE.AdditiveBlending} depthWrite={false} /></line>;
}

function UserMarker() {
  const loc = useAppStore((s) => s.userLocation);
  const tex = useMemo(() => circleTexture(64, 0.4), []);
  const ref = useRef<THREE.Sprite>(null);
  useFrame((state) => {
    if (!ref.current || !loc) return;
    const k = Math.min(0.1, Math.max(0.02, state.camera.position.length() * 0.012));
    ref.current.scale.set(k, k, 1);
  });
  if (!loc) return null;
  return (
    <sprite ref={ref} position={latLonToXYZ(loc.lat, loc.lon, 1.006)} renderOrder={8}>
      <spriteMaterial map={tex} color="#5fe3a1" transparent depthTest={false} />
    </sprite>
  );
}
