import { useEffect, useState } from 'react';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { latLonToXYZ } from '../../utils/geo';

/** Country boundaries from Natural Earth (world-atlas), loaded lazily. */
export default function Borders() {
  const on = useAppStore((s) => s.layers.borders);
  const [geo, setGeo] = useState<THREE.BufferGeometry | null>(null);

  useEffect(() => {
    if (!on || geo) return;
    let dead = false;
    (async () => {
      const [{ mesh }, atlas] = await Promise.all([import('topojson-client'), import('world-atlas/countries-110m.json')]);
      const topo = (atlas as unknown as { default: any }).default ?? atlas;
      const lines = mesh(topo, topo.objects.countries) as unknown as { coordinates: [number, number][][] };
      const v: number[] = [];
      for (const line of lines.coordinates) {
        for (let i = 0; i < line.length - 1; i++) {
          const [lo1, la1] = line[i], [lo2, la2] = line[i + 1];
          const steps = Math.max(1, Math.ceil(Math.max(Math.abs(lo2 - lo1), Math.abs(la2 - la1)) / 2));
          let prev = latLonToXYZ(la1, lo1, 1.0015);
          for (let s = 1; s <= steps; s++) {
            const f = s / steps;
            const cur = latLonToXYZ(la1 + (la2 - la1) * f, lo1 + (lo2 - lo1) * f, 1.0015);
            v.push(...prev, ...cur);
            prev = cur;
          }
        }
      }
      if (dead) return;
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(v, 3));
      setGeo(g);
    })().catch(() => undefined); // boundaries are decoration: fail silently
    return () => { dead = true; };
  }, [on, geo]);

  if (!on || !geo) return null;
  return <lineSegments geometry={geo}><lineBasicMaterial color="#7db8ff" transparent opacity={0.28} depthWrite={false} /></lineSegments>;
}
