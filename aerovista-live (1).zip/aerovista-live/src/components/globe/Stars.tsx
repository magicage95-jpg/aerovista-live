import { useMemo } from 'react';
import * as THREE from 'three';

export default function Stars() {
  const geo = useMemo(() => {
    const n = 2600;
    const pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = Math.random() * 2 - 1, th = Math.random() * Math.PI * 2, s = Math.sqrt(1 - u * u), r = 70 + Math.random() * 20;
      pos.set([r * s * Math.cos(th), r * u, r * s * Math.sin(th)], i * 3);
      const warm = Math.random(), b = 0.45 + Math.random() * 0.55;
      col.set([b * (0.85 + 0.15 * warm), b * 0.92, b * (1 - 0.12 * warm)], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return g;
  }, []);
  return <points geometry={geo} frustumCulled={false}><pointsMaterial size={1.4} sizeAttenuation={false} vertexColors transparent opacity={0.9} depthWrite={false} /></points>;
}
