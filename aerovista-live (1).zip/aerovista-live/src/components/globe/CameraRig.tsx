import { useEffect, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { useAppStore } from '../../stores/useAppStore';
import { positionOf } from '../../runtime/objects';
import { camCmd, DEFAULT_VIEW, hud, zoomToDistance } from '../../runtime/camera';
import { clamp, latLonToXYZ, xyzToLatLon } from '../../utils/geo';

interface Target { dir: THREE.Vector3; dist: number }

export default function CameraRig() {
  const { camera, size } = useThree();
  const controls = useRef<any>(null);
  const fly = useAppStore((s) => s.fly);
  const target = useRef<Target | null>(null);
  const lastInput = useRef(0);

  useEffect(() => {
    if (hud.handoff) { hud.handoff = false; camera.position.set(...latLonToXYZ(hud.lat, hud.lon, zoomToDistance(hud.zoom))); }
    else camera.position.set(...latLonToXYZ(DEFAULT_VIEW.lat, DEFAULT_VIEW.lon, DEFAULT_VIEW.distance));
  }, [camera]);

  useEffect(() => {
    if (!fly) return;
    target.current = { dir: new THREE.Vector3(...latLonToXYZ(fly.lat, fly.lon, 1)), dist: fly.distance };
  }, [fly]);

  useEffect(() => {
    const c = controls.current;
    if (!c) return;
    const start = () => {
      target.current = null; lastInput.current = performance.now();
      if (useAppStore.getState().follow) useAppStore.getState().setFollow(false);
    };
    const end = () => { lastInput.current = performance.now(); };
    c.addEventListener('start', start); c.addEventListener('end', end);
    return () => { c.removeEventListener('start', start); c.removeEventListener('end', end); };
  }, []);

  useFrame((_, dtRaw) => {
    const c = controls.current;
    if (!c) return;
    const dt = Math.min(dtRaw, 0.1);
    const st = useAppStore.getState();
    const reduced = st.settings.motion === 'reduced';
    let dist = camera.position.length();

    if (camCmd.reset) {
      camCmd.reset = false; st.setFollow(false);
      target.current = { dir: new THREE.Vector3(...latLonToXYZ(DEFAULT_VIEW.lat, DEFAULT_VIEW.lon, 1)), dist: DEFAULT_VIEW.distance };
    }
    if (camCmd.zoom !== 1) {
      dist = clamp(dist * camCmd.zoom, 1.06, 12); camCmd.zoom = 1;
      camera.position.setLength(dist); target.current = null;
    }
    if (camCmd.dLat || camCmd.dLon) {
      const cur = xyzToLatLon(camera.position.x, camera.position.y, camera.position.z);
      const lat = clamp(cur.lat + camCmd.dLat, -85, 85), lon = cur.lon + camCmd.dLon;
      camCmd.dLat = 0; camCmd.dLon = 0;
      camera.position.set(...latLonToXYZ(lat, lon, dist)); target.current = null;
    }

    let tgt = target.current;
    if (st.follow && st.selection) {
      const p = positionOf(st.selection);
      if (p) tgt = { dir: new THREE.Vector3(...latLonToXYZ(p.lat, p.lon, 1)), dist: Math.max(Math.min(dist, 2.0), p.radius + 0.7) };
    }
    if (tgt) {
      const a = reduced ? 1 : 1 - Math.exp(-dt * (st.follow ? 5 : 3.2));
      const dir = camera.position.clone().normalize();
      const angle = dir.angleTo(tgt.dir);
      dir.lerp(tgt.dir, a).normalize();
      const nd = dist + (tgt.dist - dist) * a;
      camera.position.copy(dir).multiplyScalar(nd);
      if (!st.follow && angle < 0.002 && Math.abs(tgt.dist - nd) < 0.01) target.current = null;
    }

    dist = camera.position.length();
    c.rotateSpeed = clamp((dist - 1) * 0.55, 0.1, 1);
    c.zoomSpeed = 0.8;
    const idle = performance.now() - lastInput.current > 5000;
    c.autoRotate = !reduced && idle && !st.selection && st.mode === 'live' && !target.current;
    c.autoRotateSpeed = 0.3;

    const ll = xyzToLatLon(camera.position.x, camera.position.y, camera.position.z);
    hud.lat = ll.lat; hud.lon = ll.lon; hud.mode = '3d';
    hud.altKm = (dist - 1) * 6371;
    const pxPerUnit = size.height / 2 / (Math.max(0.02, dist - 1) * Math.tan(THREE.MathUtils.degToRad(20)));
    hud.kmPerPx = 6371 / pxPerUnit;
  });

  return <OrbitControls ref={controls} makeDefault enablePan={false} enableDamping dampingFactor={0.08} minDistance={1.06} maxDistance={12} />;
}
