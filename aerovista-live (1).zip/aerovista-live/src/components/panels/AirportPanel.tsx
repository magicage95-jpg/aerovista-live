import { useCallback, useEffect, useMemo, useState } from 'react';
import { PlaneLanding, PlaneTakeoff } from 'lucide-react';
import { useAppStore } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { airportService } from '../../services/airportService';
import { ApiError } from '../../services/apiClient';
import { selectAndFly } from '../../runtime/actions';
import { fmtAlt, fmtClock, fmtCoord, fmtSpeed } from '../../utils/format';
import { haversineM } from '../../utils/geo';
import type { AirportBrief, Envelope, Movement, Schedule } from '../../types';
import Panel, { Row } from '../ui/Panel';
import SourceBadge from '../ui/SourceBadge';
import { Empty, ErrorState, Skeleton } from '../ui/States';
import WeatherView from './WeatherView';

type Tab = 'arrivals' | 'departures' | 'aircraft' | 'info' | 'weather';
const TABS: [Tab, string][] = [['arrivals', 'Arrivals'], ['departures', 'Departures'], ['aircraft', 'Live aircraft'], ['info', 'Airport info'], ['weather', 'Weather']];

export default function AirportPanel({ icao }: { icao: string }) {
  const select = useAppStore((s) => s.select);
  const refresh = useAppStore((s) => s.settings.refresh);
  const [tab, setTab] = useState<Tab>('arrivals');
  const [airport, setAirport] = useState<AirportBrief | null>(null);

  useEffect(() => {
    setAirport(null); setTab('arrivals');
    airportService.get(icao).then((r) => setAirport(r.data)).catch(() => {
      const a = useDataStore.getState().airports.data.find((x) => x.icao === icao);
      if (a) setAirport(a);
    });
  }, [icao]);

  const [sched, setSched] = useState<Envelope<Schedule> | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const loadSched = useCallback(() => {
    setErr(null);
    airportService.schedule(icao).then(setSched).catch((e) => setErr(e instanceof ApiError ? e.message : 'Live data temporarily unavailable'));
  }, [icao]);
  useEffect(() => { setSched(null); loadSched(); }, [loadSched]);
  useEffect(() => {
    if (refresh === 'manual') return;
    const t = setInterval(loadSched, 60_000);
    return () => clearInterval(t);
  }, [loadSched, refresh]);

  return (
    <Panel title={airport ? airport.name : icao} subtitle={airport ? `${airport.iata ?? '—'} · ${airport.icao} · ${airport.city ?? ''} ${airport.country}` : 'Loading airport'} onClose={() => select(null)} accent="ap">
      <div className="tabs" role="tablist" aria-label="Airport sections">
        {TABS.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}
      </div>
      <div role="tabpanel">
        {(tab === 'arrivals' || tab === 'departures') && (
          <Board dir={tab} sched={sched} err={err} onRetry={loadSched} />
        )}
        {tab === 'aircraft' && <NearbyAircraft airport={airport} />}
        {tab === 'info' && airport && (
          <>
            <dl className="kvs">
              <Row k="Name" v={airport.name} mono={false} /><Row k="IATA" v={airport.iata ?? '—'} /><Row k="ICAO" v={airport.icao} />
              <Row k="City" v={airport.city ?? '—'} mono={false} /><Row k="Country" v={airport.country} mono={false} />
              <Row k="Coordinates" v={fmtCoord(airport.lat, airport.lon)} />
              <Row k="Elevation" v={airport.elevationFt != null ? `${airport.elevationFt.toLocaleString()} ft` : '—'} />
            </dl>
            <p className="note">Airport directory: OurAirports (public domain). Static data.</p>
          </>
        )}
        {tab === 'weather' && airport && <WeatherView lat={airport.lat} lon={airport.lon} />}
        {!airport && tab !== 'arrivals' && tab !== 'departures' && <Skeleton lines={4} />}
      </div>
    </Panel>
  );
}

function Board({ dir, sched, err, onRetry }: { dir: 'arrivals' | 'departures'; sched: Envelope<Schedule> | null; err: string | null; onRetry: () => void }) {
  const tm = useAppStore((s) => s.settings.time);
  if (err && !sched) return <ErrorState message={err} onRetry={onRetry} />;
  if (!sched) return <Skeleton lines={6} />;
  const rows: Movement[] = sched.data[dir];
  if (!sched.data.configured && !sched.meta.demo) {
    return <><Empty>Arrivals and departures need a schedule provider key. Add <span className="mono">FLIGHT_API_KEY</span> to the server environment to enable them.</Empty><SourceBadge meta={sched.meta} /></>;
  }
  const Icon = dir === 'arrivals' ? PlaneLanding : PlaneTakeoff;
  return (
    <>
      {sched.meta.demo && <div className="demo-flag">DEMO DATA: sample schedule, not real flights</div>}
      {rows.length === 0 ? <Empty>No {dir} in this window.</Empty> : (
        <div className="table-wrap">
          <table className="board">
            <caption className="sr-only">{dir}</caption>
            <thead><tr><th scope="col">Time ({tm === 'utc' ? 'UTC' : 'local'})</th><th scope="col">Flight</th><th scope="col">{dir === 'arrivals' ? 'From' : 'To'}</th><th scope="col">Status</th></tr></thead>
            <tbody>
              {rows.map((m, i) => (
                <tr key={`${m.number}-${i}`}>
                  <td className="mono"><Icon size={12} aria-hidden /> {fmtClock(m.estimated ?? m.scheduled ?? '', tm, false)}
                    {m.delayMin != null && Math.abs(m.delayMin) >= 5 && <small className={m.delayMin > 0 ? 'late' : 'early'}> {m.delayMin > 0 ? '+' : ''}{m.delayMin}m</small>}
                    {m.estimated && m.scheduled && m.estimated !== m.scheduled && <small className="muted"> sched {fmtClock(m.scheduled, tm, false)}</small>}
                  </td>
                  <td><b className="mono">{m.number}</b><small>{m.airline}{m.aircraft ? ` · ${m.aircraft}` : ''}</small></td>
                  <td>{m.counterpart.iata ?? m.counterpart.icao ?? '—'}<small>{m.counterpart.name}</small></td>
                  <td>{m.status}<small>{[m.terminal && `T${m.terminal}`, m.gate && `Gate ${m.gate}`].filter(Boolean).join(' · ')}</small></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <SourceBadge meta={sched.meta} />
    </>
  );
}

function NearbyAircraft({ airport }: { airport: AirportBrief | null }) {
  const flights = useDataStore((d) => d.flights);
  const { speedUnit, altUnit } = useAppStore((s) => s.settings);
  const list = useMemo(() => {
    if (!airport) return [];
    return flights.data
      .map((a) => ({ a, d: haversineM(airport.lat, airport.lon, a.lat, a.lon) }))
      .filter((x) => x.d < 80_000).sort((x, y) => x.d - y.d).slice(0, 40);
  }, [flights.data, airport]);
  if (!airport) return <Skeleton />;
  return (
    <>
      {list.length === 0 ? <Empty>No aircraft from the current feed within 80 km. Coverage depends on the data provider.</Empty> : (
        <ul className="list">
          {list.map(({ a, d }) => (
            <li key={a.id}><button onClick={() => selectAndFly({ type: 'flight', id: a.id })}>
              <b className="mono">{a.callsign ?? a.id.toUpperCase()}</b><span>{a.airline ?? a.type ?? ''}</span>
              <small className="mono">{fmtAlt(a.altM, altUnit)} · {fmtSpeed(a.speedMs, speedUnit)} · {Math.round(d / 1000)} km</small>
            </button></li>
          ))}
        </ul>
      )}
      <SourceBadge meta={{ ...(flights.meta ?? { source: '—', kind: 'LIVE', fetchedAt: Date.now() }), kind: 'CALCULATED', note: 'Aircraft within 80 km, filtered from the live feed.' }} />
    </>
  );
}
