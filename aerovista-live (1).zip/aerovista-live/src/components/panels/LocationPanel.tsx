import { useEffect, useState } from 'react';
import { Camera, Compass, Globe2, MapPin } from 'lucide-react';
import { useAppStore } from '../../stores/useAppStore';
import { geocodingService } from '../../services/geocodingService';
import { exploreLocation } from '../../runtime/actions';
import { fmtCoord } from '../../utils/format';
import type { Envelope, NearbyPlace, StreetImage } from '../../types';
import Panel, { Row } from '../ui/Panel';
import SourceBadge from '../ui/SourceBadge';
import { Empty, Skeleton } from '../ui/States';
import WeatherView from './WeatherView';

export default function LocationPanel({ lat, lon, name }: { lat: number; lon: number; name?: string }) {
  const { select, settings, setSettings, flyTo } = useAppStore();
  const [places, setPlaces] = useState<Envelope<NearbyPlace[]> | 'err' | null>(null);
  const [street, setStreet] = useState<Envelope<StreetImage | null> | 'err' | null>(null);

  useEffect(() => {
    setPlaces(null); setStreet(null);
    geocodingService.nearby(lat, lon).then(setPlaces).catch(() => setPlaces('err'));
    geocodingService.street(lat, lon).then(setStreet).catch(() => setStreet('err'));
  }, [lat, lon]);

  const flat = settings.map === '2d';
  return (
    <Panel title={name ?? 'Selected location'} subtitle={fmtCoord(lat, lon)} onClose={() => select(null)} accent="loc">
      {flat
        ? <button className="btn wide" onClick={() => { setSettings({ map: '3d' }); flyTo(lat, lon, 1.6); }}><Globe2 size={16} aria-hidden /> Back to globe</button>
        : <button className="btn wide primary" onClick={() => exploreLocation(lat, lon)}><Compass size={16} aria-hidden /> Explore location</button>}
      <h3 className="h3">Weather</h3>
      <WeatherView lat={lat} lon={lon} />
      <h3 className="h3">Street-level imagery</h3>
      {street === null ? <Skeleton lines={3} /> : street === 'err' ? <Empty>Street-level imagery is unavailable right now.</Empty> : street.data ? (
        <figure className="street">
          <img src={street.data.url} alt="Street-level view near the selected location" loading="lazy" />
          <figcaption>{street.data.attribution} · <a href={street.data.link} target="_blank" rel="noreferrer">Open in Mapillary</a></figcaption>
        </figure>
      ) : <Empty><Camera size={14} aria-hidden /> {street.meta.note ?? 'No street-level imagery here.'} Not every location has street imagery.</Empty>}
      <h3 className="h3">Nearby places</h3>
      {places === null ? <Skeleton lines={4} /> : places === 'err' ? <Empty>Nearby places are unavailable right now.</Empty> : places.data.length === 0 ? <Empty>No named places within about 1 km.</Empty> : (
        <>
          <ul className="list">
            {places.data.slice(0, 10).map((p) => (
              <li key={p.id}><button onClick={() => useAppStore.getState().flyTo(p.lat, p.lon, flat ? 1.001 : 1.06)}><MapPin size={12} aria-hidden /> <b>{p.name}</b><small>{p.kind.replace(/_/g, ' ')}</small></button></li>
            ))}
          </ul>
          <SourceBadge meta={places.meta} compact />
        </>
      )}
      <dl className="kvs">
        <Row k="Buildings / 3D" v={flat ? 'Not available on raster basemaps' : 'Not claimed for every location'} mono={false} />
      </dl>
    </Panel>
  );
}
