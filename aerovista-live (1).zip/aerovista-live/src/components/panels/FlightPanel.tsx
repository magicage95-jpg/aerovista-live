import { useEffect, useMemo } from 'react';
import { Crosshair, Plane } from 'lucide-react';
import { useAppStore } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { useSelectionStore } from '../../stores/useSelectionStore';
import { flightService } from '../../services/flightService';
import { TRAILS } from '../../runtime/aircraft';
import { fmtAlt, fmtClock, fmtCoord, fmtDuration, fmtHeading, fmtKm, fmtSpeed, fmtVs } from '../../utils/format';
import { haversineM } from '../../utils/geo';
import { useClock } from '../../hooks/useClock';
import Panel, { Row } from '../ui/Panel';
import SourceBadge from '../ui/SourceBadge';
import Timeline, { type TimelineItem } from '../ui/Timeline';

const label = (a?: { iata?: string | null; icao: string; name?: string } | null) => (a ? `${a.iata ?? a.icao}${a.name ? ` · ${a.name}` : ''}` : null);
const coords = (a: unknown) => { const x = a as { lat?: number; lon?: number } | null | undefined; return x?.lat != null && x.lon != null ? { lat: x.lat, lon: x.lon } : null; };

export default function FlightPanel({ id }: { id: string }) {
  const { settings: s, follow, setFollow, select } = useAppStore();
  const flights = useDataStore((d) => d.flights);
  const detail = useSelectionStore((d) => d.flightDetail);
  const setDetail = useSelectionStore((d) => d.setFlightDetail);
  const now = useClock(1000);
  const ac = useMemo(() => flights.data.find((a) => a.id === id), [flights.data, id]);

  useEffect(() => {
    let dead = false;
    setDetail(null);
    flightService.getDetail(id).then((r) => { if (!dead) setDetail(r.data); }).catch(() => undefined); // optional enrichment
    return () => { dead = true; };
  }, [id, setDetail]);

  const d = detail?.id === id ? detail : null;
  const origin = d?.origin as { iata?: string | null; icao: string; name?: string } | null | undefined;
  const dest = d?.destination as { iata?: string | null; icao: string; name?: string } | null | undefined;

  const calc = useMemo(() => {
    if (!ac) return null;
    const o = coords(d?.origin), t = coords(d?.destination);
    const travelled = o ? haversineM(o.lat, o.lon, ac.lat, ac.lon) : null;
    const remaining = t ? haversineM(ac.lat, ac.lon, t.lat, t.lon) : null;
    const eta = remaining != null && ac.speedMs && ac.speedMs > 60 ? Date.now() + (remaining / ac.speedMs) * 1000 : null;
    return { travelled, remaining, eta };
  }, [ac, d]);

  if (!ac) {
    return (
      <Panel title="Aircraft out of range" subtitle="It is no longer in the current data feed." onClose={() => select(null)} accent="air">
        <p className="muted">The aircraft may have landed, left receiver coverage or the provider has not reported it recently.</p>
        <SourceBadge meta={flights.meta} />
      </Panel>
    );
  }

  const vs = ac.vsMs ?? 0, alt = ac.altM ?? 0;
  const status = ac.onGround ? 'On ground' : alt > 7500 && Math.abs(vs) < 2.5 ? 'Cruising' : vs > 2.5 ? 'Climbing' : vs < -2.5 ? 'Descending' : 'Airborne';
  const trail = TRAILS.get(id);
  const items: TimelineItem[] = [];
  if (trail?.length) items.push({ time: fmtClock(trail[0].t * 1000, s.time), label: 'First seen in this session', note: 'Not a departure time', state: 'done' });
  items.push({ time: fmtClock(ac.positionAt * 1000, s.time), label: `Last position report · ${status}`, state: 'now' });
  if (calc?.eta) items.push({ time: fmtClock(calc.eta, s.time, false), label: 'Estimated arrival', note: 'Calculated from distance and ground speed', state: 'future' });

  return (
    <Panel title={<><Plane size={18} aria-hidden /> {ac.callsign ?? ac.id.toUpperCase()}</>} subtitle={ac.airline ?? ac.originCountry ?? 'Operator unknown'} onClose={() => select(null)} accent="air">
      <button className={`btn wide ${follow ? 'on' : ''}`} onClick={() => setFollow(!follow)} aria-pressed={follow}>
        <Crosshair size={16} aria-hidden /> {follow ? 'Following aircraft' : 'Follow aircraft'}
      </button>
      <div className="route-line" aria-label="Route">
        <div><b className="mono">{origin?.iata ?? origin?.icao ?? '—'}</b><small>{origin?.name ?? 'Origin unknown'}</small></div>
        <span aria-hidden>✈</span>
        <div><b className="mono">{dest?.iata ?? dest?.icao ?? '—'}</b><small>{dest?.name ?? 'Destination unknown'}</small></div>
      </div>
      <dl className="kvs">
        <Row k="Flight number" v={ac.flightNumber ?? '—'} />
        <Row k="Callsign" v={ac.callsign ?? '—'} />
        <Row k="Airline" v={ac.airline ?? '—'} mono={false} />
        <Row k="Aircraft" v={d?.type ? `${d.type}${d.description ? ` · ${d.description}` : ''}` : ac.type ?? '—'} mono={false} />
        <Row k="Registration" v={d?.registration ?? ac.registration ?? '—'} />
        <Row k="ICAO24" v={ac.id.toUpperCase()} />
        <Row k="Status" v={status} mono={false} />
        <Row k="Altitude" v={fmtAlt(ac.altM, s.altUnit)} />
        <Row k="Ground speed" v={fmtSpeed(ac.speedMs, s.speedUnit)} />
        <Row k="Heading" v={fmtHeading(ac.headingDeg)} />
        <Row k="Vertical speed" v={fmtVs(ac.vsMs, s.altUnit)} />
        <Row k="Squawk" v={ac.squawk ?? '—'} />
        <Row k="Position" v={fmtCoord(ac.lat, ac.lon)} />
        <Row k="Distance travelled" v={calc?.travelled != null ? `≈ ${fmtKm(calc.travelled)} from origin` : '—'} />
        <Row k="Remaining" v={calc?.remaining != null ? `≈ ${fmtKm(calc.remaining)}` : '—'} />
        <Row k="Estimated arrival" v={calc?.eta ? `${fmtClock(calc.eta, s.time, false)} (${fmtDuration((calc.eta - now) / 1000)})` : '—'} />
        <Row k="Last update" v={fmtClock(ac.lastContact * 1000, s.time)} />
      </dl>
      {d?.routeSource && <p className="note">Route: {d.routeSource}.</p>}
      <h3 className="h3">Timeline</h3>
      <Timeline items={items} />
      <SourceBadge meta={flights.meta} />
      {d && label(origin) && <span className="sr-only">{label(origin)} to {label(dest)}</span>}
    </Panel>
  );
}
