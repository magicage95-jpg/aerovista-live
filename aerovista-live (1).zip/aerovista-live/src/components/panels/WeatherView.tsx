import { useCallback, useEffect, useState } from 'react';
import { Droplets, Eye, Gauge, Cloud, Wind, Thermometer } from 'lucide-react';
import { weatherService } from '../../services/weatherService';
import { ApiError } from '../../services/apiClient';
import { useAppStore } from '../../stores/useAppStore';
import { compassPoint, fmtClock } from '../../utils/format';
import { weatherText } from '../../utils/weatherCodes';
import type { Envelope, WeatherReport } from '../../types';
import SourceBadge from '../ui/SourceBadge';
import { ErrorState, Skeleton } from '../ui/States';

export default function WeatherView({ lat, lon }: { lat: number; lon: number }) {
  const [wx, setWx] = useState<Envelope<WeatherReport> | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const unit = useAppStore((s) => s.settings.speedUnit);
  const tm = useAppStore((s) => s.settings.time);

  const load = useCallback(() => {
    setErr(null);
    weatherService.get(lat, lon).then(setWx).catch((e) => setErr(e instanceof ApiError ? e.message : 'Live data temporarily unavailable'));
  }, [lat, lon]);
  useEffect(() => { setWx(null); load(); }, [load]);
  useEffect(() => { const t = setInterval(load, 10 * 60_000); return () => clearInterval(t); }, [load]);

  if (err && !wx) return <ErrorState message={err} onRetry={load} />;
  if (!wx) return <Skeleton lines={5} />;
  const c = wx.data.current;
  const wind = unit === 'kt' ? `${Math.round(c.windKmh / 1.852)} kt` : `${Math.round(c.windKmh)} km/h`;
  return (
    <div className="wx">
      <div className="wx-hero">
        <span className="wx-temp mono">{Math.round(c.temperatureC)}°</span>
        <div><strong>{weatherText(c.code)}</strong><span>Feels like {Math.round(c.apparentC)}°C</span></div>
      </div>
      <dl className="grid2">
        <div className="tile"><Wind size={14} aria-hidden /><dt>Wind</dt><dd className="mono">{wind} {compassPoint(c.windDirDeg)} ({Math.round(c.windDirDeg)}°)</dd></div>
        <div className="tile"><Droplets size={14} aria-hidden /><dt>Humidity</dt><dd className="mono">{Math.round(c.humidity)}%</dd></div>
        <div className="tile"><Eye size={14} aria-hidden /><dt>Visibility</dt><dd className="mono">{c.visibilityM == null ? '—' : `${(c.visibilityM / 1000).toFixed(c.visibilityM >= 10000 ? 0 : 1)} km`}</dd></div>
        <div className="tile"><Cloud size={14} aria-hidden /><dt>Cloud cover</dt><dd className="mono">{Math.round(c.cloudPct)}%</dd></div>
        <div className="tile"><Gauge size={14} aria-hidden /><dt>Pressure</dt><dd className="mono">{Math.round(c.pressureHpa)} hPa</dd></div>
        <div className="tile"><Thermometer size={14} aria-hidden /><dt>Gusts</dt><dd className="mono">{c.windGustKmh == null ? '—' : unit === 'kt' ? `${Math.round(c.windGustKmh / 1.852)} kt` : `${Math.round(c.windGustKmh)} km/h`}</dd></div>
      </dl>
      <h3 className="h3">Next hours</h3>
      <div className="strip" role="list">
        {wx.data.hourly.filter((_, i) => i % 3 === 0).slice(0, 8).map((h) => (
          <div key={h.time} role="listitem"><span className="mono">{fmtClock(h.time, tm, false)}</span><b className="mono">{Math.round(h.tempC)}°</b><small>{weatherText(h.code)}</small><small className="mono">{h.precipPct ?? 0}% rain</small></div>
        ))}
      </div>
      <h3 className="h3">Forecast</h3>
      <ul className="days">
        {wx.data.daily.map((d) => (
          <li key={d.date}><span>{new Date(d.date + 'T12:00:00Z').toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', timeZone: 'UTC' })}</span><span>{weatherText(d.code)}</span><span className="mono">{Math.round(d.minC)}° / {Math.round(d.maxC)}°</span></li>
        ))}
      </ul>
      <SourceBadge meta={wx.meta} />
    </div>
  );
}
