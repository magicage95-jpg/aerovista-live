import { useMemo } from 'react';
import { useAppStore, type Mode } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { SATS } from '../../runtime/satellites';
import { selectAndFly } from '../../runtime/actions';
import { fmtAlt, fmtSpeed } from '../../utils/format';
import { SAT_COLORS } from '../globe/SatelliteLayer';
import { BASEMAPS, type BasemapId } from '../../config/mapProviders';
import type { SatCategory } from '../../types';
import Panel from '../ui/Panel';
import SourceBadge from '../ui/SourceBadge';
import { Empty, ErrorState, Skeleton } from '../ui/States';

const TITLES: Record<Mode, [string, string]> = {
  live: ['Live overview', 'Aircraft, satellites and airports on one globe.'],
  flights: ['Flight mode', 'Select an aircraft on the globe or search a callsign.'],
  airports: ['Airport mode', 'Select an airport marker or search by name, IATA or ICAO.'],
  satellites: ['Satellite mode', 'Predicted positions from public orbital elements.'],
  earth: ['Earth mode', 'Click anywhere on the globe to inspect a location.'],
  weather: ['Weather mode', 'Click a location for current conditions and the forecast.'],
  map: ['Map mode', 'Flat map with switchable basemaps and layers.'],
};
const CATS: ['all' | SatCategory, string][] = [
  ['all', 'All'], ['communication', 'Communication'], ['earth-observation', 'Earth observation'], ['weather', 'Weather'],
  ['navigation', 'Navigation'], ['science', 'Science'], ['space-station', 'Space station'], ['other', 'Other'],
];

export default function ModePanel({ mode }: { mode: Mode }) {
  const [title, sub] = TITLES[mode];
  return (
    <Panel title={title} subtitle={sub}>
      {(mode === 'live' || mode === 'flights' || mode === 'airports' || mode === 'map') && <FlightsSummary />}
      {mode === 'satellites' && <SatelliteList />}
      {mode === 'map' && <BasemapPicker />}
      {(mode === 'earth' || mode === 'weather') && <p className="muted">Pick any point on Earth. The panel shows weather, nearby places and, where a provider has coverage, street-level imagery.</p>}
    </Panel>
  );
}

function FlightsSummary() {
  const f = useDataStore((d) => d.flights);
  const { speedUnit, altUnit } = useAppStore((s) => s.settings);
  const { reloadFlights } = useDataFeeds2();
  const top = useMemo(() => [...f.data].filter((a) => a.speedMs != null).sort((a, b) => (b.speedMs ?? 0) - (a.speedMs ?? 0)).slice(0, 6), [f.data]);
  if (f.status === 'error' && !f.data.length) return <ErrorState message={f.error} onRetry={reloadFlights} />;
  if (f.status !== 'ok' && !f.data.length) return <Skeleton lines={5} />;
  return (
    <>
      <h3 className="h3">Fastest right now</h3>
      {top.length === 0 ? <Empty>No aircraft in the current feed.</Empty> : (
        <ul className="list">
          {top.map((a) => (
            <li key={a.id}><button onClick={() => selectAndFly({ type: 'flight', id: a.id })}>
              <b className="mono">{a.callsign ?? a.id.toUpperCase()}</b><span>{a.airline ?? a.originCountry ?? ''}</span>
              <small className="mono">{fmtSpeed(a.speedMs, speedUnit)} · {fmtAlt(a.altM, altUnit)}</small>
            </button></li>
          ))}
        </ul>
      )}
      {f.status === 'error' && <ErrorState message={f.error} onRetry={reloadFlights} />}
      <SourceBadge meta={f.meta} />
    </>
  );
}
const useDataFeeds2 = () => ({ reloadFlights: () => useAppStore.getState().refreshNow() });

function SatelliteList() {
  const sats = useDataStore((d) => d.satellites);
  const { satFilter, setSatFilter } = useAppStore();
  const counts = useMemo(() => {
    const c = new Map<string, number>();
    for (const s of SATS.all) c.set(s.category, (c.get(s.category) ?? 0) + 1);
    return c;
  }, [sats.updatedAt]);
  if (sats.status === 'error' && !SATS.all.length) return <ErrorState message={sats.error} onRetry={() => useAppStore.getState().refreshNow()} />;
  if (!SATS.all.length) return <Skeleton lines={6} />;
  const shown = SATS.visible.slice(0, 14);
  return (
    <>
      <div className="chips" role="group" aria-label="Satellite category">
        {CATS.filter(([k]) => k === 'all' || counts.has(k)).map(([k, l]) => (
          <button key={k} className={`chip ${satFilter === k ? 'on' : ''}`} aria-pressed={satFilter === k} onClick={() => setSatFilter(k)}>
            {k !== 'all' && <i style={{ background: SAT_COLORS[k] }} aria-hidden />}{l}<small>{k === 'all' ? SATS.all.length : counts.get(k)}</small>
          </button>
        ))}
      </div>
      <ul className="list">
        {shown.map((s) => (
          <li key={s.noradId}><button onClick={() => selectAndFly({ type: 'satellite', id: s.noradId })}>
            <b>{s.name}</b><small className="mono">NORAD {s.noradId}</small>
          </button></li>
        ))}
      </ul>
      {SATS.visible.length > shown.length && <p className="note">Showing {shown.length} of {SATS.visible.length}. Use search for any name or NORAD ID.</p>}
      <p className="note">Categories come from the catalogue group each satellite was listed in, so only reliably known categories are shown.</p>
      <SourceBadge meta={sats.meta} />
    </>
  );
}

function BasemapPicker() {
  const { basemap, setBasemap } = useAppStore();
  return (
    <>
      <h3 className="h3">Basemap</h3>
      <div className="chips" role="radiogroup" aria-label="Basemap">
        {(Object.keys(BASEMAPS) as BasemapId[]).map((k) => (
          <button key={k} role="radio" aria-checked={basemap === k} className={`chip ${basemap === k ? 'on' : ''}`} onClick={() => setBasemap(k)}>{BASEMAPS[k].label}</button>
        ))}
      </div>
      <p className="note">{BASEMAPS[basemap].attribution}</p>
    </>
  );
}
