import { useEffect, useMemo, useState } from 'react';
import { Crosshair, LocateFixed, Satellite as SatIcon } from 'lucide-react';
import { useAppStore } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { ISS_ID, SATS, nextPass, orbitInfo, stateAt, type Pass } from '../../runtime/satellites';
import { useClock } from '../../hooks/useClock';
import { useGeolocation } from '../../hooks/useGeolocation';
import { fmtAlt, fmtClock, fmtCoord, fmtDuration, fmtSpeed } from '../../utils/format';
import Panel, { Row } from '../ui/Panel';
import SourceBadge from '../ui/SourceBadge';

export default function SatellitePanel({ id }: { id: number }) {
  const { settings: s, follow, setFollow, select, userLocation } = useAppStore();
  const meta = useDataStore((d) => d.satellites.meta);
  const now = useClock(1000);
  const rec = SATS.byId.get(id);
  const { state: geoState, locate } = useGeolocation();
  const [pass, setPass] = useState<Pass | null | 'busy'>(null);

  const live = useMemo(() => (rec ? stateAt(rec, new Date(now)) : null), [rec, now]);
  const orbit = useMemo(() => (rec ? orbitInfo(rec) : null), [rec]);

  useEffect(() => {
    if (!rec || !userLocation) { setPass(null); return; }
    setPass('busy');
    const t = setTimeout(() => setPass(nextPass(rec, userLocation.lat, userLocation.lon)), 30); // let the panel paint first
    return () => clearTimeout(t);
  }, [rec, userLocation]);

  if (!rec) return <Panel title="Satellite not found" onClose={() => select(null)} accent="sat"><p className="muted">This object is not in the loaded catalogue.</p></Panel>;
  const iss = id === ISS_ID;

  return (
    <Panel title={<><SatIcon size={18} aria-hidden /> {rec.name}</>} subtitle={iss ? 'International Space Station' : rec.category.replace('-', ' ')} onClose={() => select(null)} accent="sat">
      <div className="pred-flag" role="note"><b>PREDICTED</b> Calculated from orbital elements. Not live telemetry.</div>
      <button className={`btn wide ${follow ? 'on' : ''}`} onClick={() => setFollow(!follow)} aria-pressed={follow}>
        <Crosshair size={16} aria-hidden /> {follow ? 'Following satellite' : 'Follow satellite'}
      </button>
      <dl className="kvs">
        <Row k="NORAD ID" v={rec.noradId} />
        <Row k="Latitude" v={live ? `${live.lat.toFixed(3)}°` : '—'} />
        <Row k="Longitude" v={live ? `${live.lon.toFixed(3)}°` : '—'} />
        <Row k="Position" v={live ? fmtCoord(live.lat, live.lon) : '—'} />
        <Row k="Altitude" v={live ? fmtAlt(live.altKm * 1000, s.altUnit) : '—'} />
        <Row k="Velocity" v={live ? fmtSpeed(live.velKms * 1000, s.speedUnit) : '—'} />
        <Row k="Illumination" v={live ? (live.sunlit ? 'In sunlight' : 'In Earth’s shadow') : '—'} mono={false} />
        {orbit && <>
          <Row k="Orbit period" v={`${orbit.periodMin.toFixed(1)} min`} />
          <Row k="Inclination" v={`${orbit.inclinationDeg.toFixed(2)}°`} />
          <Row k="Perigee / apogee" v={`${Math.round(orbit.perigeeKm).toLocaleString()} / ${Math.round(orbit.apogeeKm).toLocaleString()} km`} />
          <Row k="Elements epoch" v={`${fmtClock(orbit.epoch, s.time, false)} · ${orbit.ageDays.toFixed(1)} d old`} />
        </>}
      </dl>
      <h3 className="h3">Next visible pass</h3>
      {!userLocation ? (
        <div>
          <p className="muted">Passes are computed for your location. Location is only requested when you ask for it.</p>
          <button className="btn" onClick={locate}><LocateFixed size={14} aria-hidden /> Use my location</button>
          {geoState === 'denied' && <p className="note">Location permission was denied. Everything else keeps working.</p>}
        </div>
      ) : pass === 'busy' ? <p className="muted">Calculating…</p> : pass ? (
        <dl className="kvs">
          <Row k="Rises" v={`${fmtClock(pass.start, s.time, false)} (in ${fmtDuration((pass.start - now) / 1000)})`} />
          <Row k="Peak" v={`${fmtClock(pass.peak, s.time, false)} · ${Math.round(pass.maxElDeg)}° elevation`} />
          <Row k="Sets" v={fmtClock(pass.end, s.time, false)} />
          <Row k="Visibility" v={pass.visible ? 'Visible to the naked eye (dark sky, sunlit satellite)' : 'Not expected to be visible (daylight or in shadow)'} mono={false} />
        </dl>
      ) : <p className="muted">No pass above 10° in the next 36 hours.</p>}
      <SourceBadge meta={meta} />
    </Panel>
  );
}
