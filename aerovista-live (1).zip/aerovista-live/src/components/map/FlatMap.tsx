import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { useAppStore } from '../../stores/useAppStore';
import { useDataStore } from '../../stores/useDataStore';
import { mapService } from '../../services/mapService';
import { AC, CATEGORY_COLORS, renderPos } from '../../runtime/aircraft';
import { SATS, updatePositions } from '../../runtime/satellites';
import { positionOf } from '../../runtime/objects';
import { selectAirport, selectAndFly } from '../../runtime/actions';
import { distanceToZoom, flat, hud } from '../../runtime/camera';
import type { AirportBrief } from '../../types';

type FC = GeoJSON.FeatureCollection<GeoJSON.Point>;
const empty: FC = { type: 'FeatureCollection', features: [] };

function planeImage(): ImageData {
  const s = 48, c = document.createElement('canvas');
  c.width = c.height = s;
  const g = c.getContext('2d')!;
  g.fillStyle = '#fff';
  g.beginPath();
  const pts: [number, number][] = [[0, -1], [0.09, -0.72], [0.1, -0.25], [0.85, 0.18], [0.85, 0.34], [0.1, 0.12], [0.08, 0.55], [0.32, 0.74], [0.32, 0.88], [0, 0.8], [-0.32, 0.88], [-0.32, 0.74], [-0.08, 0.55], [-0.1, 0.12], [-0.85, 0.34], [-0.85, 0.18], [-0.1, -0.25], [-0.09, -0.72]];
  pts.forEach(([x, y], i) => { const px = s / 2 + x * s * 0.46, py = s / 2 + y * s * 0.46; i ? g.lineTo(px, py) : g.moveTo(px, py); });
  g.closePath(); g.fill();
  return g.getImageData(0, 0, s, s);
}

function setup(map: maplibregl.Map) {
  if (!map.hasImage('plane')) map.addImage('plane', planeImage(), { sdf: true });
  const add = (id: string, opts: Partial<maplibregl.GeoJSONSourceSpecification> = {}) => {
    if (!map.getSource(id)) map.addSource(id, { type: 'geojson', data: empty, ...opts } as maplibregl.GeoJSONSourceSpecification);
  };
  add('airports', { cluster: true, clusterRadius: 38, clusterMaxZoom: 7 });
  add('aircraft'); add('sats'); add('sel'); add('user');
  const L = (l: maplibregl.LayerSpecification) => { if (!map.getLayer(l.id)) map.addLayer(l); };
  L({ id: 'ap-cluster', type: 'circle', source: 'airports', filter: ['has', 'point_count'], paint: { 'circle-color': '#3b5b8c', 'circle-opacity': 0.85, 'circle-stroke-color': '#9cc6ff', 'circle-stroke-width': 1, 'circle-radius': ['step', ['get', 'point_count'], 9, 10, 12, 40, 16] } });
  L({ id: 'ap-point', type: 'circle', source: 'airports', filter: ['!', ['has', 'point_count']], paint: { 'circle-color': ['case', ['==', ['get', 'kind'], 'large'], '#eaf3ff', '#7f97bd'], 'circle-radius': 3.5, 'circle-stroke-color': '#06101f', 'circle-stroke-width': 1 } });
  L({ id: 'sats', type: 'circle', source: 'sats', paint: { 'circle-color': '#62e0d0', 'circle-radius': 3, 'circle-opacity': 0.9 } });
  L({ id: 'aircraft', type: 'symbol', source: 'aircraft', layout: { 'icon-image': 'plane', 'icon-rotate': ['get', 'h'], 'icon-rotation-alignment': 'map', 'icon-allow-overlap': true, 'icon-ignore-placement': true, 'icon-size': ['interpolate', ['linear'], ['zoom'], 2, 0.34, 8, 0.6, 14, 0.9] }, paint: { 'icon-color': ['get', 'c'], 'icon-halo-color': '#02040a', 'icon-halo-width': 1 } });
  L({ id: 'user', type: 'circle', source: 'user', paint: { 'circle-color': '#5fe3a1', 'circle-radius': 6, 'circle-stroke-color': '#fff', 'circle-stroke-width': 2 } });
  L({ id: 'sel', type: 'circle', source: 'sel', paint: { 'circle-color': 'rgba(0,0,0,0)', 'circle-radius': 16, 'circle-stroke-color': '#7cc4ff', 'circle-stroke-width': 2 } });
}

const pt = (lon: number, lat: number, props: Record<string, unknown>): GeoJSON.Feature<GeoJSON.Point> => ({ type: 'Feature', properties: props, geometry: { type: 'Point', coordinates: [lon, lat] } });
const src = (map: maplibregl.Map, id: string) => map.getSource(id) as maplibregl.GeoJSONSource | undefined;

export default function FlatMap() {
  const box = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const basemap = useAppStore((s) => s.basemap);
  const layers = useAppStore((s) => s.layers);
  const fly = useAppStore((s) => s.fly);
  const airports = useDataStore((s) => s.airports.data);
  const user = useAppStore((s) => s.userLocation);
  const first = useRef(true);
  const airportsRef = useRef<AirportBrief[]>([]);
  airportsRef.current = airports;

  // create / destroy
  useEffect(() => {
    const st = useAppStore.getState();
    const map = new maplibregl.Map({
      container: box.current as HTMLDivElement,
      style: mapService.style(st.basemap),
      center: [hud.lon, hud.lat],
      zoom: distanceToZoom(1 + hud.altKm / 6371),
      minZoom: 1.2, maxZoom: 18, attributionControl: { compact: true }, dragRotate: false, pitchWithRotate: false,
    });
    map.touchZoomRotate.disableRotation();
    mapRef.current = map;
    flat.map = map;
    hud.mode = '2d';
    const onStyle = () => { setup(map); pushAirports(); };
    const pushAirports = () => {
      src(map, 'airports')?.setData({ type: 'FeatureCollection', features: airportsRef.current.map((a) => pt(a.lon, a.lat, { icao: a.icao, kind: a.kind })) });
    };
    map.on('style.load', onStyle);

    const tick = () => {
      if (!map.isStyleLoaded() && !map.getSource('aircraft')) return;
      const s = useAppStore.getState();
      const b = map.getBounds();
      const out = { lat: 0, lon: 0 }, now = Date.now() / 1000, feats: GeoJSON.Feature<GeoJSON.Point>[] = [];
      if (s.layers.aircraft) {
        const pad = 2;
        for (let i = 0; i < AC.list.length && feats.length < 6000; i++) {
          renderPos(i, now, out);
          if (out.lat < b.getSouth() - pad || out.lat > b.getNorth() + pad) continue;
          if (out.lon < b.getWest() - pad || out.lon > b.getEast() + pad) continue;
          feats.push(pt(out.lon, out.lat, { id: AC.list[i].id, h: AC.list[i].headingDeg ?? 0, c: CATEGORY_COLORS[AC.list[i].category] }));
        }
      }
      src(map, 'aircraft')?.setData({ type: 'FeatureCollection', features: feats });
      const sf: GeoJSON.Feature<GeoJSON.Point>[] = [];
      if (s.layers.satellites) {
        updatePositions(new Date());
        for (let i = 0; i < SATS.visible.length; i++) if (SATS.pos[i * 3 + 2] >= 0) sf.push(pt(SATS.pos[i * 3 + 1], SATS.pos[i * 3], { id: SATS.visible[i].noradId }));
      }
      src(map, 'sats')?.setData({ type: 'FeatureCollection', features: sf });
      const p = positionOf(s.selection);
      src(map, 'sel')?.setData(p ? { type: 'FeatureCollection', features: [pt(p.lon, p.lat, {})] } : empty);
      if (s.follow && p) map.easeTo({ center: [p.lon, p.lat], duration: s.settings.motion === 'reduced' ? 0 : 1800, easing: (t) => t });
    };
    const id = window.setInterval(tick, 2000);

    const hudTick = () => { const c = map.getCenter(); hud.lat = c.lat; hud.lon = c.lng; hud.altKm = 0; hud.kmPerPx = (40075 * Math.cos((c.lat * Math.PI) / 180)) / (512 * Math.pow(2, map.getZoom())); };
    map.on('move', hudTick); hudTick();

    map.on('dragstart', () => { if (useAppStore.getState().follow) useAppStore.getState().setFollow(false); });
    map.on('click', (e) => {
      const box2: [maplibregl.PointLike, maplibregl.PointLike] = [[e.point.x - 14, e.point.y - 14], [e.point.x + 14, e.point.y + 14]];
      const hits = map.queryRenderedFeatures(box2, { layers: ['aircraft', 'sats', 'ap-point', 'ap-cluster'].filter((l) => map.getLayer(l)) });
      const h = hits[0];
      if (h) {
        const p = h.properties ?? {};
        if (h.layer.id === 'aircraft') return selectAndFly({ type: 'flight', id: String(p.id) });
        if (h.layer.id === 'sats') return selectAndFly({ type: 'satellite', id: Number(p.id) });
        if (h.layer.id === 'ap-point') return selectAirport(String(p.icao));
        if (h.layer.id === 'ap-cluster') { map.easeTo({ center: e.lngLat, zoom: map.getZoom() + 2 }); return; }
      }
      const s = useAppStore.getState();
      if (s.mode === 'earth' || s.mode === 'weather' || s.mode === 'map') s.select({ type: 'location', lat: e.lngLat.lat, lon: e.lngLat.lng });
      else if (s.selection) s.select(null);
    });

    return () => {
      window.clearInterval(id);
      flat.map = null; hud.mode = '3d'; hud.zoom = map.getZoom(); hud.handoff = true;
      map.remove(); mapRef.current = null;
    };
  }, []);

  // basemap switch (skip the first run: the style was set at creation)
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (first.current) { first.current = false; return; }
    map.setStyle(mapService.style(basemap));
  }, [basemap]);

  // airports data
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const push = () => src(map, 'airports')?.setData({ type: 'FeatureCollection', features: airports.map((a) => pt(a.lon, a.lat, { icao: a.icao, kind: a.kind })) });
    if (map.getSource('airports')) push(); else map.once('style.load', push);
  }, [airports]);

  // layer visibility
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const apply = () => {
      const vis = (id: string, on: boolean) => map.getLayer(id) && map.setLayoutProperty(id, 'visibility', on ? 'visible' : 'none');
      vis('aircraft', layers.aircraft); vis('sats', layers.satellites); vis('ap-point', layers.airports); vis('ap-cluster', layers.airports);
    };
    if (map.isStyleLoaded()) apply(); else map.once('style.load', apply);
  }, [layers.aircraft, layers.satellites, layers.airports, basemap]);

  // weather radar overlay
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    let dead = false;
    const remove = () => { if (map.getLayer('radar')) map.removeLayer('radar'); if (map.getSource('radar')) map.removeSource('radar'); };
    const apply = async () => {
      remove();
      if (!layers.weather) return;
      const r = await mapService.radar();
      if (dead || !r || !map.isStyleLoaded()) return;
      map.addSource('radar', { type: 'raster', tiles: [r.tileUrl], tileSize: 256, maxzoom: 7, attribution: r.attribution });
      map.addLayer({ id: 'radar', type: 'raster', source: 'radar', paint: { 'raster-opacity': 0.65 } }, map.getLayer('aircraft') ? 'ap-cluster' : undefined);
    };
    if (map.isStyleLoaded()) void apply(); else map.once('style.load', () => void apply());
    return () => { dead = true; };
  }, [layers.weather, basemap]);

  // user marker
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const push = () => src(map, 'user')?.setData(user ? { type: 'FeatureCollection', features: [pt(user.lon, user.lat, {})] } : empty);
    if (map.getSource('user')) push(); else map.once('style.load', push);
  }, [user]);

  // fly requests
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !fly) return;
    const reduced = useAppStore.getState().settings.motion === 'reduced';
    map.flyTo({ center: [fly.lon, fly.lat], zoom: distanceToZoom(fly.distance), duration: reduced ? 0 : 1600, essential: !reduced });
  }, [fly]);

  return <div ref={box} className="flatmap" role="application" aria-label="Interactive 2D map" />;
}
