export type DataKind = 'LIVE' | 'CALCULATED' | 'PREDICTED' | 'STATIC' | 'DEMO';

export interface SourceMeta {
  source: string;
  kind: DataKind;
  fetchedAt: number; // epoch ms (server fetch time)
  stale?: boolean;
  coverage?: string;
  note?: string;
  demo?: boolean;
  attribution?: string;
  url?: string;
  ttlSec?: number;
}
export interface Envelope<T> { data: T; meta: SourceMeta }

export type AircraftCategory = 'airliner' | 'cargo' | 'helicopter' | 'general' | 'military' | 'unknown';

export interface Aircraft {
  id: string; // ICAO24 hex
  callsign: string | null;
  flightNumber?: string | null; // derived from callsign only when the airline prefix is known
  airline?: string | null;
  registration?: string | null;
  type?: string | null;
  lat: number;
  lon: number;
  altM: number | null;
  speedMs: number | null;
  headingDeg: number | null;
  vsMs: number | null;
  onGround: boolean;
  squawk?: string | null;
  category: AircraftCategory;
  originCountry?: string | null;
  lastContact: number; // unix seconds
  positionAt: number; // unix seconds of the reported position
  source: string;
}

export interface AirportBrief {
  icao: string;
  iata?: string | null;
  name: string;
  city?: string | null;
  country: string;
  lat: number;
  lon: number;
  elevationFt?: number | null;
  kind: 'large' | 'medium' | 'small';
}

export interface FlightDetail {
  id: string;
  registration?: string | null;
  type?: string | null;
  description?: string | null;
  operator?: string | null;
  origin?: AirportBrief | { icao: string; iata?: string | null; name?: string } | null;
  destination?: AirportBrief | { icao: string; iata?: string | null; name?: string } | null;
  routeSource?: string;
}

export interface Movement {
  number: string;
  airline?: string;
  aircraft?: string;
  registration?: string;
  status: string;
  counterpart: { name?: string; iata?: string; icao?: string };
  scheduled?: string; // ISO UTC
  estimated?: string;
  actual?: string;
  delayMin?: number;
  terminal?: string;
  gate?: string;
  cargo?: boolean;
}
export interface Schedule {
  airport: AirportBrief;
  configured: boolean;
  arrivals: Movement[];
  departures: Movement[];
}

export type SatCategory =
  | 'communication' | 'earth-observation' | 'weather' | 'navigation' | 'science' | 'space-station' | 'other';

export interface SatTle { noradId: number; name: string; line1: string; line2: string; category: SatCategory }

export interface WeatherNow {
  time: string;
  temperatureC: number;
  apparentC: number;
  humidity: number;
  pressureHpa: number;
  cloudPct: number;
  windKmh: number;
  windGustKmh: number | null;
  windDirDeg: number;
  visibilityM: number | null;
  code: number;
  isDay: boolean;
}
export interface WeatherReport {
  lat: number;
  lon: number;
  current: WeatherNow;
  hourly: { time: string; tempC: number; precipPct: number | null; code: number; windKmh: number }[];
  daily: { date: string; maxC: number; minC: number; code: number; precipPct: number | null }[];
}

export interface PlaceHit { name: string; admin?: string; country?: string; lat: number; lon: number; feature?: string }
export interface SearchResults {
  flights: Pick<Aircraft, 'id' | 'callsign' | 'flightNumber' | 'airline' | 'registration' | 'lat' | 'lon'>[];
  aircraft: Pick<Aircraft, 'id' | 'callsign' | 'registration' | 'type' | 'lat' | 'lon'>[];
  airports: AirportBrief[];
  satellites: { noradId: number; name: string; category: SatCategory }[];
  cities: PlaceHit[];
  locations: PlaceHit[];
}

export interface NearbyPlace { id: string; name: string; kind: string; lat: number; lon: number }
export interface StreetImage { url: string; capturedAt?: number; attribution: string; link: string }

export interface ServerStatus {
  version: string;
  demo: boolean;
  time: number;
  airportsCount: number;
  layers: Record<string, { provider: string; configured: boolean; note?: string }>;
}
