declare module 'satellite.js';
