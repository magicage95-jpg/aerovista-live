import { lazy, Suspense, useEffect } from 'react';
import { useAppStore } from './stores/useAppStore';
import { useDataFeeds } from './hooks/useDataFeeds';
import ExplorerPage from './pages/ExplorerPage';

const AboutPage = lazy(() => import('./pages/AboutPage'));

export default function App() {
  const page = useAppStore((s) => s.page);
  const setPage = useAppStore((s) => s.setPage);
  const { theme, motion } = useAppStore((s) => s.settings);
  useDataFeeds();

  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => { document.documentElement.dataset.motion = motion; }, [motion]);
  useEffect(() => {
    const sync = () => setPage(window.location.hash.startsWith('#/about') ? 'about' : 'explorer');
    sync();
    window.addEventListener('hashchange', sync);
    return () => window.removeEventListener('hashchange', sync);
  }, [setPage]);

  // Keep the explorer mounted while reading About so the globe and feeds keep their state.
  return (
    <>
      <div hidden={page === 'about'} style={{ display: page === 'about' ? 'none' : undefined }}><ExplorerPage /></div>
      {page === 'about' && <Suspense fallback={null}><AboutPage /></Suspense>}
    </>
  );
}
