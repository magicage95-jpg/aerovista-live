import { apiGet } from './apiClient';
import type { Envelope, SatTle } from '../types';

export interface SatelliteService { list(): Promise<Envelope<SatTle[]>> }
export const satelliteService: SatelliteService = { list: () => apiGet('/api/satellites', { ttlMs: 600_000 }) };
