import { API_BASE } from '../config/env';

export class ApiError extends Error {
  constructor(message: string, public status: number, public retryable: boolean) { super(message); }
}

interface Opts { ttlMs?: number; signal?: AbortSignal; params?: Record<string, string | number | undefined> }
const store = new Map<string, { at: number; value: unknown }>();
const inflight = new Map<string, Promise<unknown>>();

/** GET with client-side caching and in-flight de-duplication. */
export async function apiGet<T>(path: string, { ttlMs = 0, signal, params }: Opts = {}): Promise<T> {
  const qs = params
    ? '?' + Object.entries(params).filter(([, v]) => v !== undefined && v !== '').map(([k, v]) => `${k}=${encodeURIComponent(String(v))}`).join('&')
    : '';
  const url = `${API_BASE}${path}${qs}`;
  const hit = store.get(url);
  if (ttlMs > 0 && hit && Date.now() - hit.at < ttlMs) return hit.value as T;
  const pending = inflight.get(url);
  if (pending && !signal) return pending as Promise<T>;

  const p = (async () => {
    let res: Response;
    try { res = await fetch(url, { signal, headers: { Accept: 'application/json' } }); }
    catch (e) {
      if ((e as Error).name === 'AbortError') throw e;
      throw new ApiError('Live data temporarily unavailable', 0, true);
    }
    if (!res.ok) {
      let msg = 'Live data temporarily unavailable';
      try { msg = ((await res.json()) as { error?: string }).error ?? msg; } catch { /* keep default */ }
      throw new ApiError(msg, res.status, res.status >= 500 || res.status === 429);
    }
    const json = (await res.json()) as T;
    if (ttlMs > 0) store.set(url, { at: Date.now(), value: json });
    return json;
  })().finally(() => inflight.delete(url));
  if (!signal) inflight.set(url, p);
  return p;
}
