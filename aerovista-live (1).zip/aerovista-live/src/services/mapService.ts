import type { StyleSpecification } from 'maplibre-gl';
import { API_BASE } from '../config/env';
import { BASEMAPS, type BasemapId } from '../config/mapProviders';

export interface RadarInfo { tileUrl: string; attribution: string; time: number }

export interface MapService {
  basemap(id: BasemapId): (typeof BASEMAPS)[BasemapId];
  style(id: BasemapId): StyleSpecification;
  imageryUrl(layer: 'bluemarble' | 'night' | 'daily'): string;
  radar(): Promise<RadarInfo | null>;
}

export const mapService: MapService = {
  basemap: (id) => BASEMAPS[id],
  style(id) {
    const b = BASEMAPS[id];
    return {
      version: 8,
      sources: { base: { type: 'raster', tiles: b.tiles, tileSize: b.tileSize, maxzoom: b.maxzoom, attribution: b.attribution } },
      layers: [
        { id: 'bg', type: 'background', paint: { 'background-color': '#04060b' } },
        { id: 'base', type: 'raster', source: 'base' },
      ],
    };
  },
  imageryUrl: (layer) => `${API_BASE}/api/imagery/${layer}.jpg`,
  async radar() {
    try {
      const r = await fetch('https://api.rainviewer.com/public/weather-maps.json');
      if (!r.ok) return null;
      const j = (await r.json()) as { host: string; radar?: { past?: { path: string; time: number }[] } };
      const last = j.radar?.past?.at(-1);
      if (!last) return null;
      return { tileUrl: `${j.host}${last.path}/256/{z}/{x}/{y}/2/1_1.png`, attribution: 'Radar © RainViewer', time: last.time * 1000 };
    } catch { return null; }
  },
};
