import { apiGet } from './apiClient';
import type { AirportBrief, Envelope, Schedule } from '../types';

export interface AirportService {
  markers(): Promise<Envelope<AirportBrief[]>>;
  search(q: string, signal?: AbortSignal): Promise<Envelope<AirportBrief[]>>;
  get(code: string): Promise<Envelope<AirportBrief>>;
  schedule(code: string): Promise<Envelope<Schedule>>;
}
export const airportService: AirportService = {
  markers: () => apiGet('/api/airports/markers', { ttlMs: 3600_000 }),
  search: (q, signal) => apiGet('/api/airports/search', { params: { q }, signal, ttlMs: 60_000 }),
  get: (code) => apiGet(`/api/airports/${code}`, { ttlMs: 3600_000 }),
  schedule: (code) => apiGet(`/api/airports/${code}/schedule`, { ttlMs: 30_000 }),
};
