import { apiGet } from './apiClient';
import type { Envelope, NearbyPlace, SearchResults, StreetImage } from '../types';

export interface GeocodingService {
  search(q: string, signal?: AbortSignal): Promise<Envelope<SearchResults>>;
  nearby(lat: number, lon: number): Promise<Envelope<NearbyPlace[]>>;
  street(lat: number, lon: number): Promise<Envelope<StreetImage | null>>;
}
export const geocodingService: GeocodingService = {
  search: (q, signal) => apiGet('/api/search', { params: { q }, signal, ttlMs: 30_000 }),
  nearby: (lat, lon) => apiGet('/api/geo/places', { params: { lat: lat.toFixed(4), lon: lon.toFixed(4) }, ttlMs: 600_000 }),
  street: (lat, lon) => apiGet('/api/geo/street', { params: { lat: lat.toFixed(5), lon: lon.toFixed(5) }, ttlMs: 600_000 }),
};
