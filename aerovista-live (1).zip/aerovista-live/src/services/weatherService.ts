import { apiGet } from './apiClient';
import type { Envelope, WeatherReport } from '../types';

export interface WeatherService { get(lat: number, lon: number): Promise<Envelope<WeatherReport>> }
export const weatherService: WeatherService = {
  get: (lat, lon) => apiGet('/api/weather', { params: { lat: lat.toFixed(2), lon: lon.toFixed(2) }, ttlMs: 120_000 }),
};
