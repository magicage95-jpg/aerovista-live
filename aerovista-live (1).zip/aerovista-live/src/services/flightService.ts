import { apiGet } from './apiClient';
import type { Aircraft, Envelope, FlightDetail } from '../types';

export interface FlightService {
  getLive(center?: { lat: number; lon: number }): Promise<Envelope<Aircraft[]>>;
  getDetail(id: string): Promise<Envelope<FlightDetail>>;
}
export const flightService: FlightService = {
  getLive: (c) => apiGet('/api/flights', { params: c ? { lat: Math.round(c.lat), lon: Math.round(c.lon) } : undefined }),
  getDetail: (id) => apiGet(`/api/flights/${id}`, { ttlMs: 60_000 }),
};
