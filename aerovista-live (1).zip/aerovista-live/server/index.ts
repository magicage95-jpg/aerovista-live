import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import compression from 'compression';
import { config } from './config';
import { applySecurity } from './middleware/security';
import { errorHandler, notFound } from './middleware/errors';
import { initAirports } from './services/airports';
import { flightsRouter } from './routes/flights';
import { airportsRouter } from './routes/airports';
import { satellitesRouter } from './routes/satellites';
import { weatherRouter } from './routes/weather';
import { searchRouter } from './routes/search';
import { geoRouter } from './routes/geo';
import { imageryRouter } from './routes/imagery';
import { statusRouter } from './routes/status';

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(compression());
applySecurity(app);

app.use('/api/status', statusRouter);
app.use('/api/flights', flightsRouter);
app.use('/api/airports', airportsRouter);
app.use('/api/satellites', satellitesRouter);
app.use('/api/weather', weatherRouter);
app.use('/api/search', searchRouter);
app.use('/api/geo', geoRouter);
app.use('/api/imagery', imageryRouter);
app.use('/api', notFound);

// When the built frontend exists, serve it from the same process (single-service deployment).
const dist = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../dist');
if (fs.existsSync(path.join(dist, 'index.html'))) {
  app.use('/assets', express.static(path.join(dist, 'assets'), { maxAge: '1y', immutable: true }));
  app.use(express.static(dist, { index: false, maxAge: '1h' }));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use(errorHandler);
initAirports();
app.listen(config.port, () => {
  console.log(`AEROVISTA API listening on :${config.port} (${config.env}, demo=${config.demoMode}, flights=${config.flights.provider})`);
});
