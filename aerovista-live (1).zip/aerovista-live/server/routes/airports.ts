import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler, HttpError } from '../middleware/errors';
import { icaoCode, parse, text } from '../middleware/validate';
import { airportCount, airportSource, findAirport, markers, searchAirports } from '../services/airports';
import { getSchedule } from '../services/schedules';
import type { Envelope } from '../../src/types';

export const airportsRouter = Router();

airportsRouter.get('/markers', (_req, res) => {
  const body: Envelope<unknown> = {
    data: markers(),
    meta: { source: airportSource.name, kind: 'STATIC', fetchedAt: airportSource.loadedAt, note: `${airportCount().toLocaleString()} airports in index`, coverage: airportSource.complete ? 'Airports with scheduled service plus larger fields.' : 'Limited built-in list (full dataset unavailable).' },
  };
  res.set('Cache-Control', 'public, max-age=3600').json(body);
});

airportsRouter.get('/search', (req, res) => {
  const { q } = parse(z.object({ q: text(40) }), req.query);
  res.json({ data: searchAirports(q), meta: { source: airportSource.name, kind: 'STATIC', fetchedAt: airportSource.loadedAt } });
});

airportsRouter.get('/:code', (req, res) => {
  const a = findAirport(parse(icaoCode, req.params.code));
  if (!a) throw new HttpError(404, 'Airport not found');
  res.json({ data: a, meta: { source: airportSource.name, kind: 'STATIC', fetchedAt: airportSource.loadedAt } });
});

airportsRouter.get('/:code/schedule', asyncHandler(async (req, res) => {
  const a = findAirport(parse(icaoCode, req.params.code));
  if (!a) throw new HttpError(404, 'Airport not found');
  res.set('Cache-Control', 'public, max-age=30').json(await getSchedule(a));
}));
