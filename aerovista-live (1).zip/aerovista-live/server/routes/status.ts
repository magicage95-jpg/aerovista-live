import { Router } from 'express';
import { config } from '../config';
import { airportCount } from '../services/airports';
import { flightsProviderStatus } from '../services/flights';
import type { ServerStatus } from '../../src/types';

export const statusRouter = Router();
statusRouter.get('/', (_req, res) => {
  const f = flightsProviderStatus();
  const body: ServerStatus = {
    version: '1.0.0',
    demo: config.demoMode === 'on' || config.flights.provider === 'demo',
    time: Date.now(),
    airportsCount: airportCount(),
    layers: {
      flights: f,
      schedules: { provider: 'AeroDataBox', configured: Boolean(config.schedules.key), note: config.schedules.key ? undefined : 'Arrivals/departures need FLIGHT_API_KEY.' },
      satellites: { provider: 'CelesTrak', configured: true },
      weather: { provider: 'Open-Meteo', configured: true, note: config.weatherKey ? 'Commercial key set.' : 'Free non-commercial endpoint.' },
      street: { provider: 'Mapillary', configured: Boolean(config.mapillaryToken) },
    },
  };
  res.set('Cache-Control', 'no-store').json(body);
});
