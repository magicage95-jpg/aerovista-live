import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../middleware/errors';
import { lat, lon, parse } from '../middleware/validate';
import { getWeather } from '../services/weather';

export const weatherRouter = Router();
weatherRouter.get('/', asyncHandler(async (req, res) => {
  const q = parse(z.object({ lat, lon }), req.query);
  res.set('Cache-Control', 'public, max-age=120').json(await getWeather(q.lat, q.lon));
}));
