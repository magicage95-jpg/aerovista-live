import { Router } from 'express';
import { asyncHandler } from '../middleware/errors';
import { lat, lon, parse } from '../middleware/validate';
import { z } from 'zod';
import { nearbyPlaces, streetImage } from '../services/geo';

export const geoRouter = Router();
const pt = z.object({ lat, lon });

geoRouter.get('/places', asyncHandler(async (req, res) => {
  const { lat: la, lon: lo } = parse(pt, req.query);
  const data = await nearbyPlaces(la, lo);
  res.set('Cache-Control', 'public, max-age=600').json({
    data,
    meta: { source: 'OpenStreetMap via Overpass API', kind: 'STATIC', fetchedAt: Date.now(), attribution: '© OpenStreetMap contributors (ODbL)' },
  });
}));

geoRouter.get('/street', asyncHandler(async (req, res) => {
  const { lat: la, lon: lo } = parse(pt, req.query);
  const img = await streetImage(la, lo);
  res.set('Cache-Control', 'public, max-age=600').json({
    data: img === 'unconfigured' ? null : img,
    meta: {
      source: 'Mapillary', kind: 'STATIC', fetchedAt: Date.now(),
      note: img === 'unconfigured' ? 'Street-level imagery is not configured (set MAPILLARY_TOKEN).' : img ? undefined : 'No street-level imagery found near this location.',
    },
  });
}));
