import { Router } from 'express';
import { asyncHandler, HttpError } from '../middleware/errors';
import { getImagery, isImageryLayer } from '../services/imagery';

export const imageryRouter = Router();
imageryRouter.get('/:layer.jpg', asyncHandler(async (req, res) => {
  const layer = req.params.layer;
  if (!isImageryLayer(layer)) throw new HttpError(404, 'Unknown imagery layer');
  const img = await getImagery(layer);
  res.set({ 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=21600', 'X-Imagery-Date': img.date ?? 'static' }).send(img.buf);
}));
