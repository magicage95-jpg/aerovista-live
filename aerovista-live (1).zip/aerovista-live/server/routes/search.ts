import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler } from '../middleware/errors';
import { parse, text } from '../middleware/validate';
import { searchAirports } from '../services/airports';
import { searchAirlines } from '../services/airlines';
import { currentAircraft } from '../services/flights';
import { currentSatellites } from '../services/satellites';
import { geocode } from '../services/geo';
import type { Envelope, PlaceHit, SearchResults } from '../../src/types';

export const searchRouter = Router();

const CITY = /^PPL/;

searchRouter.get('/', asyncHandler(async (req, res) => {
  const { q } = parse(z.object({ q: text(60) }), req.query);
  const s = q.toLowerCase();
  const compact = s.replace(/\s+/g, '');
  const airlinePrefixes = new Set(searchAirlines(s).map((x) => x.toUpperCase()));

  const flights = currentAircraft().filter((a) =>
    (a.callsign && a.callsign.toLowerCase().startsWith(compact)) ||
    (a.flightNumber && a.flightNumber.toLowerCase() === compact) ||
    a.id === compact ||
    (a.callsign && airlinePrefixes.has(a.callsign.slice(0, 3))) ||
    (a.airline && a.airline.toLowerCase().includes(s) && s.length >= 3),
  ).slice(0, 8).map((a) => ({ id: a.id, callsign: a.callsign, flightNumber: a.flightNumber, airline: a.airline, registration: a.registration, lat: a.lat, lon: a.lon }));

  const aircraft = currentAircraft().filter((a) => a.registration && a.registration.toLowerCase().replace(/-/g, '').startsWith(compact.replace(/-/g, ''))).slice(0, 6)
    .map((a) => ({ id: a.id, callsign: a.callsign, registration: a.registration, type: a.type, lat: a.lat, lon: a.lon }));

  const satellites = currentSatellites().filter((t) => t.name.toLowerCase().includes(s) || String(t.noradId) === s).slice(0, 8)
    .map((t) => ({ noradId: t.noradId, name: t.name, category: t.category }));

  let places: PlaceHit[] = [];
  const degraded: string[] = [];
  if (q.length >= 3) { try { places = await geocode(q, 8); } catch { degraded.push('places'); } }

  const data: SearchResults = {
    flights, aircraft, satellites,
    airports: searchAirports(q, 6),
    cities: places.filter((p) => !p.feature || CITY.test(p.feature)).slice(0, 5),
    locations: places.filter((p) => p.feature && !CITY.test(p.feature)).slice(0, 4),
  };
  const body: Envelope<SearchResults> = {
    data,
    meta: { source: 'AEROVISTA search (airports, live feed, catalogue, Open-Meteo geocoding)', kind: 'CALCULATED', fetchedAt: Date.now(), note: degraded.length ? `Place search unavailable right now.` : 'Flight and aircraft results cover only aircraft in the current provider feed.' },
  };
  res.json(body);
}));
