import { Router } from 'express';
import { z } from 'zod';
import { asyncHandler, HttpError } from '../middleware/errors';
import { hex24, lat, lon, parse } from '../middleware/validate';
import { currentAircraft, getFlights } from '../services/flights';
import { flightDetail } from '../services/flights/enrich';
import type { Envelope, FlightDetail } from '../../src/types';

export const flightsRouter = Router();

flightsRouter.get('/', asyncHandler(async (req, res) => {
  const q = parse(z.object({
    lat: lat.optional(), lon: lon.optional(),
    radiusNm: z.coerce.number().min(10).max(250).optional(),
    ground: z.enum(['0', '1']).optional(),
  }), req.query);
  const out = await getFlights({ lat: q.lat, lon: q.lon, radiusNm: q.radiusNm, includeGround: q.ground === '1' });
  res.set('Cache-Control', 'public, max-age=5').json(out);
}));

flightsRouter.get('/:id', asyncHandler(async (req, res) => {
  const id = parse(hex24, req.params.id).toLowerCase();
  const ac = currentAircraft().find((a) => a.id === id);
  if (!ac) throw new HttpError(404, 'Aircraft is no longer in the current feed');
  const d = await flightDetail(id, ac.callsign ?? undefined, ac.lat, ac.lon);
  const body: Envelope<FlightDetail> = {
    data: d.value,
    meta: { source: 'adsb.lol (registration and route lookup)', kind: 'LIVE', fetchedAt: d.fetchedAt, ttlSec: 600, note: 'Route data is community-sourced and may be missing or wrong.' },
  };
  res.set('Cache-Control', 'public, max-age=30').json(body);
}));
