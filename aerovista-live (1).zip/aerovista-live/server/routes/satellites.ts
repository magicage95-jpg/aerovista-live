import { Router } from 'express';
import { asyncHandler } from '../middleware/errors';
import { getSatellites } from '../services/satellites';

export const satellitesRouter = Router();
satellitesRouter.get('/', asyncHandler(async (_req, res) => {
  res.set('Cache-Control', 'public, max-age=600').json(await getSatellites());
}));
