import { userAgent } from '../config';

export class UpstreamError extends Error {
  constructor(message: string, public status = 502, public provider = 'upstream') {
    super(message);
  }
}

interface Opts extends Omit<RequestInit, 'signal'> { timeoutMs?: number; provider?: string }

async function request(url: string, opts: Opts): Promise<Response> {
  const provider = opts.provider ?? 'upstream';
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 12_000);
  try {
    const res = await fetch(url, {
      ...opts,
      signal: ctrl.signal,
      headers: { 'User-Agent': userAgent, ...(opts.headers as Record<string, string> | undefined) },
    });
    if (!res.ok) throw new UpstreamError(`${provider} responded with ${res.status}`, res.status === 429 ? 429 : 502, provider);
    return res;
  } catch (e) {
    if (e instanceof UpstreamError) throw e;
    throw new UpstreamError(`${provider} is unreachable`, 504, provider);
  } finally {
    clearTimeout(timer);
  }
}

export async function fetchJson<T>(url: string, opts: Opts = {}): Promise<T> {
  const res = await request(url, { ...opts, headers: { Accept: 'application/json', ...(opts.headers as Record<string, string> | undefined) } });
  try {
    return (await res.json()) as T;
  } catch {
    throw new UpstreamError(`${opts.provider ?? 'upstream'} returned invalid data`, 502, opts.provider);
  }
}
export async function fetchText(url: string, opts: Opts = {}): Promise<string> {
  return (await request(url, opts)).text();
}
export async function fetchBuffer(url: string, opts: Opts = {}): Promise<{ buf: Buffer; type: string }> {
  const res = await request(url, opts);
  return { buf: Buffer.from(await res.arrayBuffer()), type: res.headers.get('content-type') ?? 'application/octet-stream' };
}
