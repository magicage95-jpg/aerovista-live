import 'dotenv/config';

const num = (v: string | undefined, d: number) => {
  if (v === undefined || v.trim() === '') return d;
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
};
const str = (v: string | undefined) => (v && v.trim() ? v.trim() : undefined);

export type FlightProviderId = 'auto' | 'opensky' | 'adsblol' | 'demo';

export const config = {
  port: num(process.env.PORT, 8787),
  env: process.env.NODE_ENV ?? 'development',
  corsOrigins: (process.env.CORS_ORIGINS ?? 'http://localhost:5173').split(',').map((s) => s.trim()).filter(Boolean),
  contact: str(process.env.CONTACT_EMAIL),
  rateLimitPerMin: num(process.env.RATE_LIMIT_PER_MIN, 240),
  demoMode: (['auto', 'on', 'off'].includes(process.env.DEMO_MODE ?? '') ? process.env.DEMO_MODE : 'auto') as 'auto' | 'on' | 'off',
  flights: {
    provider: (['auto', 'opensky', 'adsblol', 'demo'].includes(process.env.FLIGHT_PROVIDER ?? '')
      ? process.env.FLIGHT_PROVIDER
      : 'auto') as FlightProviderId,
    openskyId: str(process.env.OPENSKY_CLIENT_ID),
    openskySecret: str(process.env.OPENSKY_CLIENT_SECRET),
    cacheTtlSec: process.env.FLIGHT_CACHE_TTL_SEC ? num(process.env.FLIGHT_CACHE_TTL_SEC, 0) : 0,
  },
  schedules: {
    key: str(process.env.FLIGHT_API_KEY),
    host: str(process.env.FLIGHT_API_HOST) ?? 'aerodatabox.p.rapidapi.com',
  },
  weatherKey: str(process.env.WEATHER_API_KEY),
  mapillaryToken: str(process.env.MAPILLARY_TOKEN),
};

export const userAgent = `AEROVISTA-LIVE/1.0 (+${config.contact ?? 'no-contact-configured'})`;
