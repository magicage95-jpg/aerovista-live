interface Entry<T> { value: T; at: number; expires: number }
export interface Cached<T> { value: T; fetchedAt: number; stale: boolean }

/** Small TTL cache with in-flight de-duplication and stale-if-error. */
export class TtlCache {
  private store = new Map<string, Entry<unknown>>();
  private inflight = new Map<string, Promise<Cached<unknown>>>();
  constructor(private maxEntries = 400) {}

  peek<T>(key: string): Cached<T> | undefined {
    const e = this.store.get(key) as Entry<T> | undefined;
    return e ? { value: e.value, fetchedAt: e.at, stale: e.expires < Date.now() } : undefined;
  }

  async wrap<T>(key: string, ttlMs: number, loader: () => Promise<T>, maxStaleMs = 3_600_000): Promise<Cached<T>> {
    const now = Date.now();
    const hit = this.store.get(key) as Entry<T> | undefined;
    if (hit && hit.expires > now) return { value: hit.value, fetchedAt: hit.at, stale: false };
    const pending = this.inflight.get(key) as Promise<Cached<T>> | undefined;
    if (pending) return pending;

    const p = (async (): Promise<Cached<T>> => {
      try {
        const value = await loader();
        const at = Date.now();
        this.store.delete(key);
        this.store.set(key, { value, at, expires: at + ttlMs });
        this.evict();
        return { value, fetchedAt: at, stale: false };
      } catch (err) {
        if (hit && now - hit.at < maxStaleMs) return { value: hit.value, fetchedAt: hit.at, stale: true };
        throw err;
      } finally {
        this.inflight.delete(key);
      }
    })();
    this.inflight.set(key, p as Promise<Cached<unknown>>);
    return p;
  }

  private evict() {
    while (this.store.size > this.maxEntries) {
      const oldest = this.store.keys().next().value as string | undefined;
      if (oldest === undefined) break;
      this.store.delete(oldest);
    }
  }
}

/** Serialises calls to one upstream and enforces a minimum gap between them. */
export class Throttler {
  private next = 0;
  constructor(private minGapMs: number) {}
  async run<T>(fn: () => Promise<T>): Promise<T> {
    const now = Date.now();
    const start = Math.max(now, this.next);
    this.next = start + this.minGapMs;
    if (start > now) await new Promise((r) => setTimeout(r, start - now));
    return fn();
  }
}

export const cache = new TtlCache(600);
