import type { ErrorRequestHandler, NextFunction, Request, RequestHandler, Response } from 'express';
import { UpstreamError } from '../utils/http';

export class HttpError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export const asyncHandler =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => { fn(req, res, next).catch(next); };

export const notFound: RequestHandler = (_req, res) => { res.status(404).json({ error: 'Not found' }); };

// Never leak stack traces or upstream details to the browser.
export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  if (err instanceof HttpError) return void res.status(err.status).json({ error: err.message });
  if (err instanceof UpstreamError) {
    console.warn(`[upstream] ${err.provider}: ${err.message}`);
    return void res.status(err.status === 429 ? 429 : 503).json({
      error: 'Live data temporarily unavailable',
      provider: err.provider,
      retryable: true,
    });
  }
  console.error('[error]', err instanceof Error ? err.message : err);
  res.status(500).json({ error: 'Something went wrong on the server' });
};
