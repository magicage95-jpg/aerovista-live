import { z, type ZodTypeAny } from 'zod';
import { HttpError } from './errors';

export function parse<S extends ZodTypeAny>(schema: S, data: unknown): z.infer<S> {
  const r = schema.safeParse(data);
  if (!r.success) throw new HttpError(400, 'Invalid request parameters');
  return r.data;
}

export const lat = z.coerce.number().min(-90).max(90);
export const lon = z.coerce.number().min(-180).max(180);
/** Strips control characters and caps length. */
export const text = (max = 80) =>
  z.string().transform((s) => s.replace(/[\u0000-\u001f\u007f<>]/g, '').trim()).pipe(z.string().min(1).max(max));
export const hex24 = z.string().regex(/^[0-9a-fA-F]{6}$/);
export const icaoCode = z.string().regex(/^[A-Za-z0-9]{3,4}$/);
