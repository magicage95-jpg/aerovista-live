import { cache } from '../cache/memoryCache';
import { fetchBuffer } from '../utils/http';

// Allow-list: the browser can never make this proxy fetch arbitrary layers.
const LAYERS = {
  bluemarble: { id: 'BlueMarble_ShadedRelief_Bathymetry', w: 4096, h: 2048, timed: false, ttl: 7 * 86400_000 },
  night: { id: 'VIIRS_Black_Marble', w: 2048, h: 1024, timed: false, ttl: 7 * 86400_000 },
  daily: { id: 'MODIS_Terra_CorrectedReflectance_TrueColor', w: 4096, h: 2048, timed: true, ttl: 6 * 3600_000 },
} as const;
export type ImageryLayer = keyof typeof LAYERS;
export const isImageryLayer = (s: string): s is ImageryLayer => s in LAYERS;

export async function getImagery(layer: ImageryLayer) {
  const L = LAYERS[layer];
  const date = new Date(Date.now() - 86400_000).toISOString().slice(0, 10); // yesterday UTC: today's mosaic is incomplete
  const key = `img:${layer}:${L.timed ? date : 'static'}`;
  const r = await cache.wrap(key, L.ttl, async () => {
    const q = new URLSearchParams({
      SERVICE: 'WMS', REQUEST: 'GetMap', VERSION: '1.1.1', LAYERS: L.id, STYLES: '', FORMAT: 'image/jpeg',
      SRS: 'EPSG:4326', BBOX: '-180,-90,180,90', WIDTH: String(L.w), HEIGHT: String(L.h),
    });
    if (L.timed) q.set('TIME', date);
    return fetchBuffer(`https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi?${q}`, { provider: 'NASA GIBS', timeoutMs: 40_000 });
  }, 7 * 86400_000);
  return { ...r.value, date: L.timed ? date : null };
}
