import data from '../data/airlines.json';
import type { AircraftCategory } from '../../src/types';

const AIRLINES = data as unknown as Record<string, [string, string, number]>;

export interface CallsignInfo { airline: string | null; flightNumber: string | null; cargo: boolean }

/** ICAO callsigns look like "BAW123". We only claim an airline / flight number when the 3-letter prefix is known. */
export function parseCallsign(callsign: string | null): CallsignInfo {
  const none = { airline: null, flightNumber: null, cargo: false };
  if (!callsign) return none;
  const m = /^([A-Z]{3})(\d{1,4}[A-Z]?)$/.exec(callsign);
  if (!m) return none;
  const a = AIRLINES[m[1]];
  if (!a) return none;
  return { airline: a[0], flightNumber: `${a[1]}${m[2]}`, cargo: a[2] === 1 };
}

export function searchAirlines(q: string): string[] {
  const s = q.toLowerCase();
  return Object.entries(AIRLINES)
    .filter(([icao, [name, iata]]) => icao.toLowerCase() === s || iata.toLowerCase() === s || name.toLowerCase().includes(s))
    .map(([icao]) => icao);
}
export const airlineName = (icao: string) => AIRLINES[icao]?.[0] ?? null;

export function categoryFromOpenSky(c: number | null | undefined, cargo: boolean): AircraftCategory {
  if (cargo) return 'cargo';
  if (c === 8) return 'helicopter';
  if (c === 2 || c === 3 || c === 9 || c === 10 || c === 11 || c === 12) return 'general';
  if (c === 4 || c === 5 || c === 6) return 'airliner';
  return 'unknown';
}
export function categoryFromAdsb(c: string | undefined, cargo: boolean, military: boolean): AircraftCategory {
  if (military) return 'military';
  if (cargo) return 'cargo';
  if (c === 'A7') return 'helicopter';
  if (c === 'A1' || c === 'A2' || c === 'B1' || c === 'B2' || c === 'B4') return 'general';
  if (c === 'A3' || c === 'A4' || c === 'A5') return 'airliner';
  return 'unknown';
}
