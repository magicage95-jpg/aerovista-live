import { config } from '../config';
import { cache, Throttler } from '../cache/memoryCache';
import { fetchJson } from '../utils/http';
import type { AirportBrief, Envelope, Movement, Schedule } from '../../src/types';

const throttle = new Throttler(1_100);

interface AdbTime { utc?: string; local?: string }
interface AdbItem {
  number?: string; status?: string; isCargo?: boolean;
  movement?: { airport?: { icao?: string; iata?: string; name?: string }; scheduledTime?: AdbTime; revisedTime?: AdbTime; runwayTime?: AdbTime; terminal?: string; gate?: string };
  aircraft?: { model?: string; reg?: string };
  airline?: { name?: string };
}
const iso = (t?: AdbTime) => {
  if (!t?.utc) return undefined;
  const d = new Date(t.utc.replace(' ', 'T'));
  return isNaN(d.getTime()) ? undefined : d.toISOString();
};

function mapItem(i: AdbItem): Movement {
  const scheduled = iso(i.movement?.scheduledTime);
  const estimated = iso(i.movement?.revisedTime);
  const actual = iso(i.movement?.runwayTime);
  const ref = estimated ?? scheduled;
  return {
    number: i.number ?? '—',
    airline: i.airline?.name, aircraft: i.aircraft?.model, registration: i.aircraft?.reg,
    status: i.status ?? 'Unknown',
    counterpart: { name: i.movement?.airport?.name, iata: i.movement?.airport?.iata, icao: i.movement?.airport?.icao },
    scheduled, estimated, actual,
    delayMin: scheduled && estimated ? Math.round((new Date(estimated).getTime() - new Date(scheduled).getTime()) / 60000) : undefined,
    terminal: i.movement?.terminal, gate: i.movement?.gate, cargo: i.isCargo,
    ...(ref ? {} : {}),
  };
}

function demoSchedule(a: AirportBrief): Schedule {
  const names = ['Demo Airways', 'Sample Air', 'Placeholder Jet'];
  const mk = (dir: 'a' | 'd', n: number): Movement => {
    const t = new Date(Date.now() + (n - 3) * 17 * 60_000);
    return {
      number: `DM${100 + n * 7}`, airline: names[n % 3], aircraft: 'Sample A320',
      status: n < 3 ? (dir === 'a' ? 'Arrived' : 'Departed') : 'Expected',
      counterpart: { name: 'Sample Airport', iata: 'XXX' },
      scheduled: t.toISOString(), terminal: String(1 + (n % 3)), gate: `${'ABC'[n % 3]}${10 + n}`,
    };
  };
  return { airport: a, configured: false, arrivals: Array.from({ length: 8 }, (_, n) => mk('a', n)), departures: Array.from({ length: 8 }, (_, n) => mk('d', n)) };
}

export async function getSchedule(airport: AirportBrief): Promise<Envelope<Schedule>> {
  const demo = config.demoMode === 'on';
  if (demo) {
    return { data: demoSchedule(airport), meta: { source: 'DEMO DATA (simulated)', kind: 'DEMO', demo: true, fetchedAt: Date.now(), note: 'Sample schedule. Not real flights.' } };
  }
  if (!config.schedules.key) {
    return {
      data: { airport, configured: false, arrivals: [], departures: [] },
      meta: { source: 'AeroDataBox (not configured)', kind: 'LIVE', fetchedAt: Date.now(), note: 'Set FLIGHT_API_KEY on the server to enable arrivals and departures.' },
    };
  }
  const { key, host } = config.schedules;
  const r = await cache.wrap(`sched:${airport.icao}`, 5 * 60_000, () =>
    throttle.run(async () => {
      const url = `https://${host}/flights/airports/icao/${airport.icao}?offsetMinutes=-120&durationMinutes=600&direction=Both&withLeg=false&withCancelled=true&withCodeshared=false&withCargo=true&withPrivate=false&withLocation=false`;
      const j = await fetchJson<{ arrivals?: AdbItem[]; departures?: AdbItem[] }>(url, {
        provider: 'AeroDataBox',
        headers: { 'x-rapidapi-key': key, 'x-rapidapi-host': host },
      });
      const sort = (a: Movement, b: Movement) => (a.estimated ?? a.scheduled ?? '').localeCompare(b.estimated ?? b.scheduled ?? '');
      return { arrivals: (j.arrivals ?? []).map(mapItem).sort(sort), departures: (j.departures ?? []).map(mapItem).sort(sort) };
    }),
  );
  return {
    data: { airport, configured: true, ...r.value },
    meta: {
      source: 'AeroDataBox (via RapidAPI)', url: 'https://aerodatabox.com', kind: 'LIVE',
      fetchedAt: r.fetchedAt, stale: r.stale, ttlSec: 300,
      note: 'Times are UTC. Schedule coverage and accuracy depend on the provider and your plan.',
    },
  };
}
