import seed from '../data/airports.seed.json';
import { fetchText } from '../utils/http';
import { parseCsv } from '../utils/csv';
import type { AirportBrief } from '../../src/types';

const SOURCE_URL = 'https://davidmegginson.github.io/ourairports-data/airports.csv';
const REFRESH_MS = 24 * 3600_000;

let airports: AirportBrief[] = [];
let byIcao = new Map<string, AirportBrief>();
let byIata = new Map<string, AirportBrief>();
export let airportSource: { name: string; loadedAt: number; complete: boolean } = { name: 'Built-in seed list', loadedAt: Date.now(), complete: false };

const regionNames = (() => {
  try { return new Intl.DisplayNames(['en'], { type: 'region' }); } catch { return null; }
})();
const countryName = (code: string) => { try { return regionNames?.of(code) ?? code; } catch { return code; } };

function index(list: AirportBrief[]) {
  airports = list;
  byIcao = new Map(list.map((a) => [a.icao, a]));
  byIata = new Map(list.filter((a) => a.iata).map((a) => [a.iata as string, a]));
}

function loadSeed() {
  index((seed as unknown as [string, string, string, string, string, number, number][]).map(([icao, iata, name, city, country, lat, lon]) => ({
    icao, iata, name, city, country, lat, lon, kind: 'large' as const,
  })));
}

export async function refreshAirports() {
  try {
    const rows = parseCsv(await fetchText(SOURCE_URL, { provider: 'OurAirports', timeoutMs: 30_000 }));
    const head = rows[0];
    const col = (n: string) => head.indexOf(n);
    const [iType, iName, iLat, iLon, iElev, iCountry, iCity, iSched, iIcao, iIata, iIdent] =
      ['type', 'name', 'latitude_deg', 'longitude_deg', 'elevation_ft', 'iso_country', 'municipality', 'scheduled_service', 'icao_code', 'iata_code', 'ident'].map(col);
    const list: AirportBrief[] = [];
    for (let r = 1; r < rows.length; r++) {
      const x = rows[r];
      const type = x[iType];
      if (type !== 'large_airport' && type !== 'medium_airport' && type !== 'small_airport') continue;
      if (x[iSched] !== 'yes' && type === 'small_airport') continue;
      const lat = parseFloat(x[iLat]), lon = parseFloat(x[iLon]);
      const icao = (x[iIcao] || x[iIdent] || '').toUpperCase();
      if (!icao || !isFinite(lat) || !isFinite(lon)) continue;
      list.push({
        icao, iata: x[iIata] ? x[iIata].toUpperCase() : null, name: x[iName], city: x[iCity] || null,
        country: countryName(x[iCountry]), lat, lon,
        elevationFt: x[iElev] ? parseInt(x[iElev], 10) : null,
        kind: type === 'large_airport' ? 'large' : type === 'medium_airport' ? 'medium' : 'small',
      });
    }
    if (list.length > 500) {
      index(list);
      airportSource = { name: 'OurAirports (public domain)', loadedAt: Date.now(), complete: true };
      console.log(`[airports] loaded ${list.length} airports from OurAirports`);
    }
  } catch (e) {
    console.warn('[airports] OurAirports unavailable, using seed list:', e instanceof Error ? e.message : e);
  }
}

export function initAirports() {
  loadSeed();
  void refreshAirports();
  setInterval(() => void refreshAirports(), REFRESH_MS).unref();
}

export const airportCount = () => airports.length;
export const findAirport = (code: string) => {
  const c = code.toUpperCase();
  return byIcao.get(c) ?? byIata.get(c);
};
export const markers = () => airports.filter((a) => a.kind !== 'small');

export function searchAirports(q: string, limit = 8): AirportBrief[] {
  const s = q.trim().toLowerCase();
  if (s.length < 2) return [];
  const scored: [number, AirportBrief][] = [];
  for (const a of airports) {
    const iata = a.iata?.toLowerCase(), icao = a.icao.toLowerCase(), name = a.name.toLowerCase(), city = (a.city ?? '').toLowerCase();
    let score = 0;
    if (iata === s || icao === s) score = 100;
    else if (iata?.startsWith(s) || icao.startsWith(s)) score = 70;
    else if (city.startsWith(s)) score = 60;
    else if (name.includes(s)) score = 40;
    else if (city.includes(s) || a.country.toLowerCase() === s) score = 30;
    if (score) scored.push([score + (a.kind === 'large' ? 8 : a.kind === 'medium' ? 3 : 0), a]);
  }
  return scored.sort((x, y) => y[0] - x[0]).slice(0, limit).map((x) => x[1]);
}
