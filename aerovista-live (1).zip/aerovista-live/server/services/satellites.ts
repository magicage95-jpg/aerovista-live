import { cache, Throttler } from '../cache/memoryCache';
import { fetchText } from '../utils/http';
import type { Envelope, SatCategory, SatTle } from '../../src/types';

const throttle = new Throttler(400);
// Categories are only assigned from the CelesTrak group a satellite was found in, which is reliable.
const GROUPS: { group: string; category: SatCategory }[] = [
  { group: 'stations', category: 'space-station' },
  { group: 'weather', category: 'weather' },
  { group: 'resource', category: 'earth-observation' },
  { group: 'gps-ops', category: 'navigation' },
  { group: 'galileo', category: 'navigation' },
  { group: 'glo-ops', category: 'navigation' },
  { group: 'beidou', category: 'navigation' },
  { group: 'intelsat', category: 'communication' },
  { group: 'ses', category: 'communication' },
  { group: 'iridium-NEXT', category: 'communication' },
  { group: 'globalstar', category: 'communication' },
  { group: 'orbcomm', category: 'communication' },
  { group: 'science', category: 'science' },
  { group: 'visual', category: 'other' },
];

function parseTle(text: string, category: SatCategory): SatTle[] {
  const lines = text.split(/\r?\n/).map((l) => l.trimEnd()).filter(Boolean);
  const out: SatTle[] = [];
  for (let i = 0; i + 2 < lines.length; i += 3) {
    const [name, l1, l2] = [lines[i], lines[i + 1], lines[i + 2]];
    if (!l1.startsWith('1 ') || !l2.startsWith('2 ')) continue;
    const id = parseInt(l1.slice(2, 7), 10);
    if (!Number.isFinite(id)) continue;
    out.push({ noradId: id, name: name.trim(), line1: l1, line2: l2, category });
  }
  return out;
}

let latest: SatTle[] = [];
export const currentSatellites = () => latest;

export async function getSatellites(): Promise<Envelope<SatTle[]>> {
  const r = await cache.wrap('sats:all', 2 * 3600_000, async () => {
    const seen = new Map<number, SatTle>();
    let ok = 0;
    for (const g of GROUPS) {
      try {
        const txt = await throttle.run(() => fetchText(`https://celestrak.org/NORAD/elements/gp.php?GROUP=${g.group}&FORMAT=tle`, { provider: 'CelesTrak', timeoutMs: 20_000 }));
        ok++;
        for (const s of parseTle(txt, g.category)) if (!seen.has(s.noradId)) seen.set(s.noradId, s);
      } catch { /* keep going: one failing group must not block the rest */ }
    }
    if (ok === 0) throw new Error('CelesTrak unreachable');
    return [...seen.values()];
  }, 24 * 3600_000);
  latest = r.value;
  return {
    data: r.value,
    meta: {
      source: 'CelesTrak (orbital elements)', url: 'https://celestrak.org', kind: 'PREDICTED',
      fetchedAt: r.fetchedAt, stale: r.stale, ttlSec: 7200,
      note: 'Positions are calculated in your browser from public orbital elements (SGP4). They are predictions, not live telemetry.',
      attribution: 'Orbital elements from CelesTrak (Dr. T.S. Kelso).',
      coverage: 'Selected public catalogue groups, not every object in orbit.',
    },
  };
}
