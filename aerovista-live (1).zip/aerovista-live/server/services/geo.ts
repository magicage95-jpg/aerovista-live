import { config } from '../config';
import { cache, Throttler } from '../cache/memoryCache';
import { fetchJson } from '../utils/http';
import type { NearbyPlace, PlaceHit, StreetImage } from '../../src/types';

const overpassGate = new Throttler(1_500);

export async function geocode(q: string, count = 6): Promise<PlaceHit[]> {
  const key = `geo:${q.toLowerCase()}:${count}`;
  const r = await cache.wrap(key, 24 * 3600_000, async () => {
    const j = await fetchJson<{ results?: { name: string; admin1?: string; country?: string; latitude: number; longitude: number; feature_code?: string }[] }>(
      `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(q)}&count=${count}&language=en&format=json`,
      { provider: 'Open-Meteo Geocoding', timeoutMs: 8000 },
    );
    return (j.results ?? []).map((x): PlaceHit => ({ name: x.name, admin: x.admin1, country: x.country, lat: x.latitude, lon: x.longitude, feature: x.feature_code }));
  });
  return r.value;
}

export async function nearbyPlaces(lat: number, lon: number): Promise<NearbyPlace[]> {
  const la = lat.toFixed(3), lo = lon.toFixed(3);
  const r = await cache.wrap(`places:${la}:${lo}`, 3600_000, () =>
    overpassGate.run(async () => {
      const ql = `[out:json][timeout:15];(nwr(around:1200,${la},${lo})["name"]["amenity"];nwr(around:1200,${la},${lo})["name"]["tourism"];nwr(around:1200,${la},${lo})["name"]["aeroway"="terminal"];);out center 40;`;
      const j = await fetchJson<{ elements?: { id: number; type: string; lat?: number; lon?: number; center?: { lat: number; lon: number }; tags?: Record<string, string> }[] }>(
        'https://overpass-api.de/api/interpreter',
        { provider: 'OpenStreetMap Overpass', method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `data=${encodeURIComponent(ql)}`, timeoutMs: 20_000 },
      );
      return (j.elements ?? []).flatMap((e): NearbyPlace[] => {
        const p = e.lat != null ? { lat: e.lat, lon: e.lon as number } : e.center;
        if (!p || !e.tags?.name) return [];
        return [{ id: `${e.type}/${e.id}`, name: e.tags.name, kind: e.tags.amenity ?? e.tags.tourism ?? e.tags.aeroway ?? 'place', lat: p.lat, lon: p.lon }];
      }).slice(0, 25);
    }),
  );
  return r.value;
}

export async function streetImage(lat: number, lon: number): Promise<StreetImage | null | 'unconfigured'> {
  if (!config.mapillaryToken) return 'unconfigured';
  const d = 0.0008;
  const r = await cache.wrap(`street:${lat.toFixed(4)}:${lon.toFixed(4)}`, 6 * 3600_000, async () => {
    const j = await fetchJson<{ data?: { id: string; thumb_1024_url?: string; captured_at?: number }[] }>(
      `https://graph.mapillary.com/images?access_token=${encodeURIComponent(config.mapillaryToken as string)}&fields=id,thumb_1024_url,captured_at&bbox=${lon - d},${lat - d},${lon + d},${lat + d}&limit=1`,
      { provider: 'Mapillary', timeoutMs: 8000 },
    );
    const img = j.data?.[0];
    if (!img?.thumb_1024_url) return null;
    return { url: img.thumb_1024_url, capturedAt: img.captured_at, attribution: 'Imagery © Mapillary contributors, CC BY-SA', link: `https://www.mapillary.com/app/?pKey=${img.id}` } satisfies StreetImage;
  });
  return r.value;
}
