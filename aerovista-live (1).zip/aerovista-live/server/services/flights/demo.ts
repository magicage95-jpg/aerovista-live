import { airportCount, findAirport } from '../airports';
import { bearingDeg, haversineM, intermediate } from '../../../src/utils/geo';
import type { Aircraft } from '../../../src/types';
import type { FlightProvider } from './types';

const PAIRS: [string, string][] = [
  ['KJFK', 'EGLL'], ['KLAX', 'RJTT'], ['OMDB', 'EGLL'], ['WSSS', 'YSSY'], ['EDDF', 'KORD'], ['VHHH', 'KSFO'],
  ['FAOR', 'OMDB'], ['SBGR', 'LEMD'], ['EHAM', 'KJFK'], ['RKSI', 'KLAX'], ['VIDP', 'EGLL'], ['LFPG', 'OTHH'],
  ['YSSY', 'NZAA'], ['KATL', 'MMMX'], ['LTFM', 'KJFK'], ['ZBAA', 'EDDF'], ['VTBS', 'RJAA'], ['KSEA', 'PHNL'],
];

/** Clearly labelled sample traffic for demo mode only. Not real aircraft. */
export const demoProvider: FlightProvider = {
  id: 'demo',
  name: 'DEMO DATA (simulated)',
  url: '',
  coverage: 'Simulated aircraft flying between major airports. Not real traffic.',
  attribution: 'Sample data generated locally.',
  ttlSec: () => 10,
  cacheKey: () => 'demo',
  async fetchAircraft() {
    void airportCount();
    const now = Date.now() / 1000;
    const out: Aircraft[] = [];
    PAIRS.forEach(([a, b], i) => {
      const A = findAirport(a), B = findAirport(b);
      if (!A || !B) return;
      for (let k = 0; k < 3; k++) {
        const dist = haversineM(A.lat, A.lon, B.lat, B.lon);
        const speed = 235;
        const dur = dist / speed;
        const phase = (((now / dur) + (i * 0.137 + k / 3)) % 1 + 1) % 1;
        const p = intermediate(A.lat, A.lon, B.lat, B.lon, phase);
        const q = intermediate(A.lat, A.lon, B.lat, B.lon, Math.min(1, phase + 0.002));
        out.push({
          id: `d3m0${String(i).padStart(2, '0')}${k}`.slice(0, 6),
          callsign: `DEMO${i}${k}`, flightNumber: null, airline: 'Demo airline', registration: null, type: null,
          lat: p.lat, lon: p.lon, altM: 10500, speedMs: speed, headingDeg: bearingDeg(p.lat, p.lon, q.lat, q.lon), vsMs: 0,
          onGround: false, squawk: null, category: 'airliner', originCountry: null,
          lastContact: now, positionAt: now, source: 'DEMO DATA',
        });
      }
    });
    return out;
  },
};
