import { cache } from '../../cache/memoryCache';
import { fetchJson } from '../../utils/http';
import { findAirport } from '../airports';
import type { AirportBrief, FlightDetail } from '../../../src/types';

type Ref = AirportBrief | { icao: string; iata?: string | null; name?: string } | null;
const ref = (code: string | undefined): Ref => {
  if (!code) return null;
  return findAirport(code) ?? { icao: code.toUpperCase() };
};

/** Best-effort registration/type/route enrichment from adsb.lol. Failures degrade to an empty detail. */
export async function flightDetail(id: string, callsign?: string, lat?: number, lon?: number): Promise<{ value: FlightDetail; fetchedAt: number }> {
  const key = `detail:${id}:${callsign ?? ''}`;
  const r = await cache.wrap(key, 10 * 60_000, async () => {
    const detail: FlightDetail = { id };
    try {
      const j = await fetchJson<{ ac?: { r?: string; t?: string; desc?: string; ownOp?: string }[] }>(`https://api.adsb.lol/v2/hex/${id}`, { provider: 'adsb.lol', timeoutMs: 8000 });
      const a = j.ac?.[0];
      if (a) { detail.registration = a.r ?? null; detail.type = a.t ?? null; detail.description = a.desc ?? null; detail.operator = a.ownOp ?? null; }
    } catch { /* optional */ }
    if (callsign && lat != null && lon != null) {
      try {
        const routes = await fetchJson<{ airport_codes?: string; plausible?: boolean }[]>('https://api.adsb.lol/api/0/routeset', {
          provider: 'adsb.lol', timeoutMs: 8000, method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ planes: [{ callsign, lat, lng: lon }] }),
        });
        const codes = routes?.[0]?.airport_codes;
        if (codes && codes !== 'unknown' && routes[0].plausible !== false) {
          const parts = codes.split('-').filter(Boolean);
          if (parts.length >= 2) {
            detail.origin = ref(parts[0]);
            detail.destination = ref(parts[parts.length - 1]);
            detail.routeSource = 'adsb.lol community route data (not a schedule; may be inaccurate)';
          }
        }
      } catch { /* optional */ }
    }
    return detail;
  });
  return { value: r.value, fetchedAt: r.fetchedAt };
}
