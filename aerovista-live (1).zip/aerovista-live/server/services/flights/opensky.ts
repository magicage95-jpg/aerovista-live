import { config } from '../../config';
import { UpstreamError, fetchJson } from '../../utils/http';
import { categoryFromOpenSky, parseCallsign } from '../airlines';
import type { Aircraft } from '../../../src/types';
import type { FlightProvider } from './types';

const STATES = 'https://opensky-network.org/api/states/all?extended=1';
const TOKEN_URL = 'https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token';
let token: { value: string; exp: number } | null = null;

async function getToken(): Promise<string | null> {
  const { openskyId, openskySecret } = config.flights;
  if (!openskyId || !openskySecret) return null;
  if (token && token.exp > Date.now() + 30_000) return token.value;
  const res = await fetch(TOKEN_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ grant_type: 'client_credentials', client_id: openskyId, client_secret: openskySecret }),
  }).catch(() => null);
  if (!res || !res.ok) throw new UpstreamError(`OpenSky authentication failed${res ? ` (${res.status})` : ''}`, 502, 'OpenSky Network');
  const j = (await res.json()) as { access_token: string; expires_in: number };
  token = { value: j.access_token, exp: Date.now() + j.expires_in * 1000 };
  return token.value;
}

type State = (string | number | boolean | null | (number | null)[])[];

export const openSky: FlightProvider = {
  id: 'opensky',
  name: 'OpenSky Network',
  url: 'https://opensky-network.org',
  coverage: 'Global ADS-B/MLAT receiver network. Coverage depends on volunteer receivers: sparse over oceans and some regions.',
  attribution: 'Aircraft state data © The OpenSky Network, https://opensky-network.org',
  // Anonymous access has a small daily credit budget, so refresh far less often unless credentials are configured.
  ttlSec: () => config.flights.cacheTtlSec || (config.flights.openskyId ? 90 : 900),
  cacheKey: (q) => `opensky:${q.includeGround ? 'g' : 'a'}`,
  async fetchAircraft(q) {
    const t = await getToken();
    const json = await fetchJson<{ time: number; states: State[] | null }>(STATES, {
      provider: 'OpenSky Network',
      timeoutMs: 25_000,
      headers: t ? { Authorization: `Bearer ${t}` } : undefined,
    });
    const out: Aircraft[] = [];
    for (const s of json.states ?? []) {
      const lat = s[6] as number | null, lon = s[5] as number | null;
      if (lat == null || lon == null) continue;
      const onGround = Boolean(s[8]);
      if (onGround && !q.includeGround) continue;
      const callsign = ((s[1] as string) || '').trim() || null;
      const info = parseCallsign(callsign);
      out.push({
        id: String(s[0]),
        callsign,
        flightNumber: info.flightNumber,
        airline: info.airline,
        lat, lon,
        altM: (s[13] as number | null) ?? (s[7] as number | null),
        speedMs: s[9] as number | null,
        headingDeg: s[10] as number | null,
        vsMs: s[11] as number | null,
        onGround,
        squawk: (s[14] as string | null) ?? null,
        category: categoryFromOpenSky(s[17] as number | null, info.cargo),
        originCountry: s[2] as string,
        lastContact: s[4] as number,
        positionAt: (s[3] as number | null) ?? (s[4] as number),
        source: 'OpenSky Network',
      });
    }
    return out;
  },
};
