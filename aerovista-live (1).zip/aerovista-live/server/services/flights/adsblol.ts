import { fetchJson } from '../../utils/http';
import { categoryFromAdsb, parseCallsign } from '../airlines';
import type { Aircraft } from '../../../src/types';
import type { FlightProvider, FlightQuery } from './types';

interface AdsbAc {
  hex: string; flight?: string; r?: string; t?: string; alt_baro?: number | 'ground'; alt_geom?: number;
  gs?: number; track?: number; baro_rate?: number; geom_rate?: number; squawk?: string; lat?: number; lon?: number;
  seen?: number; seen_pos?: number; category?: string; dbFlags?: number;
}

const FT = 0.3048, KT = 0.514444, FPM = 0.00508;
const cell = (v: number | undefined, step: number) => Math.round((v ?? 0) / step) * step;

export const adsbLol: FlightProvider = {
  id: 'adsblol',
  name: 'adsb.lol',
  url: 'https://adsb.lol',
  coverage: 'Regional: aircraft within ~250 NM of the view centre, from the adsb.lol community receiver network.',
  attribution: 'Aircraft data from adsb.lol, community-sourced ADS-B (ODbL).',
  ttlSec: () => 15,
  cacheKey: (q) => `adsblol:${cell(q.lat, 5)}:${cell(q.lon, 5)}:${q.includeGround ? 'g' : 'a'}`,
  async fetchAircraft(q: FlightQuery) {
    const lat = cell(q.lat, 5), lon = cell(q.lon, 5);
    const r = Math.min(250, Math.max(25, Math.round(q.radiusNm ?? 250)));
    const j = await fetchJson<{ ac?: AdsbAc[] }>(`https://api.adsb.lol/v2/point/${lat}/${lon}/${r}`, { provider: 'adsb.lol' });
    const now = Date.now() / 1000;
    const out: Aircraft[] = [];
    for (const a of j.ac ?? []) {
      if (a.lat == null || a.lon == null) continue;
      const onGround = a.alt_baro === 'ground';
      if (onGround && !q.includeGround) continue;
      const callsign = a.flight?.trim() || null;
      const info = parseCallsign(callsign);
      const alt = typeof a.alt_baro === 'number' ? a.alt_baro * FT : a.alt_geom != null ? a.alt_geom * FT : null;
      const rate = a.baro_rate ?? a.geom_rate;
      out.push({
        id: a.hex.replace('~', '').toLowerCase(),
        callsign, flightNumber: info.flightNumber, airline: info.airline,
        registration: a.r ?? null, type: a.t ?? null,
        lat: a.lat, lon: a.lon, altM: onGround ? 0 : alt,
        speedMs: a.gs != null ? a.gs * KT : null,
        headingDeg: a.track ?? null,
        vsMs: rate != null ? rate * FPM : null,
        onGround, squawk: a.squawk ?? null,
        category: categoryFromAdsb(a.category, info.cargo, Boolean((a.dbFlags ?? 0) & 1)),
        lastContact: now - (a.seen ?? 0),
        positionAt: now - (a.seen_pos ?? a.seen ?? 0),
        source: 'adsb.lol',
      });
    }
    return out;
  },
};
