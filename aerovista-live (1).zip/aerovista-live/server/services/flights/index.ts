import { config } from '../../config';
import { cache, Throttler } from '../../cache/memoryCache';
import { UpstreamError } from '../../utils/http';
import { openSky } from './opensky';
import { adsbLol } from './adsblol';
import { demoProvider } from './demo';
import type { FlightProvider, FlightQuery } from './types';
import type { Aircraft, Envelope } from '../../../src/types';

const throttles: Record<string, Throttler> = {
  opensky: new Throttler(2_000),
  adsblol: new Throttler(1_000),
  demo: new Throttler(0),
};
const cooldown = new Map<string, number>();
let lastAircraft: Aircraft[] = [];

function chain(): FlightProvider[] {
  if (config.demoMode === 'on' || config.flights.provider === 'demo') return [demoProvider];
  switch (config.flights.provider) {
    case 'opensky': return [openSky];
    case 'adsblol': return [adsbLol];
    default: return [openSky, adsbLol];
  }
}

export async function getFlights(q: FlightQuery): Promise<Envelope<Aircraft[]>> {
  let lastErr: unknown = new UpstreamError('No flight provider available', 503, 'flights');
  for (const p of chain()) {
    if ((cooldown.get(p.id) ?? 0) > Date.now()) continue;
    try {
      const r = await cache.wrap(p.cacheKey(q), p.ttlSec() * 1000, () => throttles[p.id].run(() => p.fetchAircraft(q)));
      if (!r.stale) cooldown.delete(p.id);
      lastAircraft = r.value;
      const demo = p.id === 'demo';
      return {
        data: r.value,
        meta: {
          source: p.name, url: p.url, kind: demo ? 'DEMO' : 'LIVE', demo,
          fetchedAt: r.fetchedAt, stale: r.stale, ttlSec: p.ttlSec(),
          coverage: p.coverage, attribution: p.attribution,
          note: 'Positions between updates are estimated from speed and heading.',
        },
      };
    } catch (e) {
      lastErr = e;
      cooldown.set(p.id, Date.now() + 60_000);
    }
  }
  throw lastErr;
}

export const currentAircraft = () => lastAircraft;
export function flightsProviderStatus() {
  const demo = config.demoMode === 'on' || config.flights.provider === 'demo';
  return {
    provider: demo ? demoProvider.name : config.flights.provider === 'auto' ? 'OpenSky Network → adsb.lol fallback' : chain()[0].name,
    configured: demo ? true : Boolean(config.flights.openskyId) || config.flights.provider !== 'opensky',
    note: config.flights.openskyId ? 'OpenSky credentials configured.' : 'No OpenSky credentials: anonymous access is heavily rate limited, so refreshes are slow.',
  };
}
