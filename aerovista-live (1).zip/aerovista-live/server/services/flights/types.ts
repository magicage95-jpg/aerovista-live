import type { Aircraft } from '../../../src/types';

export interface FlightQuery { lat?: number; lon?: number; radiusNm?: number; includeGround?: boolean }
export interface FlightProvider {
  id: string;
  name: string;
  url: string;
  coverage: string;
  attribution: string;
  ttlSec(): number;
  cacheKey(q: FlightQuery): string;
  fetchAircraft(q: FlightQuery): Promise<Aircraft[]>;
}
