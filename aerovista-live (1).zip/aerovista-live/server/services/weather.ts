import { config } from '../config';
import { cache } from '../cache/memoryCache';
import { fetchJson } from '../utils/http';
import type { Envelope, WeatherReport } from '../../src/types';

interface OM {
  current: Record<string, number | string>;
  hourly: { time: string[]; temperature_2m: number[]; precipitation_probability: (number | null)[]; weather_code: number[]; wind_speed_10m: number[] };
  daily: { time: string[]; temperature_2m_max: number[]; temperature_2m_min: number[]; weather_code: number[]; precipitation_probability_max: (number | null)[] };
}

export async function getWeather(lat: number, lon: number): Promise<Envelope<WeatherReport>> {
  const la = Math.round(lat * 10) / 10, lo = Math.round(lon * 10) / 10;
  const r = await cache.wrap(`wx:${la}:${lo}`, 10 * 60_000, async () => {
    const base = config.weatherKey ? 'https://customer-api.open-meteo.com/v1/forecast' : 'https://api.open-meteo.com/v1/forecast';
    const q = new URLSearchParams({
      latitude: String(la), longitude: String(lo),
      current: 'temperature_2m,apparent_temperature,relative_humidity_2m,pressure_msl,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code,visibility,is_day',
      hourly: 'temperature_2m,precipitation_probability,weather_code,wind_speed_10m',
      daily: 'temperature_2m_max,temperature_2m_min,weather_code,precipitation_probability_max',
      forecast_days: '3', timezone: 'UTC', wind_speed_unit: 'kmh',
    });
    if (config.weatherKey) q.set('apikey', config.weatherKey);
    const j = await fetchJson<OM>(`${base}?${q}`, { provider: 'Open-Meteo' });
    const c = j.current;
    const nowIso = String(c.time).slice(0, 13);
    const start = Math.max(0, j.hourly.time.findIndex((t) => t.startsWith(nowIso)));
    const report: WeatherReport = {
      lat: la, lon: lo,
      current: {
        time: String(c.time) + 'Z',
        temperatureC: Number(c.temperature_2m), apparentC: Number(c.apparent_temperature),
        humidity: Number(c.relative_humidity_2m), pressureHpa: Number(c.pressure_msl), cloudPct: Number(c.cloud_cover),
        windKmh: Number(c.wind_speed_10m), windGustKmh: c.wind_gusts_10m == null ? null : Number(c.wind_gusts_10m),
        windDirDeg: Number(c.wind_direction_10m), visibilityM: c.visibility == null ? null : Number(c.visibility),
        code: Number(c.weather_code), isDay: Number(c.is_day) === 1,
      },
      hourly: j.hourly.time.slice(start, start + 24).map((t, i) => ({
        time: t + 'Z', tempC: j.hourly.temperature_2m[start + i], precipPct: j.hourly.precipitation_probability[start + i],
        code: j.hourly.weather_code[start + i], windKmh: j.hourly.wind_speed_10m[start + i],
      })),
      daily: j.daily.time.map((d, i) => ({
        date: d, maxC: j.daily.temperature_2m_max[i], minC: j.daily.temperature_2m_min[i],
        code: j.daily.weather_code[i], precipPct: j.daily.precipitation_probability_max[i],
      })),
    };
    return report;
  });
  return {
    data: r.value,
    meta: {
      source: 'Open-Meteo', url: 'https://open-meteo.com', kind: 'LIVE', fetchedAt: r.fetchedAt, stale: r.stale, ttlSec: 600,
      attribution: 'Weather data by Open-Meteo.com (CC BY 4.0). Model-based forecast, not an airport METAR.',
      note: 'Values are gridded model output for this location, not observations from the airport weather station.',
    },
  };
}
